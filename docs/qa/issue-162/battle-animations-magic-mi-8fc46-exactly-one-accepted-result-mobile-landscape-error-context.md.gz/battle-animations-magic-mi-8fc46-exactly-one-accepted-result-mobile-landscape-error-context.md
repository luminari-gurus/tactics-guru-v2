# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-animations.spec.ts >> magic_missile: real controls, travel/impact, transformed anchors and exactly one accepted result
- Location: tests/battle-animations.spec.ts:210:25

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 3
+ Received  + 1

@@ -1,12 +1,10 @@
  Array [
    Object {
      "abilityId": "ability:magic_missile",
      "target": Object {
-       "missileTargets": Array [
-         4,
-       ],
+       "unitId": 4,
      },
      "type": "abilityUsed",
      "unitId": 3,
    },
    Object {
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Battle controls" [ref=e8]:
      - generic "Acting unit information; scroll for details" [ref=e9]:
        - paragraph [ref=e10]: Round 1 · Your turn · Resolving action (Animating)
        - generic [ref=e11]:
          - img "Mage portrait" [ref=e13]
          - generic [ref=e14]:
            - heading "Mage" [level=2] [ref=e15]
            - paragraph [ref=e16]: HP 11/11
            - paragraph [ref=e19]: AC 11 · Accuracy +3
            - paragraph [ref=e20]: No status effects
        - paragraph [ref=e21]: Move spent / Action spent
      - generic "Actions, target and secondary tools; scroll for more" [ref=e22]:
        - generic [ref=e23]:
          - paragraph [ref=e24]: Choose your action
          - generic "Acting unit actions" [ref=e25]:
            - button "Move" [disabled] [ref=e26]:
              - strong [ref=e27]: Move
              - generic [ref=e28]: Unavailable
            - button "Basic attack" [disabled] [ref=e29]:
              - strong [ref=e30]: Basic attack
              - generic [ref=e31]: Unavailable
            - button "Magic Missile" [disabled] [ref=e32]:
              - strong [ref=e33]: Magic Missile
              - generic [ref=e34]: Unavailable
            - button "Wait / End turn" [disabled] [ref=e35]:
              - strong [ref=e36]: Wait / End turn
              - generic [ref=e37]: Ends turn immediately
          - text: Ability
          - combobox "Ability" [disabled] [ref=e38]:
            - option "Magic Missile" [selected]
          - paragraph [ref=e39]: Resolving action. Gameplay is locked until presentation finishes.Range 1–5 · Living target, including allies · automatic force damage · uses action
          - paragraph [ref=e40]: Resolving action. Gameplay is locked until presentation finishes.
          - region "Target and action preview" [ref=e41]:
            - generic [ref=e42]: Target / destination
            - combobox "Target / destination" [disabled] [ref=e43]:
              - option "Choose target" [selected]
            - paragraph [ref=e44]: Select a tile
            - paragraph
            - paragraph [ref=e45]: Choose an action and target
            - generic [ref=e46]:
              - button "Review action" [disabled] [ref=e47]
              - button "Cancel action" [disabled] [ref=e48]
          - navigation "Secondary battle tools" [ref=e49]:
            - button "Inspect party" [ref=e50] [cursor=pointer]
            - button "Battle log" [ref=e51] [cursor=pointer]
            - button "Enable sound" [ref=e52] [cursor=pointer]
          - paragraph [ref=e53]: Sound off
        - generic [ref=e54]:
          - status [ref=e55]: Battle ready
          - button "Restart battle" [active] [ref=e56] [cursor=pointer]
        - generic [ref=e57]:
          - generic [ref=e58]: Battle saved on this device
          - button "Save recovery" [ref=e59] [cursor=pointer]
        - paragraph [ref=e60]: "Gold: active · White: selected · Teal: reachable · Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Play three-encounter run" [ref=e61] [cursor=pointer]:
          - /url: /run
        - group [ref=e62]:
          - generic "Privacy & analytics" [ref=e63] [cursor=pointer]
```

# Test source

```ts
  126 |   if(command.type!=='useAbility' || !('unitId' in command.target))throw Error('Expected unit attack fixture');
  127 |   const targetId=command.target.unitId;
  128 |   const target=fixture.before.units.find(u=>u.id===targetId)!;
  129 |   const current=await report(page),tile=current.tiles.find((t:any)=>t.x===target.cell.x&&t.y===target.cell.y),point=projectTile(tile);
  130 |   const screen={x:current.transform.x+point.x*current.transform.scale,y:current.transform.y+point.y*current.transform.scale};
  131 |   if(info.project.name.startsWith('mobile'))await page.touchscreen.tap(screen.x,screen.y);
  132 |   else await page.mouse.click(screen.x,screen.y);
  133 |   expect((await report(page)).targets.find((t:any)=>t.selected)).toEqual({cell:target.cell,valid:true,selected:true,reason:null});
  134 |   await page.locator('#battle-review').click();await page.locator('#dialog-cancel').click();
  135 |   expect((await report(page)).targets).toEqual([]);await expect(page.locator('#battle-review')).toBeDisabled();
  136 |   await press(page,'[data-action="signature"]');await page.locator('#battle-target').selectOption(`${target.cell.x},${target.cell.y}`);
  137 |   await press(page,'[data-action="move"]');expect((await report(page)).targets).toEqual([]);
  138 |   await press(page,'[data-action="basic"]');expect((await report(page)).targets.length).toBeGreaterThan(0);
  139 |   await page.locator('#battle-cancel').click();expect((await report(page)).targets).toEqual([]);
  140 |   expect((await readSession(page)).state).toEqual(initial);expect(await stored(page)).toEqual(saved);
  141 |   await press(page,'[data-action="signature"]');await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);
  142 |   expect((await report(page)).targets).toEqual([]);
  143 | });
  144 | function aligned(r:any,fixture:Boundary) {
  145 |   const effect=r.effect;expect(effect).not.toBeNull();
  146 |   for(const [id,point] of [[effect.actorId,effect.from],[effect.targetId,effect.to]] as const){
  147 |     const unit=fixture.before.units.find(u=>u.id===id)!,tile=r.tiles.find((t:any)=>t.x===unit.cell.x && t.y===unit.cell.y);
  148 |     const expected=projectTile(tile);expect(point).toEqual({x:expected.x,y:expected.y-28});
  149 |     expect(r.units.find((u:any)=>u.id===id).anchorError).toBeLessThan(0.001);
  150 |   }
  151 | }
  152 | 
  153 | test('shared corpse cell keeps living target identity through inspection, confirmation and execution',async({page},info)=>{
  154 |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  155 |   const fixture=sharedCellBoundary();expect(fixture.before.commandCount).toBe(64);
  156 |   const target=fixture.before.units.find(u=>u.id===5)!,corpse=fixture.before.units.find(u=>u.id===2)!;
  157 |   expect(target.hp).toBe(5);expect(corpse.hp).toBe(0);expect(corpse.cell).toEqual(target.cell);
  158 |   await boot(page,fixture);
  159 |   await expect(page).toHaveTitle(/Tactics Guru/);await expect(page.locator('vite-error-overlay')).toHaveCount(0);
  160 |   await page.locator('[data-action="basic"]').click();await page.locator('#battle-target').selectOption(`${target.cell.x},${target.cell.y}`);
  161 |   const label='Goblin Archer #5 · HP 5/8',saved=await stored(page),prepared=await page.locator('#game').getAttribute('data-session');
  162 |   expect(JSON.parse(prepared!).pending).toEqual(fixture.command);
  163 |   await expect(page.locator('#battle-target option:checked')).toContainText(label);
  164 |   await expect(page.locator('#battle-target-info')).toHaveText(`Target: ${label}`);
  165 |   await page.locator('#battle-inspect-target').click();await expect(page.locator('#battle-dialog-title')).toHaveText('Inspection only — Goblin Archer #5');
  166 |   await expect(page.locator('#battle-dialog-message')).toContainText('HP 5/8');
  167 |   await page.locator('#inspection-close').click();expect(await page.locator('#game').getAttribute('data-session')).toBe(prepared);expect(await stored(page)).toEqual(saved);
  168 |   // Confirmation must use the prepared command, even if the rendered panel is stale.
  169 |   await page.locator('#battle-target-info').evaluate(el=>{el.textContent='Target: Ranger #2 · Defeated';});
  170 |   await page.locator('#battle-review').click();await expect(page.locator('#battle-dialog-message')).toContainText(`Target: ${label}`);
  171 |   await expect(page.locator('#battle-dialog-message')).not.toContainText('Ranger #2');
  172 |   await page.screenshot({path:info.outputPath('living-target-confirmation.png')});
  173 |   await confirmFrozen(page);
  174 |   const accepted=await readSession(page);expect(accepted.continuation!.commands).toEqual([fixture.command]);
  175 |   expect(accepted.events).toEqual(fixture.events);expect(accepted.state).toEqual(fixture.after);expect(accepted.state.units.find(u=>u.id===corpse.id)!.hp).toBe(0);
  176 |   await page.clock.runFor(700);await ready(page);expect(errors).toEqual([]);
  177 | });
  178 | 
  179 | for(const outcome of ['miss','defeat'] as const)test(`guarded strike ${outcome}: panned-edge actor and target feedback never overlap`,async({page},info)=>{
  180 |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  181 |   const fixture=boundary('guarded_strike',outcome,false,1);
  182 |   if(outcome==='defeat'){expect(fixture.before.seed).toBe(1);expect(fixture.before.commandCount).toBe(73);}
  183 |   await page.setViewportSize({width:320,height:568});await boot(page,fixture);
  184 |   const r=(await report(page)).region;
  185 |   const drag=async(dx:number,dy:number)=>{
  186 |     const x=r.x+r.width*(dx>0?.1:dx<0?.9:.5),y=r.y+r.height*(dy>0?.1:dy<0?.9:.5);
  187 |     await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+dx*r.width*.8,y+dy*r.height*.8,{steps:8});await page.mouse.up();
  188 |   };
  189 |   // Reproduce the review: pan before the command, with no mid-animation gesture.
  190 |   await drag(0,-1);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(288);
  191 |   const saved=await stored(page);
  192 |   const check=async()=>{
  193 |     const frame=await report(page),labels=frame.feedbackBounds;
  194 |     expect(labels.map((b:any)=>b.text)).toEqual(abilityPresentation(fixture.events).feedback.map(f=>f.text));
  195 |     expect(labels).toHaveLength(outcome==='defeat'?3:2);
  196 |     for(const a of labels){
  197 |       expect(a.x).toBeGreaterThanOrEqual(frame.region.x);expect(a.y).toBeGreaterThanOrEqual(frame.region.y);
  198 |       expect(a.x+a.width).toBeLessThanOrEqual(frame.region.x+frame.region.width);expect(a.y+a.height).toBeLessThanOrEqual(frame.region.y+frame.region.height);
  199 |     }
  200 |     for(let i=0;i<labels.length;i++)for(let j=i+1;j<labels.length;j++){
  201 |       const a=labels[i],b=labels[j];expect(a.x+a.width<=b.x || b.x+b.width<=a.x || a.y+a.height<=b.y || b.y+b.height<=a.y,`${a.text} overlaps ${b.text}`).toBe(true);
  202 |     }
  203 |     expect((await readSession(page)).state).toEqual(fixture.after);expect(await stored(page)).toEqual(saved);
  204 |   };
  205 |   await check();await page.screenshot({path:info.outputPath(`guarded-${outcome}-prepan.png`)});
  206 |   // Re-layout at the other edges, maximum zoom and an actual viewport change.
  207 |   for(const [dx,dy] of [[0,1],[-1,0],[1,0],[0,-1]]){await drag(dx,dy);await check();}
  208 |   await page.mouse.move(r.x+r.width/2,r.y+r.height/2);await page.mouse.wheel(0,-3000);await drag(0,-1);await check();
  209 |   await page.setViewportSize({width:568,height:320});await page.clock.runFor(32);await check();
  210 |   await page.clock.runFor(700);await ready(page);expect(errors).toEqual([]);
  211 | });
  212 | 
  213 | for(const kind of kinds)test(`${kind}: real controls, travel/impact, transformed anchors and exactly one accepted result`,async({page},info)=>{
  214 |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  215 |   const fixture=boundary(kind),keyboard=kind==='magic_missile';await boot(page,fixture);
  216 |   const baseline=(await report(page)).objectCount,savedBefore=await stored(page);
  217 |   // A signature aimed at its own actor must remain a rejected preview, with no cue or save.
  218 |   await press(page,'[data-action="signature"]',keyboard);await page.locator('canvas').focus();await page.keyboard.press('Enter');
  219 |   await expect(page.locator('#battle-preview')).toContainText('Unavailable');await expect(page.locator('#battle-review')).toBeDisabled();
  220 |   expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.before);expect(await stored(page)).toEqual(savedBefore);
  221 |   await press(page,'#battle-cancel',keyboard);
  222 |   await review(page,fixture,keyboard);await page.keyboard.press('Escape');
  223 |   expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.before);expect(await stored(page)).toEqual(savedBefore);
  224 |   // Transform before the effect through real board gestures.
  225 |   const point=await page.evaluate(()=>{const r=document.querySelector('#battle-board-region')!.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height*0.6};});
> 226 |   await page.mouse.move(point.x,point.y);await page.mouse.wheel(0,-80);
      |                                                                         ^ Error: expect(received).toEqual(expected) // deep equality
  227 |   await review(page,fixture,keyboard);await confirmFrozen(page);
  228 |   const accepted=await readSession(page),saved=await stored(page);
  229 |   expect(accepted.state).toEqual(fixture.after);expect(accepted.events).toEqual(fixture.events);
  230 |   expect(accepted.continuation!.commands).toEqual([fixture.command]);
  231 |   const expected=dispatch(fixture.before,fixture.command,catalog);expect(expected.ok).toBe(true);
  232 |   if(expected.ok)expect(accepted.state).toEqual(expected.state);
  233 |   // Exercise board input during the lock. Fresh keys on the usable Restart
  234 |   // fallback intentionally open/confirm reset; held-key capture has its own regression.
  235 |   await expect(page.locator('#fit-restart')).toBeFocused();await page.locator('canvas').focus();
  236 |   await page.keyboard.press('Enter');await page.keyboard.press('Space');
  237 |   await expect(page.locator('#battle-next')).toBeDisabled();await expect(page.locator('[data-action="signature"]')).toBeDisabled();
  238 |   await page.clock.runFor(112);const travel=await report(page);aligned(travel,fixture);
  239 |   expect(travel.effect.progress).toBeGreaterThan(0);expect(travel.effect.progress).toBeLessThan(0.45);
  240 |   await page.screenshot({path:info.outputPath(`${kind}-travel.png`)});
  241 |   // Pan/zoom during flight without changing the accepted simulation.
  242 |   await page.mouse.move(point.x,point.y);await page.mouse.down();await page.mouse.move(point.x+25,point.y-15,{steps:3});await page.mouse.up();
  243 |   await page.mouse.wheel(0,-50);await page.clock.runFor(176);
  244 |   const impact=await report(page);aligned(impact,fixture);expect(impact.transform).not.toEqual(travel.transform);
  245 |   expect(impact.effect.progress).toBeGreaterThanOrEqual(0.45);
  246 |   expect(impact.effect.feedback.filter((f:any)=>f.visible).map((f:any)=>({unitId:f.unitId,text:f.text})))
  247 |     .toEqual(abilityPresentation(fixture.events).feedback.map(f=>({unitId:f.unitId,text:f.text})));
  248 |   await page.screenshot({path:info.outputPath(`${kind}-impact.png`)});
  249 |   const capture=(r:any)=>({viewport:r.viewport,transform:r.transform,effect:r.effect,
  250 |     units:r.units.filter((u:any)=>u.id===r.effect.actorId || u.id===r.effect.targetId),objectCount:r.objectCount});
  251 |   writeFileSync(info.outputPath('animation.json'),JSON.stringify({viewport:page.viewportSize(),fixture,travel:capture(travel),impact:capture(impact)},null,2));
  252 |   expect((await readSession(page)).state).toEqual(accepted.state);expect(await stored(page)).toEqual(saved);
  253 |   await page.clock.runFor(500);await ready(page);
  254 |   expect((await report(page)).effect).toBeNull();expect((await report(page)).objectCount).toBe(baseline);
  255 |   expect((await readSession(page)).state).toEqual(fixture.after);expect(await stored(page)).toEqual(saved);expect(errors).toEqual([]);
  256 | });
  257 | 
  258 | for(const [kind,outcome] of [['guarded_strike','miss'],['high_shot','miss'],['high_shot','critical'],['magic_missile','defeat']] as const)
  259 | test(`${kind}: ${outcome} feedback matches resolved events`,async({page},info)=>{
  260 |   const fixture=boundary(kind,outcome);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(288);
  261 |   const r=await report(page);aligned(r,fixture);
  262 |   const feedback=abilityPresentation(fixture.events).feedback;
  263 |   expect(r.effect.feedback.map((f:any)=>({unitId:f.unitId,text:f.text}))).toEqual(feedback.map(f=>({unitId:f.unitId,text:f.text})));
  264 |   expect(r.effect.feedback.every((f:any)=>f.visible)).toBe(true);
  265 |   if(outcome==='miss'){expect(feedback.some(f=>f.text==='Miss')).toBe(true);expect(feedback.some(f=>f.text.includes('−'))).toBe(false);}
  266 |   if(kind==='guarded_strike')expect(feedback).toContainEqual({unitId:r.effect.actorId,kind:'guard',text:'Guarded'});
  267 |   const positions=r.effect.feedback.map((f:any)=>`${f.x},${f.y}`);expect(new Set(positions).size).toBe(positions.length);
  268 |   await page.screenshot({path:info.outputPath(`${kind}-${outcome}.png`)});await page.clock.runFor(500);
  269 |   expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.after);
  270 | });
  271 | 
  272 | for(const kind of kinds)test(`${kind}: repeated cancellation, modal refresh, resize and restart during travel and impact`,async({page})=>{
  273 |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  274 |   const fixture=boundary(kind);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(96);
  275 |   const saved=await stored(page);
  276 |   await page.locator('#fit-restart').click({force:true});await page.locator('#save-cancel-reset').click({force:true});
  277 |   aligned(await report(page),fixture);
  278 |   const size=page.viewportSize()!;await page.setViewportSize({width:size.height,height:size.width});await page.clock.runFor(64);
  279 |   aligned(await report(page),fixture);
  280 |   await page.evaluate(()=>{
  281 |     Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});
  282 |     for(let i=0;i<3;i++)document.dispatchEvent(new Event('visibilitychange'));
  283 |   });
  284 |   await ready(page);expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.after);expect(await stored(page)).toEqual(saved);
  285 |   await page.evaluate(()=>{delete (document as unknown as {hidden?:boolean}).hidden;document.dispatchEvent(new Event('visibilitychange'));});
  286 |   await page.clock.runFor(700);expect((await readSession(page)).state).toEqual(fixture.after);
  287 |   // Restore only this known legal boundary via the real persisted-save startup for each teardown phase.
  288 |   for(const time of [96,288]){
  289 |     const encoded=encodeBattleSave(fixture.before,catalog);if(!encoded.ok)throw Error(encoded.reason);
  290 |     await page.evaluate(({keys,text})=>{localStorage.setItem(keys.primary,text);localStorage.setItem(keys.backup,text);},{keys,text:encoded.text});
  291 |     await page.reload();await page.clock.resume();await page.locator('#save-continue').click();await ready(page);
  292 |     await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(time);
  293 |     await page.locator('#fit-restart').click({force:true});await confirmRestart(page,true);await page.clock.resume();await ready(page);
  294 |     expect((await readSession(page)).state.seed).toBe(fixture.before.seed+1);expect((await report(page)).effect).toBeNull();
  295 |     await expect(page.locator('canvas')).toHaveCount(1);
  296 |   }
  297 |   expect(errors).toEqual([]);
  298 | });
  299 | 
  300 | for(const kind of kinds)test(`${kind}: reload resumes accepted save without historical effects`,async({page})=>{
  301 |   const fixture=boundary(kind);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(112);
  302 |   const saved=await stored(page);await page.reload();await page.clock.resume();await expect(page.locator('#save-continue')).toBeVisible();
  303 |   expect(await stored(page)).toEqual(saved);await page.locator('#save-continue').click();await ready(page);
  304 |   expect((await readSession(page)).state).toEqual(fixture.after);expect((await readSession(page)).events).toEqual([]);
  305 |   expect((await report(page)).effect).toBeNull();expect(await stored(page)).toEqual(saved);
  306 | });
  307 | 
  308 | test('elevated target remains anchored through rotation during impact',async({page},info)=>{
  309 |   const fixture=boundary('high_shot','any',true);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);
  310 |   await page.clock.runFor(288);const before=await report(page);aligned(before,fixture);
  311 |   const unit=fixture.before.units.find(u=>u.id===before.effect.targetId)!;
  312 |   expect(before.tiles.find((t:any)=>t.x===unit.cell.x && t.y===unit.cell.y).elevation).toBeGreaterThan(0);
  313 |   const size=page.viewportSize()!,rotated={width:size.height,height:size.width};
  314 |   // Native resize delivery is independent of the paused animation clock. Wait
  315 |   // for that event before advancing Phaser's resize/presentation callbacks.
  316 |   await page.evaluate(()=>window.addEventListener('resize',()=>{document.documentElement.dataset.impactResize='observed';},{once:true}));
  317 |   await page.setViewportSize(rotated);
  318 |   await expect(page.locator('html')).toHaveAttribute('data-impact-resize','observed');
  319 |   await page.clock.runFor(64);
  320 |   const after=await report(page);aligned(after,fixture);expect(after.viewport).toEqual(rotated);
  321 |   await page.screenshot({path:info.outputPath('elevated-rotated-impact.png')});
  322 |   await page.clock.runFor(500);expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.after);
  323 | });
  324 | 
  325 | test.describe('ability departure through real browser history',()=>{
  326 |   for(const kind of kinds)test(`${kind}: cached return preserves exact accepted slots until Continue`,async({page,baseURL})=>{
```
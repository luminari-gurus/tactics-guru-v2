# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-animations.spec.ts >> magic_missile: real controls, travel/impact, transformed anchors and exactly one accepted result
- Location: tests/battle-animations.spec.ts:210:25

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 3
+ Received  + 1

@@ -1,12 +1,10 @@
  Array [
    Object {
      "abilityId": "ability:magic_missile",
      "target": Object {
-       "missileTargets": Array [
-         4,
-       ],
+       "unitId": 4,
      },
      "type": "abilityUsed",
      "unitId": 3,
    },
    Object {
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Battle controls" [ref=e8]:
      - generic "Acting unit information; scroll for details" [ref=e9]:
        - paragraph [ref=e10]: Round 1 · Your turn · Resolving action (Animating)
        - generic [ref=e11]:
          - img "Mage portrait" [ref=e13]
          - generic [ref=e14]:
            - heading "Mage" [level=2] [ref=e15]
            - paragraph [ref=e16]: HP 11/11
            - paragraph [ref=e19]: AC 11 · Accuracy +3
            - paragraph [ref=e20]: No status effects
        - paragraph [ref=e21]: Move spent / Action spent
      - generic "Actions, target and secondary tools; scroll for more" [ref=e22]:
        - generic [ref=e23]:
          - paragraph [ref=e24]: Choose your action
          - generic "Acting unit actions" [ref=e25]:
            - button "Move" [disabled] [ref=e26]:
              - strong [ref=e27]: Move
              - generic [ref=e28]: Unavailable
            - button "Basic attack" [disabled] [ref=e29]:
              - strong [ref=e30]: Basic attack
              - generic [ref=e31]: Unavailable
            - button "Magic Missile" [disabled] [ref=e32]:
              - strong [ref=e33]: Magic Missile
              - generic [ref=e34]: Unavailable
            - button "Wait / End turn" [disabled] [ref=e35]:
              - strong [ref=e36]: Wait / End turn
              - generic [ref=e37]: Ends turn immediately
          - text: Ability
          - combobox "Ability" [disabled] [ref=e38]:
            - option "Magic Missile" [selected]
          - paragraph [ref=e39]: Resolving action. Gameplay is locked until presentation finishes.Range 1–5 · Living target, including allies · automatic force damage · uses action
          - paragraph [ref=e40]: Resolving action. Gameplay is locked until presentation finishes.
          - region "Target and action preview" [ref=e41]:
            - generic [ref=e42]: Target / destination
            - combobox "Target / destination" [disabled] [ref=e43]:
              - option "Choose target" [selected]
            - paragraph [ref=e44]: Select a tile
            - paragraph
            - paragraph [ref=e45]: Choose an action and target
            - generic [ref=e46]:
              - button "Review action" [disabled] [ref=e47]
              - button "Cancel action" [disabled] [ref=e48]
          - navigation "Secondary battle tools" [ref=e49]:
            - button "Inspect party" [ref=e50] [cursor=pointer]
            - button "Battle log" [ref=e51] [cursor=pointer]
            - button "Enable sound" [ref=e52] [cursor=pointer]
          - paragraph [ref=e53]: Sound off
        - generic [ref=e54]:
          - status [ref=e55]: Battle ready
          - button "Restart battle" [active] [ref=e56] [cursor=pointer]
        - generic [ref=e57]:
          - generic [ref=e58]: Battle saved on this device
          - button "Save recovery" [ref=e59] [cursor=pointer]
        - paragraph [ref=e60]: "Gold: active · White: selected · Teal: reachable · Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Play three-encounter run" [ref=e61] [cursor=pointer]:
          - /url: /run
        - group [ref=e62]:
          - generic "Privacy & analytics" [ref=e63] [cursor=pointer]
```

# Test source

```ts
  126 |   const current=await report(page),tile=current.tiles.find((t:any)=>t.x===target.cell.x&&t.y===target.cell.y),point=projectTile(tile);
  127 |   const screen={x:current.transform.x+point.x*current.transform.scale,y:current.transform.y+point.y*current.transform.scale};
  128 |   if(info.project.name.startsWith('mobile'))await page.touchscreen.tap(screen.x,screen.y);
  129 |   else await page.mouse.click(screen.x,screen.y);
  130 |   expect((await report(page)).targets.find((t:any)=>t.selected)).toEqual({cell:target.cell,valid:true,selected:true,reason:null});
  131 |   await page.locator('#battle-review').click();await page.locator('#dialog-cancel').click();
  132 |   expect((await report(page)).targets).toEqual([]);await expect(page.locator('#battle-review')).toBeDisabled();
  133 |   await press(page,'[data-action="signature"]');await page.locator('#battle-target').selectOption(`${target.cell.x},${target.cell.y}`);
  134 |   await press(page,'[data-action="move"]');expect((await report(page)).targets).toEqual([]);
  135 |   await press(page,'[data-action="basic"]');expect((await report(page)).targets.length).toBeGreaterThan(0);
  136 |   await page.locator('#battle-cancel').click();expect((await report(page)).targets).toEqual([]);
  137 |   expect((await readSession(page)).state).toEqual(initial);expect(await stored(page)).toEqual(saved);
  138 |   await press(page,'[data-action="signature"]');await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);
  139 |   expect((await report(page)).targets).toEqual([]);
  140 | });
  141 | function aligned(r:any,fixture:Boundary) {
  142 |   const effect=r.effect;expect(effect).not.toBeNull();
  143 |   for(const [id,point] of [[effect.actorId,effect.from],[effect.targetId,effect.to]] as const){
  144 |     const unit=fixture.before.units.find(u=>u.id===id)!,tile=r.tiles.find((t:any)=>t.x===unit.cell.x && t.y===unit.cell.y);
  145 |     const expected=projectTile(tile);expect(point).toEqual({x:expected.x,y:expected.y-28});
  146 |     expect(r.units.find((u:any)=>u.id===id).anchorError).toBeLessThan(0.001);
  147 |   }
  148 | }
  149 | 
  150 | test('shared corpse cell keeps living target identity through inspection, confirmation and execution',async({page},info)=>{
  151 |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  152 |   const fixture=sharedCellBoundary();expect(fixture.before.commandCount).toBe(64);
  153 |   const target=fixture.before.units.find(u=>u.id===5)!,corpse=fixture.before.units.find(u=>u.id===2)!;
  154 |   expect(target.hp).toBe(5);expect(corpse.hp).toBe(0);expect(corpse.cell).toEqual(target.cell);
  155 |   await boot(page,fixture);
  156 |   await expect(page).toHaveTitle(/Tactics Guru/);await expect(page.locator('vite-error-overlay')).toHaveCount(0);
  157 |   await page.locator('[data-action="basic"]').click();await page.locator('#battle-target').selectOption(`${target.cell.x},${target.cell.y}`);
  158 |   const label='Goblin Archer #5 · HP 5/8',saved=await stored(page),prepared=await page.locator('#game').getAttribute('data-session');
  159 |   expect(JSON.parse(prepared!).pending).toEqual(fixture.command);
  160 |   await expect(page.locator('#battle-target option:checked')).toContainText(label);
  161 |   await expect(page.locator('#battle-target-info')).toHaveText(`Target: ${label}`);
  162 |   await page.locator('#battle-inspect-target').click();await expect(page.locator('#battle-dialog-title')).toHaveText('Inspection only — Goblin Archer #5');
  163 |   await expect(page.locator('#battle-dialog-message')).toContainText('HP 5/8');
  164 |   await page.locator('#inspection-close').click();expect(await page.locator('#game').getAttribute('data-session')).toBe(prepared);expect(await stored(page)).toEqual(saved);
  165 |   // Confirmation must use the prepared command, even if the rendered panel is stale.
  166 |   await page.locator('#battle-target-info').evaluate(el=>{el.textContent='Target: Ranger #2 · Defeated';});
  167 |   await page.locator('#battle-review').click();await expect(page.locator('#battle-dialog-message')).toContainText(`Target: ${label}`);
  168 |   await expect(page.locator('#battle-dialog-message')).not.toContainText('Ranger #2');
  169 |   await page.screenshot({path:info.outputPath('living-target-confirmation.png')});
  170 |   await confirmFrozen(page);
  171 |   const accepted=await readSession(page);expect(accepted.continuation!.commands).toEqual([fixture.command]);
  172 |   expect(accepted.events).toEqual(fixture.events);expect(accepted.state).toEqual(fixture.after);expect(accepted.state.units.find(u=>u.id===corpse.id)!.hp).toBe(0);
  173 |   await page.clock.runFor(700);await ready(page);expect(errors).toEqual([]);
  174 | });
  175 | 
  176 | for(const outcome of ['miss','defeat'] as const)test(`guarded strike ${outcome}: panned-edge actor and target feedback never overlap`,async({page},info)=>{
  177 |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  178 |   const fixture=boundary('guarded_strike',outcome,false,1);
  179 |   if(outcome==='defeat'){expect(fixture.before.seed).toBe(1);expect(fixture.before.commandCount).toBe(73);}
  180 |   await page.setViewportSize({width:320,height:568});await boot(page,fixture);
  181 |   const r=(await report(page)).region;
  182 |   const drag=async(dx:number,dy:number)=>{
  183 |     const x=r.x+r.width*(dx>0?.1:dx<0?.9:.5),y=r.y+r.height*(dy>0?.1:dy<0?.9:.5);
  184 |     await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+dx*r.width*.8,y+dy*r.height*.8,{steps:8});await page.mouse.up();
  185 |   };
  186 |   // Reproduce the review: pan before the command, with no mid-animation gesture.
  187 |   await drag(0,-1);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(288);
  188 |   const saved=await stored(page);
  189 |   const check=async()=>{
  190 |     const frame=await report(page),labels=frame.feedbackBounds;
  191 |     expect(labels.map((b:any)=>b.text)).toEqual(abilityPresentation(fixture.events).feedback.map(f=>f.text));
  192 |     expect(labels).toHaveLength(outcome==='defeat'?3:2);
  193 |     for(const a of labels){
  194 |       expect(a.x).toBeGreaterThanOrEqual(frame.region.x);expect(a.y).toBeGreaterThanOrEqual(frame.region.y);
  195 |       expect(a.x+a.width).toBeLessThanOrEqual(frame.region.x+frame.region.width);expect(a.y+a.height).toBeLessThanOrEqual(frame.region.y+frame.region.height);
  196 |     }
  197 |     for(let i=0;i<labels.length;i++)for(let j=i+1;j<labels.length;j++){
  198 |       const a=labels[i],b=labels[j];expect(a.x+a.width<=b.x || b.x+b.width<=a.x || a.y+a.height<=b.y || b.y+b.height<=a.y,`${a.text} overlaps ${b.text}`).toBe(true);
  199 |     }
  200 |     expect((await readSession(page)).state).toEqual(fixture.after);expect(await stored(page)).toEqual(saved);
  201 |   };
  202 |   await check();await page.screenshot({path:info.outputPath(`guarded-${outcome}-prepan.png`)});
  203 |   // Re-layout at the other edges, maximum zoom and an actual viewport change.
  204 |   for(const [dx,dy] of [[0,1],[-1,0],[1,0],[0,-1]]){await drag(dx,dy);await check();}
  205 |   await page.mouse.move(r.x+r.width/2,r.y+r.height/2);await page.mouse.wheel(0,-3000);await drag(0,-1);await check();
  206 |   await page.setViewportSize({width:568,height:320});await page.clock.runFor(32);await check();
  207 |   await page.clock.runFor(700);await ready(page);expect(errors).toEqual([]);
  208 | });
  209 | 
  210 | for(const kind of kinds)test(`${kind}: real controls, travel/impact, transformed anchors and exactly one accepted result`,async({page},info)=>{
  211 |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  212 |   const fixture=boundary(kind),keyboard=kind==='magic_missile';await boot(page,fixture);
  213 |   const baseline=(await report(page)).objectCount,savedBefore=await stored(page);
  214 |   // A signature aimed at its own actor must remain a rejected preview, with no cue or save.
  215 |   await press(page,'[data-action="signature"]',keyboard);await page.locator('canvas').focus();await page.keyboard.press('Enter');
  216 |   await expect(page.locator('#battle-preview')).toContainText('Unavailable');await expect(page.locator('#battle-review')).toBeDisabled();
  217 |   expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.before);expect(await stored(page)).toEqual(savedBefore);
  218 |   await press(page,'#battle-cancel',keyboard);
  219 |   await review(page,fixture,keyboard);await page.keyboard.press('Escape');
  220 |   expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.before);expect(await stored(page)).toEqual(savedBefore);
  221 |   // Transform before the effect through real board gestures.
  222 |   const point=await page.evaluate(()=>{const r=document.querySelector('#battle-board-region')!.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height*0.6};});
  223 |   await page.mouse.move(point.x,point.y);await page.mouse.wheel(0,-80);
  224 |   await review(page,fixture,keyboard);await confirmFrozen(page);
  225 |   const accepted=await readSession(page),saved=await stored(page);
> 226 |   expect(accepted.state).toEqual(fixture.after);expect(accepted.events).toEqual(fixture.events);
      |                                                                         ^ Error: expect(received).toEqual(expected) // deep equality
  227 |   expect(accepted.continuation!.commands).toEqual([fixture.command]);
  228 |   const expected=dispatch(fixture.before,fixture.command,catalog);expect(expected.ok).toBe(true);
  229 |   if(expected.ok)expect(accepted.state).toEqual(expected.state);
  230 |   // Exercise board input during the lock. Fresh keys on the usable Restart
  231 |   // fallback intentionally open/confirm reset; held-key capture has its own regression.
  232 |   await expect(page.locator('#fit-restart')).toBeFocused();await page.locator('canvas').focus();
  233 |   await page.keyboard.press('Enter');await page.keyboard.press('Space');
  234 |   await expect(page.locator('#battle-next')).toBeDisabled();await expect(page.locator('[data-action="signature"]')).toBeDisabled();
  235 |   await page.clock.runFor(112);const travel=await report(page);aligned(travel,fixture);
  236 |   expect(travel.effect.progress).toBeGreaterThan(0);expect(travel.effect.progress).toBeLessThan(0.45);
  237 |   await page.screenshot({path:info.outputPath(`${kind}-travel.png`)});
  238 |   // Pan/zoom during flight without changing the accepted simulation.
  239 |   await page.mouse.move(point.x,point.y);await page.mouse.down();await page.mouse.move(point.x+25,point.y-15,{steps:3});await page.mouse.up();
  240 |   await page.mouse.wheel(0,-50);await page.clock.runFor(176);
  241 |   const impact=await report(page);aligned(impact,fixture);expect(impact.transform).not.toEqual(travel.transform);
  242 |   expect(impact.effect.progress).toBeGreaterThanOrEqual(0.45);
  243 |   expect(impact.effect.feedback.filter((f:any)=>f.visible).map((f:any)=>({unitId:f.unitId,text:f.text})))
  244 |     .toEqual(abilityPresentation(fixture.events).feedback.map(f=>({unitId:f.unitId,text:f.text})));
  245 |   await page.screenshot({path:info.outputPath(`${kind}-impact.png`)});
  246 |   const capture=(r:any)=>({viewport:r.viewport,transform:r.transform,effect:r.effect,
  247 |     units:r.units.filter((u:any)=>u.id===r.effect.actorId || u.id===r.effect.targetId),objectCount:r.objectCount});
  248 |   writeFileSync(info.outputPath('animation.json'),JSON.stringify({viewport:page.viewportSize(),fixture,travel:capture(travel),impact:capture(impact)},null,2));
  249 |   expect((await readSession(page)).state).toEqual(accepted.state);expect(await stored(page)).toEqual(saved);
  250 |   await page.clock.runFor(500);await ready(page);
  251 |   expect((await report(page)).effect).toBeNull();expect((await report(page)).objectCount).toBe(baseline);
  252 |   expect((await readSession(page)).state).toEqual(fixture.after);expect(await stored(page)).toEqual(saved);expect(errors).toEqual([]);
  253 | });
  254 | 
  255 | for(const [kind,outcome] of [['guarded_strike','miss'],['high_shot','miss'],['high_shot','critical'],['magic_missile','defeat']] as const)
  256 | test(`${kind}: ${outcome} feedback matches resolved events`,async({page},info)=>{
  257 |   const fixture=boundary(kind,outcome);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(288);
  258 |   const r=await report(page);aligned(r,fixture);
  259 |   const feedback=abilityPresentation(fixture.events).feedback;
  260 |   expect(r.effect.feedback.map((f:any)=>({unitId:f.unitId,text:f.text}))).toEqual(feedback.map(f=>({unitId:f.unitId,text:f.text})));
  261 |   expect(r.effect.feedback.every((f:any)=>f.visible)).toBe(true);
  262 |   if(outcome==='miss'){expect(feedback.some(f=>f.text==='Miss')).toBe(true);expect(feedback.some(f=>f.text.includes('−'))).toBe(false);}
  263 |   if(kind==='guarded_strike')expect(feedback).toContainEqual({unitId:r.effect.actorId,kind:'guard',text:'Guarded'});
  264 |   const positions=r.effect.feedback.map((f:any)=>`${f.x},${f.y}`);expect(new Set(positions).size).toBe(positions.length);
  265 |   await page.screenshot({path:info.outputPath(`${kind}-${outcome}.png`)});await page.clock.runFor(500);
  266 |   expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.after);
  267 | });
  268 | 
  269 | for(const kind of kinds)test(`${kind}: repeated cancellation, modal refresh, resize and restart during travel and impact`,async({page})=>{
  270 |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  271 |   const fixture=boundary(kind);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(96);
  272 |   const saved=await stored(page);
  273 |   await page.locator('#fit-restart').click({force:true});await page.locator('#save-cancel-reset').click({force:true});
  274 |   aligned(await report(page),fixture);
  275 |   const size=page.viewportSize()!;await page.setViewportSize({width:size.height,height:size.width});await page.clock.runFor(64);
  276 |   aligned(await report(page),fixture);
  277 |   await page.evaluate(()=>{
  278 |     Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});
  279 |     for(let i=0;i<3;i++)document.dispatchEvent(new Event('visibilitychange'));
  280 |   });
  281 |   await ready(page);expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.after);expect(await stored(page)).toEqual(saved);
  282 |   await page.evaluate(()=>{delete (document as unknown as {hidden?:boolean}).hidden;document.dispatchEvent(new Event('visibilitychange'));});
  283 |   await page.clock.runFor(700);expect((await readSession(page)).state).toEqual(fixture.after);
  284 |   // Restore only this known legal boundary via the real persisted-save startup for each teardown phase.
  285 |   for(const time of [96,288]){
  286 |     const encoded=encodeBattleSave(fixture.before,catalog);if(!encoded.ok)throw Error(encoded.reason);
  287 |     await page.evaluate(({keys,text})=>{localStorage.setItem(keys.primary,text);localStorage.setItem(keys.backup,text);},{keys,text:encoded.text});
  288 |     await page.reload();await page.clock.resume();await page.locator('#save-continue').click();await ready(page);
  289 |     await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(time);
  290 |     await page.locator('#fit-restart').click({force:true});await confirmRestart(page,true);await page.clock.resume();await ready(page);
  291 |     expect((await readSession(page)).state.seed).toBe(fixture.before.seed+1);expect((await report(page)).effect).toBeNull();
  292 |     await expect(page.locator('canvas')).toHaveCount(1);
  293 |   }
  294 |   expect(errors).toEqual([]);
  295 | });
  296 | 
  297 | for(const kind of kinds)test(`${kind}: reload resumes accepted save without historical effects`,async({page})=>{
  298 |   const fixture=boundary(kind);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(112);
  299 |   const saved=await stored(page);await page.reload();await page.clock.resume();await expect(page.locator('#save-continue')).toBeVisible();
  300 |   expect(await stored(page)).toEqual(saved);await page.locator('#save-continue').click();await ready(page);
  301 |   expect((await readSession(page)).state).toEqual(fixture.after);expect((await readSession(page)).events).toEqual([]);
  302 |   expect((await report(page)).effect).toBeNull();expect(await stored(page)).toEqual(saved);
  303 | });
  304 | 
  305 | test('elevated target remains anchored through rotation during impact',async({page},info)=>{
  306 |   const fixture=boundary('high_shot','any',true);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);
  307 |   await page.clock.runFor(288);const before=await report(page);aligned(before,fixture);
  308 |   const unit=fixture.before.units.find(u=>u.id===before.effect.targetId)!;
  309 |   expect(before.tiles.find((t:any)=>t.x===unit.cell.x && t.y===unit.cell.y).elevation).toBeGreaterThan(0);
  310 |   const size=page.viewportSize()!,rotated={width:size.height,height:size.width};
  311 |   // Native resize delivery is independent of the paused animation clock. Wait
  312 |   // for that event before advancing Phaser's resize/presentation callbacks.
  313 |   await page.evaluate(()=>window.addEventListener('resize',()=>{document.documentElement.dataset.impactResize='observed';},{once:true}));
  314 |   await page.setViewportSize(rotated);
  315 |   await expect(page.locator('html')).toHaveAttribute('data-impact-resize','observed');
  316 |   await page.clock.runFor(64);
  317 |   const after=await report(page);aligned(after,fixture);expect(after.viewport).toEqual(rotated);
  318 |   await page.screenshot({path:info.outputPath('elevated-rotated-impact.png')});
  319 |   await page.clock.runFor(500);expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.after);
  320 | });
  321 | 
  322 | test.describe('ability departure through real browser history',()=>{
  323 |   for(const kind of kinds)test(`${kind}: cached return preserves exact accepted slots until Continue`,async({page,baseURL})=>{
  324 |     const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  325 |     await page.addInitScript(()=>window.addEventListener('pageshow',event=>{if(event.persisted)sessionStorage.setItem('test:animation-cached-return','yes');}));
  326 |     const fixture=boundary(kind);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(112);
```
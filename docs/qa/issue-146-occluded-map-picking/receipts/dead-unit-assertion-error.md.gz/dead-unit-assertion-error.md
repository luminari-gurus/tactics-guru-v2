# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-board.spec.ts >> occluded archer exposed art selects the same legal target as the dropdown
- Location: tests\battle-board.spec.ts:37:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 2

  Object {
-   "elevation": 0,
+   "elevation": 1,
    "x": 3,
-   "y": 8,
+   "y": 9,
  }
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · ✓ valid target · × unavailable · Double outline: selected · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Battle controls" [ref=e8]:
      - generic "Acting unit information; scroll for details" [ref=e9]:
        - paragraph [ref=e10]: Round 2 · Your turn
        - generic [ref=e11]:
          - img "Fighter portrait" [ref=e13]
          - generic [ref=e14]:
            - heading "Fighter" [level=2] [ref=e15]
            - paragraph [ref=e16]: HP 14/18
            - paragraph [ref=e19]: AC 14 · Accuracy +4
            - paragraph [ref=e20]: No status effects
        - paragraph [ref=e21]: Move spent / Action ready
      - generic "Actions, target and secondary tools; scroll for more" [ref=e22]:
        - generic [ref=e23]:
          - paragraph [ref=e24]: Choose your action
          - generic "Acting unit actions" [ref=e25]:
            - button "Move" [disabled] [ref=e26]:
              - strong [ref=e27]: Move
              - generic [ref=e28]: Spent
            - button "Basic attack" [ref=e29] [cursor=pointer]:
              - strong [ref=e30]: Basic attack
              - generic [ref=e31]: Uses action
            - button "Guarded Strike" [active] [pressed] [ref=e32] [cursor=pointer]:
              - strong [ref=e33]: Guarded Strike
              - generic [ref=e34]: Uses action
            - button "Wait / End turn" [ref=e35] [cursor=pointer]:
              - strong [ref=e36]: Wait / End turn
              - generic [ref=e37]: Ends turn immediately
          - paragraph [ref=e38]: Movement spent. Choose an action, then a target. Wait ends the turn immediately.
          - region "Target and action preview" [ref=e39]:
            - generic [ref=e40]: Target / destination
            - combobox "Target / destination" [ref=e41]:
              - option "Choose target"
              - 'option "Goblin Grunt #4 · HP 3/9"'
              - 'option "Goblin Archer #5 · HP 8/8"'
            - paragraph [ref=e42]: Selected (3, 9)
            - paragraph [ref=e43]: "Target: Mage #3 · HP 3/11"
            - button "Inspect target" [ref=e44] [cursor=pointer]
            - paragraph [ref=e45]: "Unavailable: Same Side · range 1–1 · −2 attack / +2 AC until your next turn"
            - generic [ref=e46]:
              - button "Review action" [disabled] [ref=e47]
              - button "Cancel action" [ref=e48] [cursor=pointer]
          - navigation "Secondary battle tools" [ref=e49]:
            - button "Inspect party" [ref=e50] [cursor=pointer]
            - button "Battle log" [ref=e51] [cursor=pointer]
            - button "Enable sound" [ref=e52] [cursor=pointer]
          - paragraph [ref=e53]: Sound off
        - generic [ref=e54]:
          - status [ref=e55]: Battle ready
          - button "Restart battle" [ref=e56] [cursor=pointer]
        - generic [ref=e57]:
          - generic [ref=e58]: Continued saved battle
          - button "Save recovery" [ref=e59] [cursor=pointer]
        - paragraph [ref=e60]: "Gold: active · White: selected · Teal: reachable · Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Play three-encounter run" [ref=e61] [cursor=pointer]:
          - /url: /run
```

# Test source

```ts
  1   | import { confirmRestart } from './helpers/battlePolicy';
  2   | import { expect, test, type Page } from '@playwright/test';
  3   | import { battleCatalog } from '../src/content/catalog';
  4   | import { buildBoardPresentation } from '../src/geometry/boardPresentation';
  5   | import { MAX_ZOOM, pickTile, screenToBoard } from '../src/geometry/picking';
  6   | import { fitBoard, projectTile, tileFaces, type Point } from '../src/geometry/iso';
  7   | import { BattleSession } from '../src/app/BattleSession';
  8   | import { hoverPreview } from '../src/ui/targetPreview';
  9   | import { encodeBattleSave } from '../src/domain/saveEnvelope';
  10  | import { BATTLE_STORAGE_KEYS } from '../src/persistence/battleStorage';
  11  | import { playerDecision } from './helpers/playerPolicy';
  12  | import { unitBounds } from '../src/geometry/canopy';
  13  | 
  14  | /** Real accepted seed-1 boundaries, using the same policy as battle/save coverage. */
  15  | async function occlusionBoundary(page: Page, count: number) {
  16  |   const session = new BattleSession(battleCatalog, 'map:forest_ruins', 1);
  17  |   while (session.state.commandCount < count) {
  18  |     if (session.phase === 'player') expect(session.prepare(playerDecision(session.state)).ok).toBe(true);
  19  |     const step = session.phase === 'player' ? session.confirm() : session.nextEnemy();
  20  |     if (!step) throw Error('Occlusion fixture failed to progress');
  21  |     session.finishPresentation(step.token);
  22  |   }
  23  |   expect(session.phase).toBe('player');
  24  |   const save = encodeBattleSave(session.state, battleCatalog);
  25  |   if (!save.ok) throw Error(save.reason);
  26  |   await page.addInitScript(({key, text}) => localStorage.setItem(key, text), {key:BATTLE_STORAGE_KEYS.primary, text:save.text});
  27  |   await page.goto('/'); await page.locator('#save-continue').click();
  28  |   await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player');
  29  |   await expect(page).toHaveTitle('Tactics Guru v2');
  30  |   await expect(page.locator('#battle-shell')).toBeVisible();
  31  |   await expect(page.locator('vite-error-overlay')).toHaveCount(0);
  32  |   return session.state;
  33  | }
  34  | 
  35  | async function boardClick(page:Page, point:Point, touch=false) {
  36  |   const r=await settledReport(page),x=r.transform.x+point.x*r.transform.scale,y=r.transform.y+point.y*r.transform.scale;
  37  |   if(touch) await page.touchscreen.tap(x,y); else await page.mouse.click(x,y);
  38  | }
  39  | 
  40  | test('occluded archer exposed art selects the same legal target as the dropdown',async({page},info)=>{
  41  |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  42  |   page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  43  |   const state=await occlusionBoundary(page,28);
  44  |   expect(state.units.find(u=>u.id===5)).toMatchObject({defId:'goblin_archer',cell:{x:3,y:2},hp:8});
  45  |   await page.locator('[data-action=signature]').click();
  46  |   await page.locator('#battle-target').selectOption('3,2');
  47  |   const expected=JSON.parse((await page.locator('#game').getAttribute('data-session'))!);
  48  |   expect(expected.pending).toMatchObject({type:'useAbility',target:{unitId:5}});
  49  |   const preview=await page.locator('#battle-preview').textContent(),saved=await page.evaluate(()=>JSON.stringify(localStorage));
  50  |   await page.screenshot({path:info.outputPath('occluded-archer-dropdown.png')});
  51  |   // Opaque head pixel (32,18) in the canonical 64x80 sprite, anchored at (32,76).
  52  |   // Projected ground center is (40,100); displayed sprite is 40x50.
  53  |   await boardClick(page,{x:40,y:63.75},!!info.project.use.hasTouch);
  54  |   expect((await report(page)).selected).toEqual({x:3,y:2,elevation:0});
  55  |   expect(await page.locator('#battle-preview').textContent()).toBe(preview);
  56  |   expect(JSON.parse((await page.locator('#game').getAttribute('data-session'))!)).toEqual(expected);
  57  |   expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(saved);
  58  |   await page.screenshot({path:info.outputPath('occluded-archer-map.png')});
  59  |   // The body under solid foreground terrain cannot steal the first hit.
  60  |   await boardClick(page,{x:40,y:100},!!info.project.use.hasTouch);
  61  |   expect((await report(page)).selected).toEqual({x:4,y:3,elevation:2});
  62  |   // Transparent pixels in the same sprite rectangle still reach terrain.
  63  |   await boardClick(page,{x:21,y:54},!!info.project.use.hasTouch);
  64  |   expect((await report(page)).selected).toEqual({x:2,y:1,elevation:0});
  65  |   // A visible distant grunt remains unavailable; art picking cannot grant range.
  66  |   await page.locator('#battle-target').selectOption('4,6');
  67  |   const unavailable=await page.locator('#battle-preview').textContent();
  68  |   expect(unavailable).toContain('Unavailable');
  69  |   const invalid=await page.locator('#game').getAttribute('data-session');
  70  |   await boardClick(page,{x:-80,y:163.75},!!info.project.use.hasTouch);
> 71  |   expect((await report(page)).selected).toEqual({x:4,y:6,elevation:0});
      |                                         ^ Error: expect(received).toEqual(expected) // deep equality
  72  |   expect(await page.locator('#battle-preview').textContent()).toBe(unavailable);
  73  |   expect(await page.locator('#game').getAttribute('data-session')).toBe(invalid);
  74  |   expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(saved);
  75  |   expect(state.units.find(u=>u.id===6)?.hp).toBe(0);
  76  |   // The defeated grunt's former head overlaps ground (3,8), never a dead target.
  77  |   await boardClick(page,{x:-200,y:223.75},!!info.project.use.hasTouch);
  78  |   expect((await report(page)).selected).toEqual({x:3,y:8,elevation:0});
  79  |   expect(errors).toEqual([]);
  80  | });
  81  | 
  82  | test('repeated map selection reaches a legal ground destination behind the same platform',async({page},info)=>{
  83  |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  84  |   page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  85  |   await occlusionBoundary(page,9);
  86  |   await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption('3,5');
  87  |   const expected=JSON.parse((await page.locator('#game').getAttribute('data-session'))!);
  88  |   expect(expected.pending).toMatchObject({type:'move',to:{x:3,y:5}});
  89  |   const preview=await page.locator('#battle-preview').textContent(),saved=await page.evaluate(()=>JSON.stringify(localStorage));
  90  |   const p={x:-77,y:160}; // Inside ground (3,5), clear of touch-rounded diamond edges.
  91  |   await boardClick(page,p,!!info.project.use.hasTouch);
  92  |   expect((await report(page)).selected).toEqual({x:4,y:5,elevation:2});
  93  |   await boardClick(page,p,!!info.project.use.hasTouch);
  94  |   expect((await report(page)).selected).toEqual({x:3,y:5,elevation:0});
  95  |   expect(await page.locator('#battle-preview').textContent()).toBe(preview);
  96  |   expect(JSON.parse((await page.locator('#game').getAttribute('data-session'))!)).toEqual(expected);
  97  |   expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(saved);
  98  |   await page.screenshot({path:info.outputPath('occluded-ground-map.png')});
  99  |   await expect(page.locator('#battle-board-caption')).toContainText('Overlap 2/2');
  100 |   const select=()=>boardClick(page,p,!!info.project.use.hasTouch);
  101 |   // Hover never advances the explicitly selected alternate cell.
  102 |   const r=await settledReport(page);
  103 |   await page.mouse.move(r.transform.x+p.x*r.transform.scale,r.transform.y+p.y*r.transform.scale);
  104 |   expect((await report(page)).selected).toEqual({x:3,y:5,elevation:0});
  105 |   await select();expect((await report(page)).selected).toEqual({x:4,y:5,elevation:2});
  106 |   await select();expect((await report(page)).selected).toEqual({x:3,y:5,elevation:0});
  107 |   await page.locator('#battle-target').selectOption('3,5'); // Native control clears overlap history.
  108 |   await select();expect((await report(page)).selected).toEqual({x:4,y:5,elevation:2});
  109 |   await select();
  110 |   await page.locator('#battle-review').click();
  111 |   const locked=await report(page);await select();expect((await report(page)).selectionEvents).toBe(locked.selectionEvents);
  112 |   await page.locator('#dialog-cancel').click();
  113 |   await select();expect((await report(page)).selected).toEqual({x:4,y:5,elevation:2});
  114 |   await select();await page.locator('canvas').focus();await page.keyboard.press('Enter');
  115 |   expect((await report(page)).selected).toEqual({x:3,y:5,elevation:0});
  116 |   await select();expect((await report(page)).selected).toEqual({x:4,y:5,elevation:2});
  117 |   // Action changes reset the sequence, and a fresh transformed-camera hit still cycles.
  118 |   await page.locator('[data-action=basic]').click();await page.locator('#battle-move').click();
  119 |   await select();expect((await report(page)).selected).toEqual({x:4,y:5,elevation:2});
  120 |   await select();
  121 |   const before=await settledReport(page);
  122 |   await page.mouse.move(before.transform.x+p.x*before.transform.scale,before.transform.y+p.y*before.transform.scale);
  123 |   await page.mouse.wheel(0,-100);await settledReport(page);
  124 |   await select();expect((await report(page)).selected).toEqual({x:4,y:5,elevation:2});
  125 |   await select();expect((await report(page)).selected).toEqual({x:3,y:5,elevation:0});
  126 |   expect(JSON.parse((await page.locator('#game').getAttribute('data-session'))!)).toEqual(expected);
  127 |   expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(saved);
  128 |   // Only explicit confirmation commits the selected legal move.
  129 |   await page.locator('#battle-review').click();await page.locator('#dialog-confirm').click();
  130 |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  131 |   const moved=JSON.parse((await page.locator('#game').getAttribute('data-session'))!).state;
  132 |   expect(moved.commandCount).toBe(expected.state.commandCount+1);
  133 |   expect(moved.units.find((u:any)=>u.id===expected.pending.unitId).cell).toEqual({x:3,y:5});
  134 |   expect(errors).toEqual([]);
  135 | });
  136 | 
  137 | async function report(page: Page) {
  138 |   return JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  139 | }
  140 | 
  141 | async function settledReport(page: Page) {
  142 |   // Let panel layout, ResizeObserver and the next render finish before using coordinates.
  143 |   await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))));
  144 |   return report(page);
  145 | }
  146 | 
  147 | test('hovered origins show only ability reach without changing selection, pending commands or saves',async({page},info)=>{
  148 |   await page.goto('/');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  149 |   const initial=await settledReport(page),before=await page.locator('#game').getAttribute('data-session');
  150 |   const state=JSON.parse(before!).state,origin={x:11,y:11};
  151 |   expect(initial.reachable).not.toContainEqual(origin);
  152 |   const saved=await page.evaluate(()=>JSON.stringify(localStorage));
  153 |   const hover=async(cell:{x:number;y:number})=>{
  154 |     const r=await settledReport(page),tile=r.tiles.find((t:any)=>t.x===cell.x&&t.y===cell.y),p=projectTile(tile);
  155 |     await page.mouse.move(r.transform.x+p.x*r.transform.scale,r.transform.y+p.y*r.transform.scale);
  156 |   };
  157 |   await hover(origin);
  158 |   const expectedHover=hoverPreview(new BattleSession(battleCatalog,state,state.seed),origin);
  159 |   await expect.poll(async()=>(await report(page)).hover).toEqual(expectedHover);
  160 |   expect(expectedHover?.cells).not.toContainEqual(origin);
  161 |   expect((await report(page)).reachable).toEqual(initial.reachable);
  162 |   await expect(page.locator('#battle-board-caption')).toContainText('Purple dots: ability reach');
  163 |   await expect(page.locator('#battle-board-caption')).toContainText('Pink +: target in reach');
  164 |   const shown=await settledReport(page);expect(shown.selected).toBeNull();expect(shown.selectionEvents).toBe(initial.selectionEvents);
  165 |   expect(await page.locator('#game').getAttribute('data-session')).toBe(before);
  166 |   expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(saved);
  167 |   await page.screenshot({path:info.outputPath('hover-movement-range.png')});
  168 |   // Screenshot regression: occupied goblin cells must remain in the preview, including Magic Missile reach.
  169 |   const mageOrigin={x:4,y:8};
  170 |   if(state.units.find((u:any)=>u.id===initial.activeId).defId!=='mage')throw Error('Expected authored opening mage turn');
  171 |   await hover(mageOrigin);
```
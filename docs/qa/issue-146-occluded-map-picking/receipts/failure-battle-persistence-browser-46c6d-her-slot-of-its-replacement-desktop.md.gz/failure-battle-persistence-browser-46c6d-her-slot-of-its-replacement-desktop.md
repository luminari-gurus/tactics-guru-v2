# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-persistence.spec.ts >> browser history with BFCache enabled >> cached battle cannot overwrite either slot of its replacement
- Location: tests\battle-persistence.spec.ts:218:52

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "http://127.0.0.1:4173/?history=first"
Received: null
```

# Page snapshot

```yaml
- generic [ref=f4e1]:
  - main "Tactics Guru game canvas" [ref=f4e2]
  - generic:
    - region "Battlefield":
      - generic [ref=f4e4]:
        - paragraph [ref=f4e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=f4e6]
      - paragraph [ref=f4e7]: "Gold: active · White: selected · Teal: reachable"
    - complementary "Battle controls" [ref=f4e8]:
      - generic "Actions, target and secondary tools; scroll for more" [ref=f4e9]:
        - generic [ref=f4e10]:
          - paragraph
          - generic [ref=f4e11]:
            - button "Move" [disabled] [ref=f4e12]
            - button "Wait / End turn" [disabled] [ref=f4e13]
            - generic [ref=f4e14]: Select a tile
        - generic [ref=f4e15]:
          - status [ref=f4e16]: Battle ready
          - button "Restart battle" [ref=f4e17] [cursor=pointer]
        - generic [ref=f4e18]:
          - generic [ref=f4e19]: Saved battle found. Choose Continue or New battle.
          - button "Save recovery" [ref=f4e20] [cursor=pointer]
        - paragraph [ref=f4e21]: "Gold: active · White: selected · Teal: reachable · Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Play three-encounter run" [ref=f4e22] [cursor=pointer]:
          - /url: /run
  - dialog [ref=f4e23]:
    - heading "Saved battle" [level=2] [ref=f4e24]
    - generic [ref=f4e25]: "Saved battle found. Choose Continue or New battle. Primary: valid. Backup: valid. Saves stay in this browser on this site. Use one battle tab; browser cleanup can remove them."
    - generic [ref=f4e26]:
      - button "Continue" [active] [ref=f4e27] [cursor=pointer]
      - button "New battle" [ref=f4e28] [cursor=pointer]
      - button "Export recovery data" [ref=f4e29] [cursor=pointer]
      - button "Remove primary save" [ref=f4e30] [cursor=pointer]
      - button "Remove backup save" [ref=f4e31] [cursor=pointer]
      - button "Retry storage" [ref=f4e32] [cursor=pointer]
```

# Test source

```ts
  131 |   expect(exported.slots).toEqual(expect.arrayContaining([{slot:'primary',text:broken},{slot:'backup',text:snapshot}]));
  132 |   await page.locator('#save-continue').click();await ready(page);await expect(page.locator('#battle-save-status')).toContainText('unsaved');
  133 |   const before=(await readSession(page)).state.commandCount;await playCommand(page,playerDecision((await readSession(page)).state));await ready(page);
  134 |   expect((await readSession(page)).state.commandCount).toBeGreaterThan(before);expect((await stored(page)).primary).toBe(broken);
  135 |   await page.locator('#battle-recovery').click();await page.locator('#save-remove-primary').click();await page.locator('#save-cancel-remove').click();
  136 |   expect((await stored(page)).primary).toBe(broken);
  137 |   await page.locator('#save-remove-primary').click();await page.locator('#save-confirm-remove').click();
  138 |   expect((await stored(page)).primary).toBeNull();await page.locator('#save-retry').click();await page.locator('#save-close').click();
  139 |   await expect(page.locator('#battle-save-status')).toContainText('Battle saved');
  140 |   const decoded=decodeBattleSave((await stored(page)).primary!,catalog);expect(decoded.ok).toBe(true);if(decoded.ok)expect(decoded.state).toEqual((await readSession(page)).state);
  141 |   expect(await page.evaluate(()=>localStorage.getItem('unrelated'))).toBe('keep');
  142 | });
  143 | 
  144 | test('unknown storage blocks startup until retry; writes remain nonfatal during play',async({page})=>{
  145 |   await page.addInitScript(()=>{
  146 |     const get=Storage.prototype.getItem,set=Storage.prototype.setItem;
  147 |     Object.assign(window,{denyRead:true,denyWrite:false});
  148 |     Storage.prototype.getItem=function(key){if((window as any).denyRead && key.startsWith('tactics-guru:phaser:'))throw new DOMException('Denied','SecurityError');return get.call(this,key);};
  149 |     Storage.prototype.setItem=function(key,value){if((window as any).denyWrite && key.startsWith('tactics-guru:phaser:'))throw new DOMException('Full','QuotaExceededError');return set.call(this,key,value);};
  150 |   });
  151 |   await page.goto('/');await expect(page.getByRole('dialog')).toContainText('unreadable');expect(await page.locator('#game').getAttribute('data-session')).toBeNull();
  152 |   await page.locator('#save-new').click();await page.locator('#save-confirm-reset').click();
  153 |   await expect(page.getByRole('dialog')).toContainText('Reset incomplete');expect(await page.locator('#game').getAttribute('data-session')).toBeNull();
  154 |   await page.evaluate(()=>Object.assign(window,{denyRead:false,denyWrite:true}));await page.locator('#save-retry').click();await ready(page);
  155 |   await expect(page.locator('#battle-save-status')).toContainText('unsaved');
  156 |   const before=(await readSession(page)).state.commandCount;await page.locator('#battle-next').click();await ready(page);
  157 |   expect((await readSession(page)).state.commandCount).toBeGreaterThan(before);
  158 |   await page.evaluate(()=>Object.assign(window,{denyWrite:false}));await page.locator('#battle-recovery').click();await page.locator('#save-retry').click();await page.locator('#save-close').click();
  159 |   await expect(page.locator('#battle-save-status')).toContainText('Battle saved');
  160 | });
  161 | 
  162 | test('failed partial reset retains battle, seed, recovery copies and usable controls; a retry succeeds once',async({page})=>{
  163 |   await seedTwo(page);const before=await readSession(page),old=await stored(page);
  164 |   await page.evaluate(keys=>{
  165 |     const remove=Storage.prototype.removeItem;
  166 |     Storage.prototype.removeItem=function(key){if(key===keys.primary)throw new DOMException('Denied','SecurityError');return remove.call(this,key);};
  167 |     Object.assign(window,{restoreRemove:()=>{Storage.prototype.removeItem=remove;}});
  168 |   },keys);
  169 |   await page.locator('#fit-restart').click();await page.locator('#save-confirm-reset').click();
  170 |   await expect(page.getByRole('dialog')).toContainText('Reset incomplete');expect((await readSession(page)).state).toEqual(before.state);
  171 |   expect((await stored(page)).backup).toBeNull();expect((await stored(page)).primary).toBe(old.primary);
  172 |   const downloadEvent=page.waitForEvent('download');await page.locator('#save-export').click();const download=await downloadEvent;
  173 |   expect(JSON.parse(readFileSync((await download.path())!,'utf8')).slots).toEqual(expect.arrayContaining([{slot:'primary',text:old.primary},{slot:'backup',text:old.backup}]));
  174 |   await page.locator('#save-close').click();await expect(page.locator('#fit-restart')).toBeEnabled();await expect(page.locator('#fit-status')).toHaveText('Battle ready');
  175 |   await page.evaluate(()=>(window as any).restoreRemove());await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);
  176 |   expect((await readSession(page)).state.seed).toBe(3);await expect(page.locator('canvas')).toHaveCount(1);
  177 |   await page.reload();await page.locator('#save-continue').click();await ready(page);expect((await readSession(page)).state.seed).toBe(3);
  178 | });
  179 | 
  180 | test('changed saved data refuses an old confirmation and requires fresh review',async({page})=>{
  181 |   await seedTwo(page);await page.locator('#fit-restart').click();
  182 |   await page.evaluate(keys=>localStorage.setItem(keys.primary,'changed'),keys);
  183 |   await page.locator('#save-confirm-reset').click();await expect(page.getByRole('dialog')).toContainText('Reset incomplete');
  184 |   expect((await stored(page)).primary).toBe('changed');expect((await readSession(page)).state.seed).toBe(2);
  185 |   await page.locator('#save-close').click();await page.locator('#fit-restart').click();await page.locator('#save-cancel-reset').click();
  186 |   expect((await stored(page)).primary).toBe('changed');await expect(page.locator('#fit-restart')).toBeFocused();
  187 | });
  188 | 
  189 | test('successful reset with failed fresh save cannot recover an old battle on reload',async({page})=>{
  190 |   await seedTwo(page);
  191 |   await page.evaluate(()=>{
  192 |     const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('tactics-guru:phaser:'))throw new DOMException('Full','QuotaExceededError');return set.call(this,key,value);};
  193 |   });
  194 |   await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);expect((await readSession(page)).state.seed).toBe(3);
  195 |   expect(await stored(page)).toEqual({primary:null,backup:null});await expect(page.locator('#battle-save-status')).toContainText('unsaved');
  196 |   await page.reload();await ready(page);expect((await readSession(page)).state.seed).toBe(1);await expect(page.getByRole('dialog')).not.toBeVisible();
  197 | });
  198 | 
  199 | for(const invalid of ['{broken',JSON.stringify({kind:'tactics-guru:battle-snapshot',format:99,payload:{},digest:'sha256:'+'0'.repeat(64)})])test(`invalid startup requires explicit reset: ${invalid.slice(0,12)}`,async({page})=>{
  200 |   await page.goto('/?scene=proof');await page.evaluate(({keys,invalid})=>localStorage.setItem(keys.primary,invalid),{keys,invalid});
  201 |   await page.goto('/');await expect(page.getByRole('dialog')).toContainText('needs recovery');await expect(page.locator('#save-continue')).toHaveCount(0);
  202 |   if(invalid.includes('"format":99'))await expect(page.getByRole('dialog')).toContainText('incompatible');
  203 |   expect((await stored(page)).primary).toBe(invalid);await page.locator('#save-new').click();
  204 |   await expect(page.locator('#save-confirm-reset')).toBeFocused();
  205 |   await page.locator('#save-cancel-reset').click();
  206 |   await expect(page.locator('#save-new')).toBeFocused();
  207 |   expect((await stored(page)).primary).toBe(invalid);await page.locator('#save-new').click();await page.locator('#save-confirm-reset').click();await ready(page);
  208 |   expect((await readSession(page)).state.seed).toBe(1);expect((await stored(page)).primary).not.toBe(invalid);
  209 | });
  210 | 
  211 | test.describe('browser history with BFCache enabled',()=>{
  212 |   test.beforeEach(async({page})=>{
  213 |     await page.addInitScript(()=>window.addEventListener('pageshow',event=>{
  214 |       if(event.persisted)sessionStorage.setItem('test:bfcache-return',location.href);
  215 |     }));
  216 |   });
  217 | 
  218 |   for(const cached of ['battle','recovery dialog'])test(`cached ${cached} cannot overwrite either slot of its replacement`,async({page,baseURL})=>{
  219 |     const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  220 |     const first=new URL('./?history=first',baseURL).href,map=new URL('map',baseURL).href;
  221 |     await page.goto(first);await ready(page);
  222 |     expect((await readSession(page)).state.seed).toBe(1);
  223 |     if(cached==='recovery dialog'){await page.reload();await expect(page.locator('#save-continue')).toBeVisible();}
  224 |     await page.goto(map);await expect(page.locator('#map-grid span')).toHaveCount(400);await page.goto(baseURL!);
  225 |     await page.locator('#save-new').click();await page.locator('#save-confirm-reset').click();await ready(page);
  226 |     const replacement=await readSession(page),saved=await stored(page);
  227 |     expect(replacement.state.seed).toBe(2);
  228 |     await page.goBack({waitUntil:'commit'});await expect(page).toHaveURL(map);
  229 |     await page.goBack({waitUntil:'commit'});
  230 |     await expect(page.locator('#save-continue')).toBeVisible();
> 231 |     expect(await page.evaluate(()=>sessionStorage.getItem('test:bfcache-return'))).toBe(first);
      |                                                                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  232 |     expect(await stored(page)).toEqual(saved);
  233 |     expect(await page.locator('#game').getAttribute('data-session')).toBeNull();
  234 |     await page.screenshot({path:test.info().outputPath('cached-return-recovery.png')});
  235 |     await page.locator('#save-continue').click();await ready(page);
  236 |     expect((await readSession(page)).state).toEqual(replacement.state);
  237 |     expect(await stored(page)).toEqual(saved);
  238 |     await page.locator('#battle-next').click();await ready(page);
  239 |     const after=await stored(page);
  240 |     for(const text of [after.primary,after.backup]){
  241 |       const decoded=decodeBattleSave(text!,catalog);expect(decoded.ok).toBe(true);
  242 |       if(decoded.ok)expect(decoded.state.seed).toBe(2);
  243 |     }
  244 |     expect(errors).toEqual([]);
  245 |   });
  246 | 
  247 |   for(const departure of ['player','presentation'])test(`cached return after restart at ${departure} preserves the accepted boundary`,async({page,baseURL})=>{
  248 |     const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  249 |     const first=new URL('./?history=first',baseURL).href,map=new URL('map',baseURL).href;
  250 |     await page.goto(first);await ready(page);
  251 |     await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);
  252 |     // Observe the last accepted boundary before the application's pagehide shutdown.
  253 |     await page.evaluate(keys=>window.addEventListener('pagehide',()=>{
  254 |       sessionStorage.setItem('test:departure',JSON.stringify({
  255 |         primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup),
  256 |       }));
  257 |     },{capture:true,once:true}),keys);
  258 |     if(departure==='presentation'){
  259 |       await page.evaluate(map=>{
  260 |         document.querySelector<HTMLButtonElement>('#battle-next')!.click();
  261 |         sessionStorage.setItem('test:departure-phase',document.querySelector<HTMLElement>('#game')!.dataset.phase!);
  262 |         location.assign(map);
  263 |       },map);
  264 |       await expect(page).toHaveURL(map);
  265 |       expect(await page.evaluate(()=>sessionStorage.getItem('test:departure-phase'))).toBe('presenting');
  266 |     }else await page.goto(map);
  267 |     await expect(page.locator('#map-grid span')).toHaveCount(400);
  268 |     const saved=JSON.parse((await page.evaluate(()=>sessionStorage.getItem('test:departure')))!);
  269 |     expect(await stored(page)).toEqual(saved);
  270 |     await page.goBack({waitUntil:'commit'});
  271 |     await expect(page.locator('#save-continue')).toBeVisible();
  272 |     expect(await page.evaluate(()=>sessionStorage.getItem('test:bfcache-return'))).toBe(first);
  273 |     expect(await stored(page)).toEqual(saved);
  274 |     await page.locator('#save-continue').click();await ready(page);
  275 |     const continued=await readSession(page),decoded=decodeBattleSave(saved.primary,catalog);
  276 |     expect(decoded.ok).toBe(true);
  277 |     if(decoded.ok)expect(continued.continuation!.snapshot).toEqual(decoded.state);
  278 |     expect(continued.state.seed).toBe(2);
  279 |     if(departure==='player'){expect(await stored(page)).toEqual(saved);expect(continued.events).toEqual([]);}
  280 |     await page.screenshot({path:test.info().outputPath(`continued-${departure}.png`)});
  281 |     expect(errors).toEqual([]);
  282 |   });
  283 | });
  284 | 
```
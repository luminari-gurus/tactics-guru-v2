# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-persistence.spec.ts >> browser history with BFCache enabled >> cached return after restart at player preserves the accepted boundary
- Location: tests\battle-persistence.spec.ts:247:52

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "http://127.0.0.1:4173/?history=first"
Received: null
```

# Page snapshot

```yaml
- generic [ref=f2e1]:
  - main "Tactics Guru game canvas" [ref=f2e2]
  - generic:
    - region "Battlefield":
      - generic [ref=f2e4]:
        - paragraph [ref=f2e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=f2e6]
      - paragraph [ref=f2e7]: "Gold: active · White: selected · Teal: reachable"
    - complementary "Battle controls" [ref=f2e8]:
      - generic "Actions, target and secondary tools; scroll for more" [ref=f2e9]:
        - generic [ref=f2e10]:
          - paragraph
          - generic [ref=f2e11]:
            - button "Move" [disabled] [ref=f2e12]
            - button "Wait / End turn" [disabled] [ref=f2e13]
            - generic [ref=f2e14]: Select a tile
        - generic [ref=f2e15]:
          - status [ref=f2e16]: Battle ready
          - button "Restart battle" [ref=f2e17] [cursor=pointer]
        - generic [ref=f2e18]:
          - generic [ref=f2e19]: Saved battle found. Choose Continue or New battle.
          - button "Save recovery" [ref=f2e20] [cursor=pointer]
        - paragraph [ref=f2e21]: "Gold: active · White: selected · Teal: reachable · Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Play three-encounter run" [ref=f2e22] [cursor=pointer]:
          - /url: /run
  - dialog [ref=f2e23]:
    - heading "Saved battle" [level=2] [ref=f2e24]
    - generic [ref=f2e25]: "Saved battle found. Choose Continue or New battle. Primary: valid. Backup: valid. Saves stay in this browser on this site. Use one battle tab; browser cleanup can remove them."
    - generic [ref=f2e26]:
      - button "Continue" [active] [ref=f2e27] [cursor=pointer]
      - button "New battle" [ref=f2e28] [cursor=pointer]
      - button "Export recovery data" [ref=f2e29] [cursor=pointer]
      - button "Remove primary save" [ref=f2e30] [cursor=pointer]
      - button "Remove backup save" [ref=f2e31] [cursor=pointer]
      - button "Retry storage" [ref=f2e32] [cursor=pointer]
```

# Test source

```ts
  172 |   const downloadEvent=page.waitForEvent('download');await page.locator('#save-export').click();const download=await downloadEvent;
  173 |   expect(JSON.parse(readFileSync((await download.path())!,'utf8')).slots).toEqual(expect.arrayContaining([{slot:'primary',text:old.primary},{slot:'backup',text:old.backup}]));
  174 |   await page.locator('#save-close').click();await expect(page.locator('#fit-restart')).toBeEnabled();await expect(page.locator('#fit-status')).toHaveText('Battle ready');
  175 |   await page.evaluate(()=>(window as any).restoreRemove());await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);
  176 |   expect((await readSession(page)).state.seed).toBe(3);await expect(page.locator('canvas')).toHaveCount(1);
  177 |   await page.reload();await page.locator('#save-continue').click();await ready(page);expect((await readSession(page)).state.seed).toBe(3);
  178 | });
  179 | 
  180 | test('changed saved data refuses an old confirmation and requires fresh review',async({page})=>{
  181 |   await seedTwo(page);await page.locator('#fit-restart').click();
  182 |   await page.evaluate(keys=>localStorage.setItem(keys.primary,'changed'),keys);
  183 |   await page.locator('#save-confirm-reset').click();await expect(page.getByRole('dialog')).toContainText('Reset incomplete');
  184 |   expect((await stored(page)).primary).toBe('changed');expect((await readSession(page)).state.seed).toBe(2);
  185 |   await page.locator('#save-close').click();await page.locator('#fit-restart').click();await page.locator('#save-cancel-reset').click();
  186 |   expect((await stored(page)).primary).toBe('changed');await expect(page.locator('#fit-restart')).toBeFocused();
  187 | });
  188 | 
  189 | test('successful reset with failed fresh save cannot recover an old battle on reload',async({page})=>{
  190 |   await seedTwo(page);
  191 |   await page.evaluate(()=>{
  192 |     const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('tactics-guru:phaser:'))throw new DOMException('Full','QuotaExceededError');return set.call(this,key,value);};
  193 |   });
  194 |   await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);expect((await readSession(page)).state.seed).toBe(3);
  195 |   expect(await stored(page)).toEqual({primary:null,backup:null});await expect(page.locator('#battle-save-status')).toContainText('unsaved');
  196 |   await page.reload();await ready(page);expect((await readSession(page)).state.seed).toBe(1);await expect(page.getByRole('dialog')).not.toBeVisible();
  197 | });
  198 | 
  199 | for(const invalid of ['{broken',JSON.stringify({kind:'tactics-guru:battle-snapshot',format:99,payload:{},digest:'sha256:'+'0'.repeat(64)})])test(`invalid startup requires explicit reset: ${invalid.slice(0,12)}`,async({page})=>{
  200 |   await page.goto('/?scene=proof');await page.evaluate(({keys,invalid})=>localStorage.setItem(keys.primary,invalid),{keys,invalid});
  201 |   await page.goto('/');await expect(page.getByRole('dialog')).toContainText('needs recovery');await expect(page.locator('#save-continue')).toHaveCount(0);
  202 |   if(invalid.includes('"format":99'))await expect(page.getByRole('dialog')).toContainText('incompatible');
  203 |   expect((await stored(page)).primary).toBe(invalid);await page.locator('#save-new').click();
  204 |   await expect(page.locator('#save-confirm-reset')).toBeFocused();
  205 |   await page.locator('#save-cancel-reset').click();
  206 |   await expect(page.locator('#save-new')).toBeFocused();
  207 |   expect((await stored(page)).primary).toBe(invalid);await page.locator('#save-new').click();await page.locator('#save-confirm-reset').click();await ready(page);
  208 |   expect((await readSession(page)).state.seed).toBe(1);expect((await stored(page)).primary).not.toBe(invalid);
  209 | });
  210 | 
  211 | test.describe('browser history with BFCache enabled',()=>{
  212 |   test.beforeEach(async({page})=>{
  213 |     await page.addInitScript(()=>window.addEventListener('pageshow',event=>{
  214 |       if(event.persisted)sessionStorage.setItem('test:bfcache-return',location.href);
  215 |     }));
  216 |   });
  217 | 
  218 |   for(const cached of ['battle','recovery dialog'])test(`cached ${cached} cannot overwrite either slot of its replacement`,async({page,baseURL})=>{
  219 |     const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  220 |     const first=new URL('./?history=first',baseURL).href,map=new URL('map',baseURL).href;
  221 |     await page.goto(first);await ready(page);
  222 |     expect((await readSession(page)).state.seed).toBe(1);
  223 |     if(cached==='recovery dialog'){await page.reload();await expect(page.locator('#save-continue')).toBeVisible();}
  224 |     await page.goto(map);await expect(page.locator('#map-grid span')).toHaveCount(400);await page.goto(baseURL!);
  225 |     await page.locator('#save-new').click();await page.locator('#save-confirm-reset').click();await ready(page);
  226 |     const replacement=await readSession(page),saved=await stored(page);
  227 |     expect(replacement.state.seed).toBe(2);
  228 |     await page.goBack({waitUntil:'commit'});await expect(page).toHaveURL(map);
  229 |     await page.goBack({waitUntil:'commit'});
  230 |     await expect(page.locator('#save-continue')).toBeVisible();
  231 |     expect(await page.evaluate(()=>sessionStorage.getItem('test:bfcache-return'))).toBe(first);
  232 |     expect(await stored(page)).toEqual(saved);
  233 |     expect(await page.locator('#game').getAttribute('data-session')).toBeNull();
  234 |     await page.screenshot({path:test.info().outputPath('cached-return-recovery.png')});
  235 |     await page.locator('#save-continue').click();await ready(page);
  236 |     expect((await readSession(page)).state).toEqual(replacement.state);
  237 |     expect(await stored(page)).toEqual(saved);
  238 |     await page.locator('#battle-next').click();await ready(page);
  239 |     const after=await stored(page);
  240 |     for(const text of [after.primary,after.backup]){
  241 |       const decoded=decodeBattleSave(text!,catalog);expect(decoded.ok).toBe(true);
  242 |       if(decoded.ok)expect(decoded.state.seed).toBe(2);
  243 |     }
  244 |     expect(errors).toEqual([]);
  245 |   });
  246 | 
  247 |   for(const departure of ['player','presentation'])test(`cached return after restart at ${departure} preserves the accepted boundary`,async({page,baseURL})=>{
  248 |     const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  249 |     const first=new URL('./?history=first',baseURL).href,map=new URL('map',baseURL).href;
  250 |     await page.goto(first);await ready(page);
  251 |     await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);
  252 |     // Observe the last accepted boundary before the application's pagehide shutdown.
  253 |     await page.evaluate(keys=>window.addEventListener('pagehide',()=>{
  254 |       sessionStorage.setItem('test:departure',JSON.stringify({
  255 |         primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup),
  256 |       }));
  257 |     },{capture:true,once:true}),keys);
  258 |     if(departure==='presentation'){
  259 |       await page.evaluate(map=>{
  260 |         document.querySelector<HTMLButtonElement>('#battle-next')!.click();
  261 |         sessionStorage.setItem('test:departure-phase',document.querySelector<HTMLElement>('#game')!.dataset.phase!);
  262 |         location.assign(map);
  263 |       },map);
  264 |       await expect(page).toHaveURL(map);
  265 |       expect(await page.evaluate(()=>sessionStorage.getItem('test:departure-phase'))).toBe('presenting');
  266 |     }else await page.goto(map);
  267 |     await expect(page.locator('#map-grid span')).toHaveCount(400);
  268 |     const saved=JSON.parse((await page.evaluate(()=>sessionStorage.getItem('test:departure')))!);
  269 |     expect(await stored(page)).toEqual(saved);
  270 |     await page.goBack({waitUntil:'commit'});
  271 |     await expect(page.locator('#save-continue')).toBeVisible();
> 272 |     expect(await page.evaluate(()=>sessionStorage.getItem('test:bfcache-return'))).toBe(first);
      |                                                                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  273 |     expect(await stored(page)).toEqual(saved);
  274 |     await page.locator('#save-continue').click();await ready(page);
  275 |     const continued=await readSession(page),decoded=decodeBattleSave(saved.primary,catalog);
  276 |     expect(decoded.ok).toBe(true);
  277 |     if(decoded.ok)expect(continued.continuation!.snapshot).toEqual(decoded.state);
  278 |     expect(continued.state.seed).toBe(2);
  279 |     if(departure==='player'){expect(await stored(page)).toEqual(saved);expect(continued.events).toEqual([]);}
  280 |     await page.screenshot({path:test.info().outputPath(`continued-${departure}.png`)});
  281 |     expect(errors).toEqual([]);
  282 |   });
  283 | });
  284 | 
```
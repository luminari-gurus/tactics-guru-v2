# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-animations.spec.ts >> ability departure through real browser history >> magic_missile: cached return preserves exact accepted slots until Continue
- Location: tests\battle-animations.spec.ts:322:27

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "yes"
Received: null
```

# Page snapshot

```yaml
- generic [ref=f2e1]:
  - main "Tactics Guru game canvas" [ref=f2e2]
  - generic:
    - region "Battlefield":
      - generic [ref=f2e4]:
        - paragraph [ref=f2e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=f2e6]
      - paragraph [ref=f2e7]: "Gold: active · White: selected · Teal: reachable"
    - complementary "Battle controls" [ref=f2e8]:
      - generic "Actions, target and secondary tools; scroll for more" [ref=f2e9]:
        - generic [ref=f2e10]:
          - paragraph
          - generic [ref=f2e11]:
            - button "Move" [disabled] [ref=f2e12]
            - button "Wait / End turn" [disabled] [ref=f2e13]
            - generic [ref=f2e14]: Select a tile
        - generic [ref=f2e15]:
          - status [ref=f2e16]: Battle ready
          - button "Restart battle" [ref=f2e17] [cursor=pointer]
        - generic [ref=f2e18]:
          - generic [ref=f2e19]: Saved battle found. Choose Continue or New battle.
          - button "Save recovery" [ref=f2e20] [cursor=pointer]
        - paragraph [ref=f2e21]: "Gold: active · White: selected · Teal: reachable · Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Play three-encounter run" [ref=f2e22] [cursor=pointer]:
          - /url: /run
  - dialog [ref=f2e23]:
    - heading "Saved battle" [level=2] [ref=f2e24]
    - generic [ref=f2e25]: "Saved battle found. Choose Continue or New battle. Primary: valid. Backup: valid. Saves stay in this browser on this site. Use one battle tab; browser cleanup can remove them."
    - generic [ref=f2e26]:
      - button "Continue" [active] [ref=f2e27] [cursor=pointer]
      - button "New battle" [ref=f2e28] [cursor=pointer]
      - button "Export recovery data" [ref=f2e29] [cursor=pointer]
      - button "Remove primary save" [ref=f2e30] [cursor=pointer]
      - button "Remove backup save" [ref=f2e31] [cursor=pointer]
      - button "Retry storage" [ref=f2e32] [cursor=pointer]
```

# Test source

```ts
  229 |   // Exercise board input during the lock. Fresh keys on the usable Restart
  230 |   // fallback intentionally open/confirm reset; held-key capture has its own regression.
  231 |   await expect(page.locator('#fit-restart')).toBeFocused();await page.locator('canvas').focus();
  232 |   await page.keyboard.press('Enter');await page.keyboard.press('Space');
  233 |   await expect(page.locator('#battle-next')).toBeDisabled();await expect(page.locator('[data-action="signature"]')).toBeDisabled();
  234 |   await page.clock.runFor(112);const travel=await report(page);aligned(travel,fixture);
  235 |   expect(travel.effect.progress).toBeGreaterThan(0);expect(travel.effect.progress).toBeLessThan(0.45);
  236 |   await page.screenshot({path:info.outputPath(`${kind}-travel.png`)});
  237 |   // Pan/zoom during flight without changing the accepted simulation.
  238 |   await page.mouse.move(point.x,point.y);await page.mouse.down();await page.mouse.move(point.x+25,point.y-15,{steps:3});await page.mouse.up();
  239 |   await page.mouse.wheel(0,-50);await page.clock.runFor(176);
  240 |   const impact=await report(page);aligned(impact,fixture);expect(impact.transform).not.toEqual(travel.transform);
  241 |   expect(impact.effect.progress).toBeGreaterThanOrEqual(0.45);
  242 |   expect(impact.effect.feedback.filter((f:any)=>f.visible).map((f:any)=>({unitId:f.unitId,text:f.text})))
  243 |     .toEqual(abilityPresentation(fixture.events).feedback.map(f=>({unitId:f.unitId,text:f.text})));
  244 |   await page.screenshot({path:info.outputPath(`${kind}-impact.png`)});
  245 |   const capture=(r:any)=>({viewport:r.viewport,transform:r.transform,effect:r.effect,
  246 |     units:r.units.filter((u:any)=>u.id===r.effect.actorId || u.id===r.effect.targetId),objectCount:r.objectCount});
  247 |   writeFileSync(info.outputPath('animation.json'),JSON.stringify({viewport:page.viewportSize(),fixture,travel:capture(travel),impact:capture(impact)},null,2));
  248 |   expect((await readSession(page)).state).toEqual(accepted.state);expect(await stored(page)).toEqual(saved);
  249 |   await page.clock.runFor(500);await ready(page);
  250 |   expect((await report(page)).effect).toBeNull();expect((await report(page)).objectCount).toBe(baseline);
  251 |   expect((await readSession(page)).state).toEqual(fixture.after);expect(await stored(page)).toEqual(saved);expect(errors).toEqual([]);
  252 | });
  253 | 
  254 | for(const [kind,outcome] of [['guarded_strike','miss'],['high_shot','miss'],['high_shot','critical'],['magic_missile','defeat']] as const)
  255 | test(`${kind}: ${outcome} feedback matches resolved events`,async({page},info)=>{
  256 |   const fixture=boundary(kind,outcome);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(288);
  257 |   const r=await report(page);aligned(r,fixture);
  258 |   const feedback=abilityPresentation(fixture.events).feedback;
  259 |   expect(r.effect.feedback.map((f:any)=>({unitId:f.unitId,text:f.text}))).toEqual(feedback.map(f=>({unitId:f.unitId,text:f.text})));
  260 |   expect(r.effect.feedback.every((f:any)=>f.visible)).toBe(true);
  261 |   if(outcome==='miss'){expect(feedback.some(f=>f.text==='Miss')).toBe(true);expect(feedback.some(f=>f.text.includes('−'))).toBe(false);}
  262 |   if(kind==='guarded_strike')expect(feedback).toContainEqual({unitId:r.effect.actorId,kind:'guard',text:'Guarded'});
  263 |   const positions=r.effect.feedback.map((f:any)=>`${f.x},${f.y}`);expect(new Set(positions).size).toBe(positions.length);
  264 |   await page.screenshot({path:info.outputPath(`${kind}-${outcome}.png`)});await page.clock.runFor(500);
  265 |   expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.after);
  266 | });
  267 | 
  268 | for(const kind of kinds)test(`${kind}: repeated cancellation, modal refresh, resize and restart during travel and impact`,async({page})=>{
  269 |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  270 |   const fixture=boundary(kind);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(96);
  271 |   const saved=await stored(page);
  272 |   await page.locator('#fit-restart').click({force:true});await page.locator('#save-cancel-reset').click({force:true});
  273 |   aligned(await report(page),fixture);
  274 |   const size=page.viewportSize()!;await page.setViewportSize({width:size.height,height:size.width});await page.clock.runFor(64);
  275 |   aligned(await report(page),fixture);
  276 |   await page.evaluate(()=>{
  277 |     Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});
  278 |     for(let i=0;i<3;i++)document.dispatchEvent(new Event('visibilitychange'));
  279 |   });
  280 |   await ready(page);expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.after);expect(await stored(page)).toEqual(saved);
  281 |   await page.evaluate(()=>{delete (document as unknown as {hidden?:boolean}).hidden;document.dispatchEvent(new Event('visibilitychange'));});
  282 |   await page.clock.runFor(700);expect((await readSession(page)).state).toEqual(fixture.after);
  283 |   // Restore only this known legal boundary via the real persisted-save startup for each teardown phase.
  284 |   for(const time of [96,288]){
  285 |     const encoded=encodeBattleSave(fixture.before,catalog);if(!encoded.ok)throw Error(encoded.reason);
  286 |     await page.evaluate(({keys,text})=>{localStorage.setItem(keys.primary,text);localStorage.setItem(keys.backup,text);},{keys,text:encoded.text});
  287 |     await page.reload();await page.clock.resume();await page.locator('#save-continue').click();await ready(page);
  288 |     await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(time);
  289 |     await page.locator('#fit-restart').click({force:true});await confirmRestart(page,true);await page.clock.resume();await ready(page);
  290 |     expect((await readSession(page)).state.seed).toBe(fixture.before.seed+1);expect((await report(page)).effect).toBeNull();
  291 |     await expect(page.locator('canvas')).toHaveCount(1);
  292 |   }
  293 |   expect(errors).toEqual([]);
  294 | });
  295 | 
  296 | for(const kind of kinds)test(`${kind}: reload resumes accepted save without historical effects`,async({page})=>{
  297 |   const fixture=boundary(kind);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(112);
  298 |   const saved=await stored(page);await page.reload();await page.clock.resume();await expect(page.locator('#save-continue')).toBeVisible();
  299 |   expect(await stored(page)).toEqual(saved);await page.locator('#save-continue').click();await ready(page);
  300 |   expect((await readSession(page)).state).toEqual(fixture.after);expect((await readSession(page)).events).toEqual([]);
  301 |   expect((await report(page)).effect).toBeNull();expect(await stored(page)).toEqual(saved);
  302 | });
  303 | 
  304 | test('elevated target remains anchored through rotation during impact',async({page},info)=>{
  305 |   const fixture=boundary('high_shot','any',true);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);
  306 |   await page.clock.runFor(288);const before=await report(page);aligned(before,fixture);
  307 |   const unit=fixture.before.units.find(u=>u.id===before.effect.targetId)!;
  308 |   expect(before.tiles.find((t:any)=>t.x===unit.cell.x && t.y===unit.cell.y).elevation).toBeGreaterThan(0);
  309 |   const size=page.viewportSize()!,rotated={width:size.height,height:size.width};
  310 |   // Native resize delivery is independent of the paused animation clock. Wait
  311 |   // for that event before advancing Phaser's resize/presentation callbacks.
  312 |   await page.evaluate(()=>window.addEventListener('resize',()=>{document.documentElement.dataset.impactResize='observed';},{once:true}));
  313 |   await page.setViewportSize(rotated);
  314 |   await expect(page.locator('html')).toHaveAttribute('data-impact-resize','observed');
  315 |   await page.clock.runFor(64);
  316 |   const after=await report(page);aligned(after,fixture);expect(after.viewport).toEqual(rotated);
  317 |   await page.screenshot({path:info.outputPath('elevated-rotated-impact.png')});
  318 |   await page.clock.runFor(500);expect((await report(page)).effect).toBeNull();expect((await readSession(page)).state).toEqual(fixture.after);
  319 | });
  320 | 
  321 | test.describe('ability departure through real browser history',()=>{
  322 |   for(const kind of kinds)test(`${kind}: cached return preserves exact accepted slots until Continue`,async({page,baseURL})=>{
  323 |     const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  324 |     await page.addInitScript(()=>window.addEventListener('pageshow',event=>{if(event.persisted)sessionStorage.setItem('test:animation-cached-return','yes');}));
  325 |     const fixture=boundary(kind);await boot(page,fixture);await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(112);
  326 |     const saved=await stored(page),map=new URL('map',baseURL).href;
  327 |     await page.evaluate(map=>location.assign(map),map);await expect(page.locator('#map-grid span')).toHaveCount(400);
  328 |     await page.goBack({waitUntil:'commit'});await page.clock.resume();await expect(page.locator('#save-continue')).toBeVisible();
> 329 |     expect(await page.evaluate(()=>sessionStorage.getItem('test:animation-cached-return'))).toBe('yes');
      |                                                                                             ^ Error: expect(received).toBe(expected) // Object.is equality
  330 |     expect(await stored(page)).toEqual(saved);expect(await page.locator('#game').getAttribute('data-session')).toBeNull();
  331 |     await page.locator('#save-continue').click();await ready(page);
  332 |     expect((await readSession(page)).state).toEqual(fixture.after);expect((await readSession(page)).events).toEqual([]);
  333 |     expect((await report(page)).effect).toBeNull();expect(await stored(page)).toEqual(saved);expect(errors).toEqual([]);
  334 |   });
  335 | });
  336 | 
  337 | for(const ability of ['ability:basic_attack','ability:guarded_strike'] as const)test(`${ability}: spent action and effective Guarded feedback agree in actor and inspection`,async({page})=>{
  338 |   const fixture=boundary('guarded_strike');await boot(page,fixture);
  339 |   const command={...fixture.command,abilityId:ability} as Extract<Command,{type:'useAbility'}>;
  340 |   await page.locator(ability==='ability:basic_attack'?'[data-action="basic"]':'[data-action="signature"]').click();
  341 |   const targetId='unitId' in command.target?command.target.unitId:-1;
  342 |   const target=fixture.before.units.find(u=>u.id===targetId)!;
  343 |   await page.locator('#battle-target').selectOption(`${target.cell.x},${target.cell.y}`);
  344 |   const prepared=await page.locator('#game').getAttribute('data-session'),preview=await page.locator('#battle-preview').textContent();
  345 |   await expect(page.locator('#battle-target-info')).toContainText('Target:');
  346 |   await page.locator('#battle-inspect-target').click();await expect(page.locator('#battle-dialog-title')).toContainText(`#${targetId}`);
  347 |   await page.locator('#inspection-close').click();await expect(page.locator('#battle-inspect-target')).toBeFocused();
  348 |   expect(await page.locator('#game').getAttribute('data-session')).toBe(prepared);expect(await page.locator('#battle-preview').textContent()).toBe(preview);
  349 |   await page.locator('#battle-review').click();await expect(page.locator('#battle-dialog-message')).toContainText('Fighter');
  350 |   await expect(page.locator('#battle-dialog-message')).toContainText('Target:');
  351 |   await page.locator('#dialog-confirm').click();await ready(page);
  352 |   const state=(await readSession(page)).state,actor=state.units.find(u=>u.id===command.unitId)!;
  353 |   expect(actor.hasActed).toBe(true);expect(!!actor.guarded).toBe(ability==='ability:guarded_strike');
  354 |   const ac=catalog.heroes.fighter.stats.armorClass+(actor.guarded?2:0);
  355 |   await expect(page.locator('#battle-stats')).toContainText(`AC ${ac}`);
  356 |   await expect(page.locator('#battle-status')).toHaveText(actor.guarded?'Guarded (+2 AC)':'No status effects');
  357 |   await expect(page.locator('[data-action="basic"]')).toBeDisabled();await expect(page.locator('#battle-availability')).toContainText('Action spent');
  358 |   await page.locator('#battle-party').click();await page.locator(`#inspect-unit-${actor.id}`).click();
  359 |   await expect(page.locator('#battle-dialog-message')).toContainText(`AC ${ac}`);
  360 |   await expect(page.locator('#battle-dialog-message')).toContainText(actor.guarded?'Guarded (+2 AC)':'No status effects');
  361 |   await page.locator('#inspection-close').click();expect((await readSession(page)).state).toEqual(state);
  362 | });
  363 | 
  364 | test('visible action feedback stays inside the drawable board at small sizes and zoomed edges',async({page},info)=>{
  365 |   const fixture=boundary('magic_missile','defeat');await boot(page,fixture);
  366 |   for(const size of [{width:320,height:568},{width:568,height:320}]){
  367 |     // Reload the same legally reached boundary; this is presentation coverage, not a battle-completion claim.
  368 |     const encoded=encodeBattleSave(fixture.before,catalog);if(!encoded.ok)throw Error(encoded.reason);
  369 |     await page.evaluate(({keys,text})=>{localStorage.setItem(keys.primary,text);localStorage.setItem(keys.backup,text);},{keys,text:encoded.text});
  370 |     await page.setViewportSize(size);await page.reload();await page.clock.resume();await page.locator('#save-continue').click();await ready(page);
  371 |     await review(page,fixture);await confirmFrozen(page);await page.clock.runFor(288);
  372 |     const initial=await report(page),r=initial.region;
  373 |     const x=r.x+r.width/2,y=r.y+r.height/2;
  374 |     await page.mouse.move(x,y);for(let i=0;i<3;i++)await page.mouse.wheel(0,-1000);
  375 |     await page.mouse.down();await page.mouse.move(r.x+r.width-6,r.y+6,{steps:4});await page.mouse.up();
  376 |     const frame=await report(page);expect(frame.feedbackBounds).toHaveLength(2);
  377 |     for(const b of frame.feedbackBounds){expect(b.x).toBeGreaterThanOrEqual(r.x);expect(b.y).toBeGreaterThanOrEqual(r.y);expect(b.x+b.width).toBeLessThanOrEqual(r.x+r.width);expect(b.y+b.height).toBeLessThanOrEqual(r.y+r.height);}
  378 |     const [a,b]=frame.feedbackBounds;expect(a.y+a.height<=b.y||b.y+b.height<=a.y).toBe(true);
  379 |     expect((await readSession(page)).state).toEqual(fixture.after);
  380 |     await page.screenshot({path:info.outputPath(`feedback-${size.width}.png`)});await page.clock.runFor(700);
  381 |   }
  382 | });
  383 | 
```
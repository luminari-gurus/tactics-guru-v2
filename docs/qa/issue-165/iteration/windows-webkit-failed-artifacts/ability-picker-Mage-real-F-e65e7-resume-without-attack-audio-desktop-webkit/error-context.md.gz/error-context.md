# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ability-picker.spec.ts >> Mage real Frost Snare preserves keyboard touch previews cancellation inspection and exact resume without attack audio
- Location: tests\ability-picker.spec.ts:19:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
    "enabled": true,
    "started": 0,
-   "status": "ready",
+   "status": "unavailable",
  }

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Proof scene diagnostics" [ref=e8]:
      - generic "Acting unit information; scroll for details" [ref=e9]:
        - paragraph [ref=e10]: Round 1 · Your turn
        - generic [ref=e11]:
          - img "Mage portrait" [ref=e13]
          - generic [ref=e14]:
            - heading "Mage" [level=2] [ref=e15]
            - paragraph [ref=e16]: HP 19/19
            - paragraph [ref=e19]: AC 11 · Accuracy +3
            - paragraph [ref=e20]: No status effects
        - paragraph [ref=e21]: Move ready / Action ready
      - generic "Actions, target and secondary tools; scroll for more" [ref=e22]:
        - generic [ref=e23]:
          - paragraph [ref=e24]: Choose your action
          - generic "Acting unit actions" [ref=e25]:
            - button "Move" [pressed] [ref=e26] [cursor=pointer]:
              - strong [ref=e27]: Move
              - generic [ref=e28]: Uses movement
            - button "Basic attack" [ref=e29] [cursor=pointer]:
              - strong [ref=e30]: Basic attack
              - generic [ref=e31]: Uses action
            - button "Frost Snare" [ref=e32] [cursor=pointer]:
              - strong [ref=e33]: Frost Snare
              - generic [ref=e34]: Uses action
            - button "Wait / End turn" [ref=e35] [cursor=pointer]:
              - strong [ref=e36]: Wait / End turn
              - generic [ref=e37]: Ends turn immediately
          - text: Ability
          - combobox "Ability" [ref=e38]:
            - option "Frost Snare" [selected]
            - option "Magic Missile"
          - paragraph [ref=e39]: Range 2–4 · Hostile target · blocks movement until its next turn ends or source/target defeat · no damage or roll · unlock level 3 · uses action · Arc Bolt consolidated into Magic Missile (level 1); Frost Snare unlocks at level 3
          - paragraph [ref=e40]: Choose an action, then a target. Wait ends the turn immediately.
          - region "Target and action preview" [ref=e41]:
            - generic [ref=e42]: Target / destination
            - combobox "Target / destination" [ref=e43]:
              - option "Choose target" [selected]
              - option "(0, 1) · cost 1"
              - option "(1, 1) · cost 2"
              - option "(0, 2) · cost 2"
              - option "(2, 1) · cost 3"
              - option "(1, 2) · cost 3"
              - option "(0, 3) · cost 3"
              - option "(3, 1) · cost 4"
              - option "(2, 2) · cost 4"
            - paragraph [ref=e44]: Select a tile
            - paragraph
            - paragraph [ref=e45]: Select a destination
            - generic [ref=e46]:
              - button "Confirm action" [disabled] [ref=e47]
              - button "Cancel action" [ref=e48] [cursor=pointer]
          - navigation "Secondary battle tools" [ref=e49]:
            - button "Inspect party" [ref=e50] [cursor=pointer]
            - button "Battle log" [ref=e51] [cursor=pointer]
            - button "Enable sound" [active] [ref=e52] [cursor=pointer]
          - paragraph [ref=e53]: "Sound unavailable: Could not load or decode battle audio."
        - generic [ref=e54]:
          - status [ref=e55]: Loading
          - button "Restart proof scene" [disabled] [ref=e56]
        - paragraph [ref=e57]: Elevated board · Tap to select · Drag to pan · Wheel/pinch to zoom
```

# Test source

```ts
  1   | import {expect,test} from '@playwright/test';
  2   | import { readSession, playCommand } from './helpers/battlePolicy';
  3   | import { abilityCatalog } from './helpers/abilityCatalog';
  4   | import { progressHero, projectProgression } from '../src/domain/progression';
  5   | import { HERO_IDS } from '../src/content/constants';
  6   | import { previewMovement } from '../src/domain/grid';
  7   | 
  8   | test('Mage real learned picker consolidates Arc Bolt and gates Frost Snare at level three',async({page})=>{
  9   |   for(const [xp,count] of [[0,0],[60,0],[180,1]]) {
  10  |     await page.goto(`/tests/fixtures/abilities/index.html?hero=mage&xp=${xp}&real`);
  11  |     await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  12  |     await expect(page.locator('#battle-ability option[value="ability:magic_missile"]')).toHaveCount(1);
  13  |     await expect(page.locator('#battle-ability option[value="ability:frost_snare"]')).toHaveCount(count);
  14  |     await expect(page.locator('#battle-ability option')).toHaveCount(count+1);
  15  |     await expect(page.locator('#battle-ability-info')).toContainText('Arc Bolt consolidated into Magic Missile (level 1); Frost Snare unlocks at level 3');
  16  |   }
  17  | });
  18  | 
  19  | test('Mage real Frost Snare preserves keyboard touch previews cancellation inspection and exact resume without attack audio',async({page,isMobile})=>{
  20  |   test.setTimeout(90000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  21  |   await page.goto('/tests/fixtures/abilities/index.html?hero=mage&xp=180&real');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  22  |   const picker=page.locator('#battle-ability'),button=page.locator('[data-action=signature]'),before=await readSession(page);
  23  |   if(isMobile)await page.locator('#battle-sound').tap();else{await page.locator('#battle-sound').focus();await page.keyboard.press('Enter');}
> 24  |   await expect.poll(()=>page.evaluate(()=>window.fitDiagnostics().battleAudio)).toMatchObject({enabled:true,status:'ready',started:0});
      |                                                                                 ^ Error: expect(received).toMatchObject(expected)
  25  |   const storage=await page.evaluate(()=>JSON.stringify(localStorage));
  26  |   await picker.selectOption('ability:frost_snare');if(isMobile)await button.tap();else{await button.focus();await page.keyboard.press('Enter');}
  27  |   await page.locator('#battle-target').selectOption('2,0');await expect(page.locator('#battle-preview')).toContainText('Snared by Mage #3');await expect(page.locator('#battle-preview')).toContainText('no damage or roll');
  28  |   const pending=(await readSession(page)).pending;expect(pending).toMatchObject({abilityId:'ability:frost_snare'});
  29  |   const viewport=page.viewportSize()!;await page.setViewportSize({width:320,height:568});await expect(picker).toHaveValue('ability:frost_snare');expect((await readSession(page)).pending).toEqual(pending);
  30  |   await page.locator('#battle-review').scrollIntoViewIfNeeded();await page.screenshot({path:test.info().outputPath('mage-snare-narrow-preview.png')});
  31  |   expect((await readSession(page)).state).toEqual(before.state);expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(storage);
  32  |   await page.setViewportSize(viewport);await page.keyboard.press('Escape');expect((await readSession(page)).pending).toBeNull();
  33  |   if(isMobile)await button.tap();else await button.click();await page.locator('#battle-target').selectOption('2,0');
  34  |   if(isMobile)await page.locator('#battle-review').tap();else{await page.locator('#battle-review').focus();await page.keyboard.press('Enter');}
  35  |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');const accepted=await readSession(page);
  36  |   expect(accepted.state.units.find(u=>u.id===5)?.movementBlock).toEqual({sourceId:3,abilityId:'ability:frost_snare'});expect(accepted.state.rng).toEqual(before.state.rng);expect(accepted.state.units.map(u=>u.hp)).toEqual(before.state.units.map(u=>u.hp));
  37  |   expect(accepted.state.commandCount).toBe(before.state.commandCount+1);await expect(picker).toBeDisabled();
  38  |   expect(await page.evaluate(()=>window.fitDiagnostics().battleAudio)).toMatchObject({enabled:true,status:'ready',started:0,completed:0,dropped:0,active:null,recent:[],ownedSounds:0});
  39  |   await page.locator('#battle-party').click();await page.locator('#inspect-unit-5').click();await expect(page.getByRole('dialog')).toContainText('Snared by Mage #3');await expect(page.getByRole('dialog')).toContainText('expires after this unit’s next turn ends or source/target defeat');
  40  |   await page.screenshot({path:test.info().outputPath('mage-snare-inspection.png')});await page.locator('#inspection-close').click();
  41  |   await page.locator('#battle-log-open').click();await expect(page.getByRole('dialog')).toContainText('Snared by Mage');await page.locator('#log-close').click();
  42  |   await page.reload();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');const resumed=await readSession(page);expect(resumed.state).toEqual(accepted.state);expect(resumed.events).toEqual([]);expect(resumed.pending).toBeNull();expect(errors).toEqual([]);
  43  | });
  44  | 
  45  | test('Ranger learned actions follow level one, two and three through the real picker',async({page})=>{
  46  |   for(const [xp,mark,pin] of [[0,0,0],[60,1,0],[180,1,1]]) {
  47  |     await page.goto(`/tests/fixtures/abilities/index.html?hero=ranger&xp=${xp}`);
  48  |     await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  49  |     await expect(page.locator('#battle-ability option[value="ability:high_shot"]')).toHaveCount(1);
  50  |     await expect(page.locator('#battle-ability option[value="ability:mark_target"]')).toHaveCount(mark);
  51  |     await expect(page.locator('#battle-ability option[value="ability:pinning_shot"]')).toHaveCount(pin);
  52  |     await expect(page.locator('#battle-ability-info')).toContainText('Mark Target unlocks at level 2; Pinning Shot at level 3');
  53  |   }
  54  | });
  55  | 
  56  | for(const ability of ['mark_target','pinning_shot'] as const)test(`Ranger ${ability} preserves keyboard touch preview cancellation inspection and exact resume`,async({page,isMobile})=>{
  57  |   test.setTimeout(90000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  58  |   await page.goto('/tests/fixtures/abilities/index.html?hero=ranger&xp=180');
  59  |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  60  |   const picker=page.locator('#battle-ability'),button=page.locator('[data-action=signature]'),abilityId=`ability:${ability}`;
  61  |   const before=await readSession(page),storage=await page.evaluate(()=>JSON.stringify(localStorage));
  62  |   // Exercise no-roll controls with a real unlocked backend, so muted audio cannot
  63  |   // hide an accidental attack/magic cue in the presentation path.
  64  |   if(isMobile)await page.locator('#battle-sound').tap();else {await page.locator('#battle-sound').focus();await page.keyboard.press('Enter');}
  65  |   await expect.poll(()=>page.evaluate(()=>window.fitDiagnostics().battleAudio)).toMatchObject({enabled:true,status:'ready',started:0});
  66  |   expect((await readSession(page)).state).toEqual(before.state);
  67  |   await picker.selectOption(abilityId);await expect(picker).toHaveValue(abilityId);await picker.focus();
  68  |   if(isMobile)await button.tap();else await button.click();
  69  |   await page.locator('#battle-target').selectOption('2,0');
  70  |   await expect(page.locator('#battle-preview')).toContainText('no damage or roll');
  71  |   await expect(page.locator('#battle-preview')).not.toContainText('Taunt');
  72  |   const pending=(await readSession(page)).pending;expect(pending).toMatchObject({abilityId});
  73  |   const viewport=page.viewportSize()!;await page.setViewportSize({width:320,height:568});
  74  |   await expect(picker).toHaveValue(abilityId);expect((await readSession(page)).pending).toEqual(pending);
  75  |   expect((await readSession(page)).state).toEqual(before.state);expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(storage);
  76  |   await page.locator('#battle-review').scrollIntoViewIfNeeded();await page.screenshot({path:test.info().outputPath(`${ability}-narrow-preview.png`)});
  77  |   await page.setViewportSize(viewport);await page.keyboard.press('Escape');expect((await readSession(page)).pending).toBeNull();
  78  |   expect((await readSession(page)).state).toEqual(before.state);
  79  |   if(isMobile)await button.tap();else await button.click();await page.locator('#battle-target').selectOption('2,0');
  80  |   if(isMobile)await page.locator('#battle-review').tap();else {await page.locator('#battle-review').focus();await page.keyboard.press('Enter');}
  81  |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  82  |   const accepted=await readSession(page),target=accepted.state.units.find(u=>u.id===5)!;
  83  |   expect(await page.evaluate(()=>window.fitDiagnostics().battleAudio)).toMatchObject({enabled:true,status:'ready',started:0,completed:0,dropped:0,active:null,recent:[],ownedSounds:0});
  84  |   if(ability==='mark_target')expect(target.markedBy).toBe(2);
  85  |   else expect(target.movementBlock).toEqual({sourceId:2,abilityId:'ability:pinning_shot'});
  86  |   expect(accepted.state.rng).toEqual(before.state.rng);
  87  |   expect(accepted.state.units.map(u=>u.hp)).toEqual(before.state.units.map(u=>u.hp));
  88  |   expect(accepted.state.commandCount).toBe(before.state.commandCount+1);await expect(picker).toBeDisabled();
  89  |   await page.locator('#battle-party').click();await page.locator('#inspect-unit-5').click();
  90  |   await expect(page.getByRole('dialog')).toContainText(ability==='mark_target'?'Marked by Ranger #2':'Pinned by Ranger #2');
  91  |   await page.screenshot({path:test.info().outputPath(`${ability}-inspection.png`)});await page.locator('#inspection-close').click();
  92  |   await page.locator('#battle-log-open').click();await expect(page.getByRole('dialog')).toContainText(ability==='mark_target'?'marked by Ranger':'Pinned by Ranger');await page.locator('#log-close').click();
  93  |   await page.reload();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  94  |   const resumed=await readSession(page);expect(resumed.state).toEqual(accepted.state);expect(resumed.events).toEqual([]);expect(resumed.pending).toBeNull();
  95  |   expect(errors).toEqual([]);
  96  | });
  97  | 
  98  | test('Fighter healing and Taunt preserve keyboard touch cancellation inspection and resume',async({page,isMobile})=>{
  99  |   test.setTimeout(90000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  100 |   await page.goto('/tests/fixtures/abilities/index.html?hero=fighter&xp=180&injured');
  101 |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  102 |   const picker=page.locator('#battle-ability'),signature=page.locator('[data-action=signature]');
  103 |   await expect(picker.locator('option[value="ability:second_wind"]')).toHaveCount(1);await expect(picker.locator('option[value="ability:taunt"]')).toHaveCount(1);
  104 |   const initial=await readSession(page);
  105 |   await picker.selectOption('ability:second_wind');if(isMobile)await signature.tap();else await signature.click();
  106 |   await page.locator('#battle-target').selectOption('0,0');await expect(page.locator('#battle-preview')).toContainText('Heal 7 HP');
  107 |   await expect(page.locator('#battle-preview')).not.toContainText('Friendly fire');await expect(page.locator('#battle-ability-info')).toContainText('1/1 use');
  108 |   await page.locator('#battle-party').click();await expect(page.getByRole('dialog')).toContainText('Second Wind 1/1');await page.locator('#inspection-close').click();
  109 |   const viewport=page.viewportSize()!;await page.setViewportSize({width:320,height:568});await expect(picker).toHaveValue('ability:second_wind');
  110 |   expect((await readSession(page)).state).toEqual(initial.state);
  111 |   await page.locator('#battle-review').scrollIntoViewIfNeeded();await page.screenshot({path:test.info().outputPath('fighter-heal-preview-narrow.png')});
  112 |   await page.setViewportSize(viewport);await page.keyboard.press('Escape');expect((await readSession(page)).pending).toBeNull();expect((await readSession(page)).state).toEqual(initial.state);
  113 |   await signature.click();await page.locator('#battle-target').selectOption('0,0');
  114 |   if(isMobile)await page.locator('#battle-review').tap();else {await page.locator('#battle-review').focus();await page.keyboard.press('Enter');}
  115 |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  116 |   const healed=await readSession(page);expect(healed.state.rng).toEqual(initial.state.rng);expect(healed.state.units.find(u=>u.defId==='fighter')).toMatchObject({hp:27,secondWindUsed:true,hasActed:true});
  117 |   await expect(page.locator('#battle-status')).toContainText('0/1');await page.locator('#battle-log-open').click();await expect(page.getByRole('dialog')).toContainText('heals 7 HP');await page.locator('#log-close').click();
  118 |   await page.reload();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');expect((await readSession(page)).state).toEqual(healed.state);
  119 |   await page.locator('#battle-next').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  120 |   for(let i=0;i<8;i++) {const s=await readSession(page);if(s.state.units.find(u=>u.id===s.state.initiative[s.state.activeIndex])!.defId==='fighter')break;await page.locator('#battle-next').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');}
  121 |   let next=await readSession(page),fighter=next.state.units.find(u=>u.id===next.state.initiative[next.state.activeIndex])!;expect(fighter.defId).toBe('fighter');
  122 |   await picker.selectOption('ability:second_wind');await expect(signature).toBeDisabled();await expect(page.locator('#battle-ability-info')).toContainText('Use exhausted');
  123 |   let enemy=next.state.units.find(u=>u.side==='enemy' && u.hp>0 && Math.abs(u.cell.x-fighter.cell.x)+Math.abs(u.cell.y-fighter.cell.y)===1);
  124 |   if(!enemy){
```
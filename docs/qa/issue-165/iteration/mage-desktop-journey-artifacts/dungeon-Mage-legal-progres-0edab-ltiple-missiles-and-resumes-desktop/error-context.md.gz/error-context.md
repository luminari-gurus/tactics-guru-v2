# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dungeon.spec.ts >> Mage legal progression journey earns level three uses Frost Snare and multiple missiles and resumes
- Location: tests/dungeon.spec.ts:16:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 114
Received: 113
```

# Page snapshot

```yaml
- main [ref=f1e2]:
  - heading "Dungeon · Floor 1 · Forest" [level=1] [ref=f1e3]
  - paragraph [ref=f1e4]: Guardian defeated. Walk to the stairs to continue.
  - status [ref=f1e5]: Travel saved on this device
  - region "Floor exploration" [ref=f1e6]:
    - heading "Explore Forest · Floor 1" [level=2] [ref=f1e7]
    - generic [ref=f1e8]:
      - text: Map art
      - combobox "Map art" [ref=f1e9]:
        - option "Simple" [selected]
        - option "Legacy 8-bit"
    - paragraph [ref=f1e10]: ● Player · M encounter (including guardian) · ✓ cleared · ↑ upstairs (floor 2+) · ↓ downstairs (guardian defeated). Reveal reaches two cells, including through walls. Tap adjacent cells or use direction controls.
    - application "Floor 1 map. Player row 19, column 7. Arrow or WASD keys move one cell." [active] [ref=f1e11]:
      - generic [aria-hidden] [ref=f1e106]: ✓
      - generic [aria-hidden] [ref=f1e149]: ✓
      - generic [aria-hidden] [ref=f1e177]: ✓
      - generic [aria-hidden] [ref=f1e378]: ●
    - group "Move player" [ref=f1e412]:
      - button "North" [ref=f1e413] [cursor=pointer]:
        - generic: "N"
      - button "East" [disabled] [ref=f1e414]:
        - generic: E
      - button "South" [disabled] [ref=f1e415]:
        - generic: S
      - button "West" [ref=f1e416] [cursor=pointer]:
        - generic: W
    - status [ref=f1e417]: Player cell 366 · Revealed 196/400 · Visited 46.
    - list "Discovered places" [ref=f1e418]:
      - listitem [ref=f1e419]: Normal encounter 1 · Forest · Floor 1 · row 5, column 15 · Cleared · Visited
      - listitem [ref=f1e420]: Elite encounter 2 · Forest · Floor 1 · row 9, column 6 · Cleared · Visited
      - listitem [ref=f1e421]: Guardian · Goblins · Forest · Floor 1 · row 7, column 18 · Cleared · Visited
      - listitem [ref=f1e422]: Downstairs · row 19, column 7 · Unlocked · Visited
  - region "Stairs" [ref=f1e423]:
    - heading "Stairs" [level=2] [ref=f1e424]
    - paragraph [ref=f1e425]: Move onto an available stair to travel automatically. On arrival or after continuing a save, move off and back onto the stair to travel again. Upstairs is unavailable on floor 1.
    - paragraph [ref=f1e426]: Guardian defeated. Descent is unlocked.
  - region "Party" [ref=f1e427]:
    - heading "Party" [level=2] [ref=f1e428]
    - paragraph [ref=f1e429]: "fighter: 30/30 HP · Level 3 · XP 205/360 · Learned: basic attack, guarded strike, second wind, taunt · Accuracy 4 · Armor class 14"
    - paragraph [ref=f1e430]: "ranger: 22/22 HP · Level 3 · XP 205/360 · Learned: basic attack, high shot, mark target, pinning shot · Accuracy 5 · Armor class 12"
    - paragraph [ref=f1e431]: "mage: 19/19 HP · Level 3 · XP 205/360 · Learned: basic attack, frost snare, magic missile · Accuracy 3 · Armor class 11"
  - region "Owned items" [ref=f1e432]:
    - heading "Owned items" [level=2] [ref=f1e433]
    - paragraph [ref=f1e434]: Charms 0/6 · Discard a charm with confirmation to free space.
    - generic [ref=f1e435]:
      - paragraph [ref=f1e436]: Healing Draught ×1
      - combobox "Healing Draught target" [ref=f1e437]:
        - option "fighter" [disabled]
        - option "ranger" [disabled]
        - option "mage" [disabled]
      - button "Use Healing Draught" [disabled] [ref=f1e438]
  - button "Save recovery" [ref=f1e439] [cursor=pointer]
  - button "Start new dungeon" [ref=f1e440] [cursor=pointer]
  - navigation [ref=f1e441]:
    - link "Three-battle scenario" [ref=f1e442] [cursor=pointer]:
      - /url: /run
    - link "Single battle" [ref=f1e443] [cursor=pointer]:
      - /url: /
    - link "Map prototype" [ref=f1e444] [cursor=pointer]:
      - /url: /map
  - group [ref=f1e445]:
    - generic "Privacy & analytics" [ref=f1e446] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect, type Page } from '@playwright/test';
  2  | import type { DungeonState } from '../../src/domain/dungeon';
  3  | import { generateMap } from '../../src/map/generate';
  4  | import { neighbors, poiCell } from '../../src/domain/exploration';
  5  | export async function dungeonSnapshot(page: Page): Promise<DungeonState> { return JSON.parse((await page.locator('#game').getAttribute('data-dungeon-snapshot'))!); }
  6  | export async function walkDungeon(page: Page, target?: number, mode: 'keyboard'|'touch'|'pointer' = 'keyboard') {
  7  |   const s=await dungeonSnapshot(page),f=s.floors[s.depth-1],destination=target??poiCell(f.exploration.pois[f.completed]);
  8  |   const map=generateMap(f.descriptor.seed,'rooms'),previous=new Map<number,number>();const queue=[f.position];previous.set(f.position,-1);
  9  |   for(let i=0;i<queue.length&&!previous.has(destination);i++)for(const n of neighbors(queue[i]))if(map.cells[n]&&!previous.has(n)){previous.set(n,queue[i]);queue.push(n);}
  10 |   if(!previous.has(destination))throw Error('Unreachable fixture destination');
  11 |   const path:number[]=[];for(let n=destination;n!==f.position;n=previous.get(n)!)path.unshift(n);
  12 |   let current=f.position;
  13 |   for(const n of path){const delta=n-current,name=delta===-20?'north':delta===20?'south':delta===1?'east':'west';
  14 |     if(mode==='keyboard'){await page.locator('#dungeon-map').focus();await page.keyboard.press(delta===-20?'ArrowUp':delta===20?'ArrowDown':delta===1?'ArrowRight':'ArrowLeft');}
  15 |     else if(mode==='touch')await page.locator(`#dungeon-step-${name}`).tap();
  16 |     else await page.locator(`#dungeon-map [data-cell="${n}"]`).click();
  17 |     const after=await dungeonSnapshot(page);
  18 |     expect(after.floors[s.depth-1].position).toBe(n);
> 19 |     if(after.depth!==s.depth){expect(n).toBe(destination);break;}
     |                                         ^ Error: expect(received).toBe(expected) // Object.is equality
  20 |     current=n;
  21 |   }
  22 |   return path;
  23 | }
  24 | 
  25 | /** Arrival is inert: leave the staircase and enter it again through normal input. */
  26 | export async function reenterDungeonStair(page: Page, direction: 'ascend'|'descend', mode: 'keyboard'|'touch'|'pointer' = 'keyboard') {
  27 |   const s=await dungeonSnapshot(page),f=s.floors[s.depth-1],map=generateMap(f.descriptor.seed,'rooms');
  28 |   const stair=direction==='ascend'?f.descriptor.upstairs:f.descriptor.downstairs;
  29 |   expect(f.position).toBe(stair);
  30 |   const adjacent=neighbors(stair).find(n=>map.cells[n]&&!f.exploration.pois.some(p=>poiCell(p)===n));
  31 |   if(adjacent===undefined)throw Error('No safe staircase exit');
  32 |   await walkDungeon(page,adjacent,mode);expect((await dungeonSnapshot(page)).depth).toBe(s.depth);
  33 |   await walkDungeon(page,stair,mode);
  34 | }
  35 | 
```
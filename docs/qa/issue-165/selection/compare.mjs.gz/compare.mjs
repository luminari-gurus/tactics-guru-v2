import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root=process.cwd(),base=process.argv[2];
const {discoverSelection}=await import(pathToFileURL(root+'/scripts/verification-selection.mjs'));
const {stages}=await import(pathToFileURL(root+'/scripts/verify-full.mjs'));
const {sourceIdentity}=await import(pathToFileURL(root+'/scripts/verification-report.mjs'));
const original={source:{commit:'bd06447d8dea21d65acc8f8a3851c379c04509d1',tree:execFileSync('git',['rev-parse','bd06447^{tree}'],{encoding:'utf8'}).trim(),method:'git archive of verification inputs; no browser/server execution'},selections:{}};
const current={source:sourceIdentity(root),selections:{}};
const requested=stages.filter(stage=>stage.browser).map(stage=>({id:stage.id,args:stage.args.slice(stage.args.indexOf('test')+1),env:stage.env}));
for(const config of ['playwright.encounters.config.ts','playwright.run-items.config.ts','playwright.abilities.config.ts','playwright.setup-smoke.config.ts'])requested.push({id:config,args:['-c',config]});
const changes=[];
for(const stage of requested){
  const before=discoverSelection(stage.args,stage.env,base),after=discoverSelection(stage.args,stage.env,root);
  original.selections[stage.id]=before;current.selections[stage.id]=after;
  assert.equal(before.workers,after.workers);assert.deepEqual(before.projects,after.projects);
  const key=test=>JSON.stringify([test.project,test.id]),old=new Map(before.tests.map(t=>[key(t),t])),next=new Map(after.tests.map(t=>[key(t),t]));
  assert.equal(old.size,before.tests.length);assert.equal(next.size,after.tests.length);
  for(const [id,test] of old)assert.deepEqual(next.get(id),test,'Retained test changed or disappeared: '+stage.id+' '+test.title);
  const added=after.tests.filter(test=>!old.has(key(test)));
  assert(added.every(test=>test.title.startsWith('Mage real ')||test.title.startsWith('Mage legal progression journey ')),'Unexpected added selection');
  changes.push({stage:stage.id,before:before.tests.length,after:after.tests.length,retained:old.size,added});
}
writeFileSync(root+'/tmp/issue165/selections-base.json',JSON.stringify(original,null,2));
writeFileSync(root+'/tmp/issue165/selections-current.json',JSON.stringify(current,null,2));
writeFileSync(root+'/tmp/issue165/selection-comparison.json',JSON.stringify({base:original.source,current:current.source.commit,allRetainedIdsAndMetadataEqual:true,allDeviceSettingsEqual:true,changes},null,2));
console.log(JSON.stringify(changes.map(({stage,before,after,retained,added})=>({stage,before,after,retained,added:added.length}))));

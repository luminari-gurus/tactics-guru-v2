set -euo pipefail
cd /tmp/tactics-issue-165-20261028
selection_base=/tmp/tactics-issue-165-selection-base-20261028
test ! -e "$selection_base"
mkdir "$selection_base"
git archive bd06447d8dea21d65acc8f8a3851c379c04509d1 -- src tests scripts public package.json package-lock.json index.html '*.config.ts' 'tsconfig*.json' | tar -x -C "$selection_base"
ln -s /tmp/tactics-issue-165-20261028/node_modules "$selection_base/node_modules"
node /mnt/c/Users/apexw/OneDrive/Desktop/Projects/Tactics-Guru/tmp/issue165-selection-compare.mjs "$selection_base"

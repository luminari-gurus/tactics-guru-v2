# Serial verification

Scope: full; complete: false; passed: false; baseline eligible: false

Job wall span: 14055223 ms; total job time: 13854969 ms; completed Actions compute: 14042000 ms.

| Batch / stage | Result | Stage seconds | Counts |
| --- | --- | ---: | --- |
| prepare / tooling | passed | 0.44 | {} |
| prepare / units | passed | 46.83 | {"total":1043,"passed":1043,"failed":0,"pending":0,"todo":0} |
| prepare / typecheck-app | passed | 0.93 | {} |
| prepare / typecheck-domain | passed | 0.15 | {} |
| prepare / build-integration | passed | 7.26 | {"total":2,"passed":2,"failed":0,"pending":0,"todo":0} |
| prepare / build-root | passed | 1.02 | {} |
| chromium-mobile-landscape-1 / chromium-mobile-landscape-1 | failed | 981.47 | {"total":86,"expected":85,"unexpected":1,"flaky":0,"skipped":0,"retryAttempts":0} |
| chromium-mobile-landscape-2 / chromium-mobile-landscape-2 | passed | 557.77 | {"total":104,"expected":102,"unexpected":0,"flaky":0,"skipped":2,"retryAttempts":0} |
| chromium-mobile-landscape-3 / chromium-mobile-landscape-3 | passed | 535.89 | {"total":62,"expected":62,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| fixtures / fixtures | passed | 550.40 | {"total":87,"expected":87,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| placement-dev / placement-dev | passed | 17.19 | {"total":3,"expected":3,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| webkit-acceptance / webkit-acceptance | passed | 675.49 | {"total":54,"expected":54,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| webkit-exploration / webkit-exploration | passed | 2775.84 | {"total":105,"expected":105,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| health-bars / health-bars | passed | 314.58 | {"total":25,"expected":25,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| telemetry-production / telemetry-production | passed | 429.48 | {"total":36,"expected":36,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| telemetry-development / telemetry-development | passed | 428.02 | {"total":36,"expected":36,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| assets-root-dev / assets-root-dev | passed | 261.57 | {"total":75,"expected":72,"unexpected":0,"flaky":0,"skipped":3,"retryAttempts":0} |
| performance / performance | passed | 46.03 | {"samples":18,"failures":[],"measuredBuild":{"commit":"abac1e262007dd64b0184e5d176f7e4425c8f764","dirty":false}} |
| chromium-desktop-1 / chromium-desktop-1 | passed | 1590.91 | {"total":100,"expected":98,"unexpected":0,"flaky":0,"skipped":2,"retryAttempts":0} |
| chromium-desktop-2 / chromium-desktop-2 | passed | 684.01 | {"total":77,"expected":77,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| chromium-desktop-3 / chromium-desktop-3 | passed | 693.78 | {"total":89,"expected":89,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| chromium-mobile-portrait-1 / chromium-mobile-portrait-1 | passed | 1140.35 | {"total":90,"expected":90,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| chromium-mobile-portrait-2 / chromium-mobile-portrait-2 | passed | 435.47 | {"total":103,"expected":101,"unexpected":0,"flaky":0,"skipped":2,"retryAttempts":0} |
| chromium-mobile-portrait-3 / chromium-mobile-portrait-3 | passed | 548.44 | {"total":64,"expected":64,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| prefix-assets / build-prefix | passed | 0.99 | {} |
| prefix-assets / assets-prefix-preview | passed | 220.26 | {"total":75,"expected":75,"unexpected":0,"flaky":0,"skipped":0,"retryAttempts":0} |
| prefix-assets / assets-prefix-dev | passed | 256.41 | {"total":75,"expected":72,"unexpected":0,"flaky":0,"skipped":3,"retryAttempts":0} |
| prefix-assets / restore-root | passed | 0.99 | {} |

- chromium-mobile-landscape-1: failed
- chromium-mobile-landscape-1: Browser failures/retries or invalid counts
- chromium-mobile-landscape-1: latest Actions job failed, incomplete or lacks its matching receipt

No comparable complete historical baseline; no speedup claim. Serial execution does not establish the <=15-minute target.

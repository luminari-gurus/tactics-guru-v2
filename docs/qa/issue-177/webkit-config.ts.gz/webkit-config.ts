import { defineConfig } from '@playwright/test';
import base from '../../playwright.device-acceptance.config';
export default defineConfig({ ...base, testDir:'../../tests', grep:/complete legal authored battle seed 2|run battle undo survives reload|undo and compound plan/ });

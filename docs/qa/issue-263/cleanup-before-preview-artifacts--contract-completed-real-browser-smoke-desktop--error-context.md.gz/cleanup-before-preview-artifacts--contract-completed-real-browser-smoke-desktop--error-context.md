# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: contract.spec.cjs >> completed real browser smoke
- Location: tmp/issue219-browser-zUYLK6/contract.spec.cjs:2:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('canvas')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('canvas') with timeout 5000ms
  - waiting for locator('canvas')

```

```yaml
- main:
  - heading "Tactics Guru" [level=1]:
    - img "Tactics Guru"
  - navigation "Main menu":
    - button "Continue" [disabled]
    - button "New Game"
    - button "Hall of Records"
    - button "Settings"
  - status: Your journey begins here. Saves stay on this device.
  - navigation "Other modes":
    - link "Standalone battle":
      - /url: /battle
    - link "Three-encounter run":
      - /url: /run
    - link "Map inspection":
      - /url: /map
  - paragraph: Choose your next adventure.
```

# Test source

```ts
  1 | const { test, expect } = require("/tmp/tactics-issue263-candidate/node_modules/@playwright/test/index.js");
> 2 | test('completed real browser smoke', async ({page}) => { await page.goto('/'); await expect(page.locator('canvas')).toBeVisible(); });
    |                                                                                                                     ^ Error: expect(locator).toBeVisible() failed
  3 | test('deliberately interrupted browser', async ({page}) => { await page.goto('/'); await new Promise(() => {}); });
```
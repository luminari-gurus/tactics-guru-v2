# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: contract.spec.cjs >> deliberately interrupted browser
- Location: tmp/issue219-browser-NiSsn4/contract.spec.cjs:3:1

# Error details

```
Error: Channel closed
```

```
Error: browserContext.close: Target page, context or browser has been closed
```
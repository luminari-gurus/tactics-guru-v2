import {readFileSync,writeFileSync} from 'node:fs';
const root='tmp/verification/issue-205';
function ids(path){const output=[];const walk=suites=>{for(const suite of suites??[]){for(const spec of suite.specs??[])for(const test of spec.tests??[])output.push({key:`${test.projectName} | ${spec.file??suite.file} | ${spec.title}`,id:spec.id});walk(suite.suites)}};walk(JSON.parse(readFileSync(path)).suites);return output.sort((a,b)=>a.key.localeCompare(b.key));}
const before=ids(`${root}/base/discovery-default.json`),after=ids(`${root}/final/discovery-default.json`);
const oldWebkit=ids(`${root}/base/discovery-webkit.json`),newWebkit=ids(`${root}/final/discovery-webkit.json`);
const removed=before.filter(x=>!after.some(y=>y.key===x.key)),added=after.filter(x=>!before.some(y=>y.key===x.key));
const retained=before.filter(x=>!removed.includes(x)),changedRetainedIds=retained.filter(x=>after.find(y=>y.key===x.key).id!==x.id);
const result={before:before.length,after:after.length,removed,added,retained:retained.length,changedRetainedIds,webkitCountBefore:oldWebkit.length,webkitCountAfter:newWebkit.length,webkitUnchanged:JSON.stringify(oldWebkit)===JSON.stringify(newWebkit),otherAudio:retained.filter(x=>x.key.includes('battle-audio.spec.ts')).length};
result.passed=removed.length===6&&removed.every(x=>/seed [12]: sound on\/off legal battles/.test(x.key))&&added.length===12&&added.every(x=>x.key.includes('battle-audio.spec.ts'))&&changedRetainedIds.length===0&&result.webkitUnchanged&&result.otherAudio===48;
writeFileSync(`${root}/discovery-comparison.json`,JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));if(!result.passed)process.exitCode=1;

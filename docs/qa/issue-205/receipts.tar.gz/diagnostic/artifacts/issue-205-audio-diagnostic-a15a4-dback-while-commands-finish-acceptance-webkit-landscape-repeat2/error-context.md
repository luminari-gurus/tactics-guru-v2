# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: issue-205-audio-diagnostic.spec.ts >> mute, hidden and context interruptions discard active feedback while commands finish
- Location: tests/issue-205-audio-diagnostic.spec.ts:60:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 2
+ Received  + 2

  Object {
-   "enabled": true,
-   "status": "ready",
+   "enabled": false,
+   "status": "muted",
  }

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Battle controls" [ref=e8]:
      - generic "Acting unit information; scroll for details" [ref=e9]:
        - paragraph [ref=e10]: Round 1 · Your turn
        - generic [ref=e11]:
          - img "Mage portrait" [ref=e13]
          - generic [ref=e14]:
            - heading "Mage" [level=2] [ref=e15]
            - paragraph [ref=e16]: HP 11/11
            - paragraph [ref=e19]: AC 11 · Accuracy +3
            - paragraph [ref=e20]: No status effects
        - paragraph [ref=e21]: Move ready / Action ready
      - generic "Actions, target and secondary tools; scroll for more" [ref=e22]:
        - generic [ref=e23]:
          - paragraph [ref=e24]: Choose your action
          - generic "Acting unit actions" [ref=e25]:
            - button "Move" [pressed] [ref=e26] [cursor=pointer]:
              - strong [ref=e27]: Move
              - generic [ref=e28]: Uses movement
            - button "Basic attack" [ref=e29] [cursor=pointer]:
              - strong [ref=e30]: Basic attack
              - generic [ref=e31]: Uses action
            - button "Magic Missile" [ref=e32] [cursor=pointer]:
              - strong [ref=e33]: Magic Missile
              - generic [ref=e34]: Uses action
            - button "Wait / End turn" [ref=e35] [cursor=pointer]:
              - strong [ref=e36]: Wait / End turn
              - generic [ref=e37]: Ends turn immediately
          - text: Ability
          - combobox "Ability" [ref=e38]:
            - option "Magic Missile" [selected]
          - paragraph [ref=e39]: Range 1–5 · Living target, including allies · automatic force damage · uses action
          - paragraph [ref=e40]: Choose an action, then a target. Wait ends the turn immediately.
          - region "Target and action preview" [ref=e41]:
            - generic [ref=e42]: Target / destination
            - combobox "Target / destination" [ref=e43]:
              - option "Choose target" [selected]
              - option "(0, 9) · cost 1"
              - option "(1, 10) · cost 1"
              - option "(0, 8) · cost 2"
              - option "(2, 9) · cost 2"
              - option "(0, 10) · cost 2"
              - option "(1, 11) · cost 2"
              - option "(0, 7) · cost 3"
              - option "(3, 9) · cost 3"
              - option "(2, 10) · cost 3"
              - option "(0, 11) · cost 3"
              - option "(2, 11) · cost 3"
              - option "(0, 6) · cost 4"
              - option "(1, 7) · cost 4"
              - option "(3, 8) · cost 4"
              - option "(4, 9) · cost 4"
              - option "(3, 10) · cost 4"
              - option "(3, 11) · cost 4"
            - paragraph [ref=e44]: Select a tile
            - paragraph
            - paragraph [ref=e45]: Select a destination
            - generic [ref=e46]:
              - button "Review action" [disabled] [ref=e47]
              - button "Cancel action" [ref=e48] [cursor=pointer]
          - navigation "Secondary battle tools" [ref=e49]:
            - button "Inspect party" [ref=e50] [cursor=pointer]
            - button "Battle log" [ref=e51] [cursor=pointer]
            - button "Enable sound" [active] [ref=e52] [cursor=pointer]
          - paragraph [ref=e53]: Sound off
        - generic [ref=e54]:
          - status [ref=e55]: Battle ready
          - button "Restart battle" [ref=e56] [cursor=pointer]
        - generic [ref=e57]:
          - generic [ref=e58]: Battle saved on this device
          - button "Save recovery" [ref=e59] [cursor=pointer]
        - paragraph [ref=e60]: "Gold: active · White: selected · Teal: reachable · Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Play three-encounter run" [ref=e61]:
          - /url: /run
        - group [ref=e62]:
          - generic "Privacy & analytics" [ref=e63] [cursor=pointer]
```

# Test source

```ts
  1   | import { confirmRestart } from './helpers/battlePolicy';
  2   | import { expect, test, type Page } from '@playwright/test';
  3   | import { readSession, session, playCommand, playerDecision } from './helpers/battlePolicy';
  4   | import { battleCatalog as catalog } from '../src/content/catalog';
  5   | import { replayBattle } from '../src/domain/turns';
  6   | import { battleCues, type BattleCue } from '../src/audio/battleCues';
  7   | import { LOAD_TIMEOUT_MS } from '../src/phaser/BattleAudio';
  8   | import { BATTLE_STORAGE_KEYS } from '../src/persistence/battleStorage';
  9   | import { decodeBattleSave, encodeBattleSave } from '../src/domain/saveEnvelope';
  10  | 
  11  | const audio=(page:Page)=>page.evaluate(()=>window.fitDiagnostics().battleAudio!);
  12  | async function ready(page:Page) {await expect(page.locator('#game')).toHaveAttribute('data-phase','player');}
  13  | async function enable(page:Page) {
  14  |   await page.locator('#battle-sound').click();
> 15  |   await expect.poll(()=>audio(page)).toMatchObject({enabled:true,status:'ready'});
      |                                      ^ Error: expect(received).toMatchObject(expected)
  16  | }
  17  | function errors(page:Page) {
  18  |   const found:string[]=[];
  19  |   page.on('pageerror',e=>found.push(e.message));
  20  |   page.on('console',m=>{if(m.type()==='error')found.push(m.text());});return found;
  21  | }
  22  | 
  23  | test('sound control uses real gestures, preserves previews, modal focus and restart preference',async({page})=>{
  24  |   const found=errors(page);await page.goto('/');await ready(page);
  25  |   expect(await audio(page)).toMatchObject({enabled:false,started:0,status:'muted'});
  26  |   const before=await session(page);
  27  |   await page.locator('#battle-sound').focus();await page.keyboard.press('Enter');
  28  |   await expect(page.locator('#battle-sound')).toHaveAttribute('aria-pressed','true');
  29  |   await expect.poll(()=>audio(page)).toMatchObject({status:'ready',started:0});
  30  |   expect((await session(page)).state).toEqual(before.state);
  31  |   await page.locator('#battle-sound').click();
  32  |   await page.locator('#battle-sound').scrollIntoViewIfNeeded();
  33  |   const box=(await page.locator('#battle-sound').boundingBox())!;
  34  |   expect(box.width).toBeGreaterThanOrEqual(44);expect(box.height).toBeGreaterThanOrEqual(44);
  35  |   const point={x:box.x+box.width/2,y:box.y+box.height/2};
  36  |   if(test.info().project.use.hasTouch)await page.touchscreen.tap(point.x,point.y);
  37  |   else {
  38  |     const cdp=await page.context().newCDPSession(page);
  39  |     await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...point,id:1}]});
  40  |     await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
  41  |     await cdp.detach();
  42  |   }
  43  |   await expect.poll(()=>audio(page)).toMatchObject({enabled:true,status:'ready',started:0});
  44  |   expect((await session(page)).state).toEqual(before.state);
  45  |   await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});
  46  |   await page.locator('#battle-review').click();await page.keyboard.press('Tab');
  47  |   expect(await page.evaluate(()=>!!document.activeElement?.closest('dialog'))).toBe(true);
  48  |   await page.keyboard.press('Escape');expect((await audio(page)).started).toBe(0);
  49  |   expect((await session(page)).state).toEqual(before.state);
  50  |   for(let run=2;run<=6;run++){
  51  |     if(run===4)await page.locator('#battle-sound').click();
  52  |     await page.locator('#fit-restart').click();await confirmRestart(page);await expect(page.locator('#game')).toHaveAttribute('data-run',String(run));
  53  |     await ready(page);expect((await audio(page)).enabled).toBe(run<4);
  54  |     expect((await audio(page)).ownedSounds).toBeLessThanOrEqual(8);
  55  |     await expect(page.locator('#battle-sound')).toHaveCount(1);
  56  |   }
  57  |   await page.reload();await page.locator('#save-continue').click();await ready(page);expect(await audio(page)).toMatchObject({enabled:false,started:0});expect(found).toEqual([]);
  58  | });
  59  | 
  60  | test('mute, hidden and context interruptions discard active feedback while commands finish',async({page})=>{
  61  |   // Fixed future anchors avoid a protocol round-trip racing a running Date.now().
  62  |   const start=Date.UTC(2026,0,1),found=errors(page);await page.clock.install({time:start});await page.goto('/');await ready(page);await enable(page);
  63  |   await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
  64  |   await page.clock.pauseAt(start+60000);
  65  |   const before=(await session(page)).state.commandCount;
  66  |   await page.locator('#dialog-confirm').click({force:true});
  67  |   await expect(page.locator('#game')).toHaveAttribute('data-phase','presenting');
  68  |   expect((await audio(page)).recent).toContain('move');
  69  |   await page.locator('#battle-sound').click({force:true});expect((await audio(page)).active).toBeNull();
  70  |   await page.clock.resume();await ready(page);expect((await session(page)).state.commandCount).toBe(before+1);
  71  |   await enable(page);
  72  |   await page.evaluate(()=>window.dispatchEvent(new Event('blur')));
  73  |   await expect.poll(()=>audio(page)).toMatchObject({status:'blocked',active:null});
  74  |   const count=(await audio(page)).started;
  75  |   await page.evaluate(()=>window.dispatchEvent(new Event('focus')));
  76  |   await expect.poll(()=>audio(page)).toMatchObject({status:'ready',started:count});
  77  |   await page.locator('#battle-next').click();
  78  |   await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'));});
  79  |   expect((await audio(page)).active).toBeNull();
  80  |   await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>false});document.dispatchEvent(new Event('visibilitychange'));});
  81  |   await ready(page);await page.locator('#battle-sound').click();expect((await audio(page)).enabled).toBe(false);
  82  |   await enable(page);
  83  |   await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page); // Seed 2 begins with a player.
  84  |   await page.clock.pauseAt(start+120000);
  85  |   let enemy:Awaited<ReturnType<typeof session>>|undefined;
  86  |   for(let i=0;i<12;i++) {
  87  |     const current=await session(page),command=current.replay.commands.at(-1);
  88  |     if(current.phase==='presenting' && command && current.state.units.find(u=>u.id===command.unitId)!.side==='enemy') {enemy=current;break;}
  89  |     if(current.phase==='player')await page.locator('#battle-next').click({force:true});
  90  |     await page.clock.runFor(48);
  91  |   }
  92  |   expect(enemy).toBeDefined();
  93  |   await expect(page.locator('#battle-sound')).toBeEnabled();
  94  |   await page.locator('#battle-sound').click({force:true});
  95  |   expect(await audio(page)).toMatchObject({enabled:false,active:null});expect((await session(page)).state).toEqual(enemy!.state);
  96  |   await page.clock.resume();await ready(page);
  97  |   expect(found).toEqual([]);
  98  | });
  99  | 
  100 | for(const mode of ['reject','pending'] as const) test(`gesture unlock ${mode} remains bounded and retryable`,async({page})=>{
  101 |   const found=errors(page);
  102 |   await page.addInitScript(mode=>{
  103 |     const original=AudioContext.prototype.resume;
  104 |     const state=Object.getOwnPropertyDescriptor(BaseAudioContext.prototype,'state')!.get!;
  105 |     // Guarantee Phaser sees the initial lock, even when headless autoplay starts running.
  106 |     Object.defineProperty(AudioContext.prototype,'state',{get(){return window.__allowAudio?state.call(this):'suspended';}});
  107 |     AudioContext.prototype.resume=function(){return window.__allowAudio?original.call(this):mode==='reject'?Promise.reject(Error('refused')):new Promise(()=>{});};
  108 |   },mode);
  109 |   await page.goto('/');await ready(page);await page.locator('#battle-sound').click();
  110 |   await expect.poll(()=>audio(page)).toMatchObject({status:'blocked',started:0});
  111 |   await expect(page.locator('#battle-next')).toBeEnabled();
  112 |   await page.evaluate(()=>{window.__allowAudio=true;});await page.locator('#battle-sound-retry').click();
  113 |   await expect.poll(()=>audio(page)).toMatchObject({status:'ready',started:0});expect(found).toEqual([]);
  114 | });
  115 | 
```
import { defineConfig } from '@playwright/test';
import base from './playwright.device-acceptance.config';
export default defineConfig({...base,testMatch:'**/issue-205-audio-diagnostic.spec.ts'});

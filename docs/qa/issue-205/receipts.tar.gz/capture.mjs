import { spawnSync } from 'node:child_process';
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import os from 'node:os';
import { sourceIdentity, digest, summarizePlaywright } from '../../../scripts/verification-report.mjs';
const [stage,...args]=process.argv.slice(2),root=process.cwd(),directory=resolve('tmp/verification/issue-205',stage);
mkdirSync(directory,{recursive:true});
const build=()=>Object.fromEntries(readdirSync('dist',{recursive:true,withFileTypes:true}).filter(e=>e.isFile()).map(e=>resolve(e.parentPath,e.name)).sort().map(p=>[p.slice(root.length+1),digest(readFileSync(p))]));
const before=sourceIdentity(root),buildBefore=build(),started=Date.now();
const environment={node:process.version,platform:process.platform,release:os.release(),arch:os.arch(),cpu:os.cpus()[0].model,cpus:os.cpus().length,memory:os.totalmem(),loadBefore:os.loadavg(),conditions:'Persistent local WSL workstation; warm installed browser/npm caches; one browser invocation and worker; no retries/traces. No other agent browser/build/test jobs during capture. Unrelated resident services remain; host-wide idleness is not independently established.',server:'ordinary production preview, root base, port 4173'};
writeFileSync(`${directory}/start.json`,JSON.stringify({args,before,buildBefore,environment,startedAt:new Date(started).toISOString()},null,2));
const result=spawnSync(process.execPath,['node_modules/@playwright/test/cli.js','test',...args,'--reporter=list,json',`--output=${directory}/artifacts`,'--retries=0','--trace=off'],{stdio:'inherit',env:{...process.env,PLAYWRIGHT_JSON_OUTPUT_FILE:`${directory}/results.json`}});
const after=sourceIdentity(root),buildAfter=build();
let summary;try{summary=summarizePlaywright(JSON.parse(readFileSync(`${directory}/results.json`)))}catch(error){summary={error:String(error)}}
writeFileSync(`${directory}/receipt.json`,JSON.stringify({args,before,after,buildBefore,buildAfter,buildUnchanged:JSON.stringify(buildBefore)===JSON.stringify(buildAfter),environment:{...environment,loadAfter:os.loadavg()},wallMs:Date.now()-started,exitCode:result.status,error:result.error?.message,summary},null,2));
process.exitCode=result.status??1;


import glob,json,zipfile,urllib.parse
hosts=set()
for path in glob.glob('tmp/verification/issue-205/diagnostic/artifacts/**/trace.zip',recursive=True):
    with zipfile.ZipFile(path) as archive:
        for name in archive.namelist():
            if not name.endswith('.network'): continue
            for line in archive.read(name).decode().splitlines():
                data=json.loads(line)
                url=data.get('snapshot',{}).get('request',{}).get('url')
                if url: hosts.add(urllib.parse.urlparse(url).netloc)
print(json.dumps({'trace_network_hosts':sorted(hosts)}))

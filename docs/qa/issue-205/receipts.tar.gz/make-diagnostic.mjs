import {readFileSync,writeFileSync} from 'node:fs';
let source=readFileSync('tests/battle-audio.spec.ts','utf8');
source+=`
test.beforeEach(async({page})=>{
  await page.addInitScript(()=>{
    const records:unknown[]=[];Object.assign(window,{__audioClicks:records});
    for(const type of ['pointerdown','pointerup','mousedown','mouseup','click','touchstart','touchend'])document.addEventListener(type,event=>{
      const sound=document.querySelector('#battle-sound'),rect=sound?.getBoundingClientRect();
      const snapshot=()=>({type:event.type,phase:document.querySelector('#game')?.getAttribute('data-phase'),target:(event.target as HTMLElement)?.id,trusted:event.isTrusted,path:event.composedPath().slice(0,4).map(n=>(n as HTMLElement).id??(n as HTMLElement).nodeName),pressed:sound?.getAttribute('aria-pressed'),rect:rect?.toJSON(),audio:window.fitDiagnostics?.().battleAudio});
      records.push(snapshot());queueMicrotask(()=>records.push({...snapshot(),microtask:true}));
    },true);
  });
});
test.afterEach(async({page},info)=>{await info.attach('click-events',{body:JSON.stringify(await page.evaluate(()=>(window as unknown as {__audioClicks:unknown[]}).__audioClicks)),contentType:'application/json'});});
`;
writeFileSync('tests/issue-205-audio-diagnostic.spec.ts',source);

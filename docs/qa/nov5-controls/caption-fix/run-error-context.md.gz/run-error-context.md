# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-progression.spec.ts >> run battle undo survives reload and a legal terminal journey
- Location: tests/run-progression.spec.ts:61:1

# Error details

```
Error: expect(received).toMatch(expected)

Expected pattern: /player|ended|boundary/
Received string:  "presenting"

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - main "Tactics Guru game canvas" [ref=f1e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=f1e3]
  - generic:
    - region "Battlefield":
      - generic [ref=f1e4]:
        - paragraph [ref=f1e5]: Tactics Guru
        - heading "Encounter 1 of 3 · forest ruins" [level=1] [ref=f1e6]
      - paragraph [ref=f1e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Run battle controls" [ref=f1e8]:
      - generic "Acting unit information; scroll for details" [ref=f1e9]:
        - paragraph [ref=f1e10]: Round 2 · Your turn
        - generic [ref=f1e11]:
          - img "Fighter portrait" [ref=f1e13]
          - generic [ref=f1e14]:
            - heading "Fighter" [level=2] [ref=f1e15]
            - paragraph [ref=f1e16]: HP 18/18
            - paragraph [ref=f1e19]: AC 14 · Accuracy +4
            - paragraph [ref=f1e20]: No status effects
        - paragraph [ref=f1e21]: Move ready / Action ready
      - generic "Actions, target and secondary tools; scroll for more" [ref=f1e22]:
        - generic [ref=f1e23]:
          - paragraph [ref=f1e24]: Choose your action
          - generic "Acting unit actions" [ref=f1e25]:
            - button "Move" [pressed] [ref=f1e26] [cursor=pointer]:
              - strong [ref=f1e27]: Move
              - generic [ref=f1e28]: Uses movement
            - button "Basic attack" [ref=f1e29] [cursor=pointer]:
              - strong [ref=f1e30]: Basic attack
              - generic [ref=f1e31]: Uses action
            - button "Guarded Strike" [ref=f1e32] [cursor=pointer]:
              - strong [ref=f1e33]: Guarded Strike
              - generic [ref=f1e34]: Uses action
            - button "Wait / End turn" [ref=f1e35] [cursor=pointer]:
              - strong [ref=f1e36]: Wait / End turn
              - generic [ref=f1e37]: Ends turn immediately
          - text: Ability
          - combobox "Ability" [ref=f1e38]:
            - option "Guarded Strike" [selected]
          - paragraph [ref=f1e39]: Range 1–1 · Hostile target · −2 attack / +2 AC until next turn · uses action · Second Wind unlocks at level 2; Taunt at level 3
          - paragraph [ref=f1e40]: Choose an action, then a target. Wait ends the turn immediately.
          - region "Target and action preview" [ref=f1e41]:
            - generic [ref=f1e42]: Target / destination
            - combobox "Target / destination" [ref=f1e43]:
              - option "Choose target" [selected]
              - option "(3, 9) · cost 1"
              - option "(2, 10) · cost 1"
              - option "(4, 10) · cost 1"
              - option "(3, 11) · cost 1"
              - option "(3, 8) · cost 2"
              - option "(2, 9) · cost 2"
              - option "(4, 9) · cost 2"
              - option "(1, 10) · cost 2"
              - option "(2, 11) · cost 2"
              - option "(4, 11) · cost 2"
              - option "(3, 7) · cost 3"
              - option "(2, 8) · cost 3"
              - option "(4, 8) · cost 3"
              - option "(1, 9) · cost 3"
              - option "(5, 9) · cost 3"
              - option "(0, 10) · cost 3"
              - option "(1, 11) · cost 3"
              - option "(5, 11) · cost 3"
              - option "(3, 6) · cost 4"
              - option "(2, 7) · cost 4"
              - option "(4, 7) · cost 4"
              - option "(1, 8) · cost 4"
              - option "(5, 8) · cost 4"
              - option "(0, 9) · cost 4"
              - option "(6, 9) · cost 4"
              - option "(0, 11) · cost 4"
              - option "(6, 11) · cost 4"
            - paragraph [ref=f1e44]: Select a tile
            - paragraph
            - paragraph [ref=f1e45]: Select a destination
            - generic [ref=f1e46]:
              - button "Confirm action" [disabled] [ref=f1e47]
              - button "Cancel action" [ref=f1e48] [cursor=pointer]
          - navigation "Secondary battle tools" [ref=f1e49]:
            - button "Plan move + ability" [ref=f1e50] [cursor=pointer]
            - button "Undo move" [disabled] [ref=f1e51]
            - button "Inspect party" [ref=f1e52] [cursor=pointer]
            - button "Show enemy danger" [ref=f1e53] [cursor=pointer]
            - button "Battle log" [ref=f1e54] [cursor=pointer]
            - button "Enable sound" [ref=f1e55] [cursor=pointer]
            - group [ref=f1e56]:
              - generic "More" [ref=f1e57] [cursor=pointer]
          - paragraph [ref=f1e58]: Danger shows living heroes reachable by an enemy attack or Weakening Hex on its next turn, assuming current positions and statuses; it does not predict enemy choice.
          - paragraph
          - paragraph [ref=f1e59]: Sound off
        - paragraph [ref=f1e60]: Encounter 1 of 3 · forest ruins
        - generic [ref=f1e61]:
          - status [ref=f1e62]: Battle ready
          - button "Start new run" [ref=f1e63] [cursor=pointer]
        - generic [ref=f1e64]:
          - button "Save recovery" [ref=f1e65] [cursor=pointer]
          - generic [ref=f1e66]: Run saved on this device
        - paragraph [ref=f1e67]: "Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Single battle" [ref=f1e68] [cursor=pointer]:
          - /url: /battle
        - link "Dungeon floors" [ref=f1e69] [cursor=pointer]:
          - /url: /dungeon
        - link "Main menu" [ref=f1e70] [cursor=pointer]:
          - /url: /
        - group [ref=f1e71]:
          - generic "Privacy & analytics" [ref=f1e72] [cursor=pointer]
```

# Test source

```ts
  1   | import {expect,test,type Page,installRailControls} from './helpers/forceRailControls';
  2   | import {readFileSync,writeFileSync} from 'node:fs';
  3   | import {readSession,playCommand,playUndo} from './helpers/battlePolicy';
  4   | import {playerDecision} from './helpers/playerPolicy';
  5   | import {runContext} from './helpers/runItemFixtures';
  6   | import {runBattleCatalog,type RunSnapshot} from '../src/domain/runSaveEnvelope';
  7   | import {replayRunBattle} from '../src/domain/runBattle';
  8   | // Exercise actual BFCache rather than Playwright's default disabled cache.
  9   | test.use({launchOptions:async({browserName},use)=>{
  10  |   await use({executablePath:browserName==='chromium'?process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE:undefined,ignoreDefaultArgs:['--disable-back-forward-cache']});
  11  | }});
  12  | import {legalDefeatSaves} from './helpers/runRecoveryFixtures';
  13  | import {RUN_STORAGE_KEYS} from '../src/persistence/runStorage';
  14  | async function loadLegalDefeat(page:Page){
  15  |  await test.step('reach legal outcome',async()=>{
  16  |   const {primary,backup}=legalDefeatSaves();
  17  |   await page.goto('/?game=run');
  18  |   await page.evaluate(({keys,primary,backup})=>{
  19  |    localStorage.setItem(keys.primary,primary);localStorage.setItem(keys.backup,backup);
  20  |   },{keys:RUN_STORAGE_KEYS,primary,backup});
  21  |   await page.reload();await page.locator('#run-continue').click();
  22  |   await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  23  |   expect(await page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),RUN_STORAGE_KEYS)).toEqual({primary,backup});
  24  |  });
  25  | }
  26  | async function snapshot(page:Page):Promise<RunSnapshot>{return JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);}
  27  | async function start(page:Page){
  28  |  await page.goto('/?game=run');await page.locator('#run-start').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  29  |  await expect(page.locator('#battle-actor')).toBeVisible();
  30  |  const drawable=await page.locator('#battle-board-region').boundingBox();
  31  |  expect(drawable!.width).toBeGreaterThan(0);
  32  |  expect(drawable!.height).toBeGreaterThanOrEqual(page.viewportSize()!.height*0.3-1);
  33  | }
> 34  | async function ready(page:Page){await expect.poll(async()=>await page.locator('#game').getAttribute('data-phase')??'boundary',{timeout:15000}).toMatch(/player|ended|boundary/);}
      |                                                                                                                                                ^ Error: expect(received).toMatch(expected)
  35  | async function fight(page:Page,wait=false,useDraught=false){
  36  |  let drank=false;
  37  |  for(let i=0;i<500;i++){
  38  |   await ready(page);const current=await snapshot(page);if(current.items.run.phase!=='battle')break;
  39  |   const battle=await readSession(page);expect(battle.phase).toBe('player');const catalog=runBattleCatalog(current.items,runContext)!;
  40  |   const unitId=battle.state.initiative[battle.state.activeIndex];
  41  |   if(useDraught && !drank && battle.state.draughts && await page.locator('#battle-draught').isEnabled()) {
  42  |    await playCommand(page,{type:'drinkDraught',unitId});drank=true;
  43  |   } else await playCommand(page,wait?{type:'endTurn',unitId}:playerDecision(battle.state,catalog));
  44  |  }
  45  |  await expect(page.locator('#run-screen')).toBeVisible();
  46  |  await expect(page.locator('#run-item-status')).not.toHaveText('Saving run…');
  47  |  return drank;
  48  | }
  49  | async function prepare(page:Page){
  50  |  const current=await snapshot(page),offer=current.items.offer!;
  51  |  const choice=offer.options.find(o=>o.itemId==='item:healing_draught')??offer.options[0];
  52  |  await page.getByRole('button',{name:`Claim ${runContext.items[choice.itemId].label}`,exact:true}).click();await page.locator('#item-confirm').click();
  53  |  await expect(page.locator('#run-start-encounter')).toBeVisible();
  54  |  for(const equipment of (await snapshot(page)).items.ownership.equipment){
  55  |   const now=await snapshot(page);if(now.items.ownership.assignments.some(a=>a.instanceId===equipment.instanceId))continue;
  56  |   const def=runContext.items[equipment.itemId];const hero=now.items.run.party.find(h=>h.hp>0 && def.eligibleHeroes.includes(h.heroId));
  57  |   if(hero){await page.locator(`[id="target-${equipment.instanceId}"]`).selectOption(hero.heroId);await page.getByRole('button',{name:`Equip ${def.label}`,exact:true}).click();await page.locator('#item-confirm').click();}
  58  |  }
  59  |  await expect(page.locator('#run-item-status')).not.toHaveText('Saving run…');
  60  | }
  61  | test('run battle undo survives reload and a legal terminal journey',async({page,isMobile})=>{
  62  |  test.setTimeout(300000);await start(page);const entry=await snapshot(page);
  63  |  const catalog=runBattleCatalog(entry.items,runContext)!;const restored=await playUndo(page,catalog,isMobile);
  64  |  await page.reload();await page.locator('#run-continue').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  65  |  expect((await readSession(page)).state).toEqual(restored);await expect(page.locator('#battle-undo')).toBeDisabled();
  66  |  await fight(page,true);await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  67  |  await page.reload();await page.locator('#run-continue').click();await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  68  |  await page.locator('#run-new').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  69  | });
  70  | test('legal run outcomes, earned rewards, terminal resume and fresh restart',async({page})=>{
  71  |  test.setTimeout(300000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await start(page);await page.locator('#battle-sound').click();const records=[];let usedDraught=false;
  72  |  for(let index=0;index<3;index++){
  73  |   // Each encounter constructs a fresh shared renderer; prior selections cannot leak.
  74  |   const board=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  75  |   expect(board.selected).toBeNull();expect(board.selectionEvents).toBe(0);
  76  |   await expect(page.locator('#battle-move')).toHaveAttribute('aria-pressed','true');
  77  |   await expect(page.locator('#battle-target')).toHaveValue('');await expect(page.locator('#battle-review')).toBeDisabled();
  78  |   const runBefore=await snapshot(page);
  79  |   const corner=board.tiles.find((t:{x:number;y:number})=>t.x===11&&t.y===11);
  80  |   const x=(corner.x-corner.y)*40,y=(corner.x+corner.y)*20-corner.elevation*24;
  81  |   await page.mouse.click(board.transform.x+x*board.transform.scale,board.transform.y+y*board.transform.scale);
  82  |   expect(JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!).selected).toEqual({x:11,y:11,elevation:corner.elevation});
  83  |   expect(await snapshot(page)).toEqual(runBefore);
  84  |   // Each new scene owns exactly its current actor cue; a finished encounter tears it down.
  85  |   await expect.poll(async()=>{
  86  |    const report=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  87  |    const actor=report.units.find((unit:any)=>unit.id===report.activeId);
  88  |    expect(report.units.filter((unit:any)=>unit.id!==report.activeId).every((unit:any)=>unit.bobOffset===0)).toBe(true);
  89  |    return actor.bobOffset;
  90  |   }).toBeLessThan(-0.2);
  91  |   const beforeBob=await snapshot(page);
  92  |   await page.screenshot({path:test.info().outputPath(`encounter-${index+1}-active-bob.png`)});
  93  |   expect(await snapshot(page)).toEqual(beforeBob);
  94  |   usedDraught=(await fight(page,false,true))||usedDraught;
  95  |   await expect(page.locator('#game')).not.toHaveAttribute('data-battle-report');if(index===0)await page.screenshot({path:test.info().outputPath('run-reward.png')});const current=await snapshot(page);expect(index===2?['victory','defeat']:['reward','defeat']).toContain(current.items.run.phase);expect(current.items.run.encounterIndex).toBe(index);
  96  |   const record=JSON.parse((await page.locator('#game').getAttribute('data-run-battle-record'))!);const replay=replayRunBattle(record.replay,record.entry,runContext);expect(replay.ok).toBe(true);if(replay.ok){expect(replay.state).toEqual(record.state);expect(replay.events).toEqual(record.events);}records.push(record);
  97  |   if(current.items.run.phase==='defeat')break;
  98  |   if(index<2){
  99  |    // The pending offer and claimed/prepared boundary survive the real Continue path.
  100 |    if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(current);}
  101 |    await prepare(page);const prepared=await snapshot(page);if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(prepared);}
  102 |    await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  103 |    await expect(page.locator('#battle-sound')).toHaveAttribute('aria-pressed',index===0?'true':'false');
  104 |   }
  105 |  }
  106 |  const final=await snapshot(page);await expect(page.getByRole('heading',{name:final.items.run.phase==='victory'?'Run victory':'Run defeat',exact:true})).toBeVisible();
  107 |  expect(usedDraught).toBe(true);
  108 |  expect(final.items.ownership.consumables.some(stack=>stack.itemId==='item:healing_draught')).toBe(false);
  109 |  await page.screenshot({path:test.info().outputPath('run-terminal.png')});
  110 |  writeFileSync(test.info().outputPath('run-records.json'),JSON.stringify(records,null,2));
  111 |  await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(final);
  112 |  await page.locator('#run-new').dblclick();await expect(page.locator('#run-start-encounter')).toBeVisible();const fresh=await snapshot(page);expect(fresh.items.run.seed).toBe(14);expect(fresh.items.run.id).not.toBe(final.items.run.id);expect(fresh.items.ownership).toEqual({consumables:[],equipment:[],assignments:[]});expect(fresh.items.run.party.every(h=>h.hp===runContext.catalog.heroes[h.heroId].stats.maxHp)).toBe(true);
  113 |  expect(errors).toEqual([]);
  114 | });
  115 | test('testing routes: an earned combat draught stays in the transient authored run',async({page})=>{
  116 |  test.setTimeout(300000);
  117 |  const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  118 |  await page.addInitScript(()=>{
  119 |   const get=Storage.prototype.getItem,set=Storage.prototype.setItem,remove=Storage.prototype.removeItem;
  120 |   const saved=(key:string)=>key.startsWith('tactics-guru:phaser:')||key==='tactics-guru:menu-new-dungeon-review';
  121 |   const attempts:string[]=[];
  122 |   (window as unknown as Record<string, unknown>).__draughtSaveAttempts=attempts;
  123 |   Storage.prototype.getItem=function(key){if(saved(key)){attempts.push('read');throw Error('Testing route read saved gameplay');}return get.call(this,key);};
  124 |   Storage.prototype.setItem=function(key,value){if(saved(key)){attempts.push('write');throw Error('Testing route wrote saved gameplay');}set.call(this,key,value);};
  125 |   Storage.prototype.removeItem=function(key){if(saved(key)){attempts.push('remove');throw Error('Testing route removed saved gameplay');}remove.call(this,key);};
  126 |  });
  127 |  await page.goto('./run');
  128 |  await page.locator('#run-start').click();
  129 |  await page.locator('#run-start-encounter').click();
  130 |  await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  131 |  await fight(page);
  132 |  await expect(page.getByRole('button',{name:'Claim Healing Draught',exact:true})).toBeVisible();
  133 |  await prepare(page);
  134 |  await page.locator('#run-start-encounter').click();
```
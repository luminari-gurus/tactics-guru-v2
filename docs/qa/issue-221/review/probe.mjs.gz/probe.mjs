import {readFileSync, writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const path='tests/battle-animations.spec.ts';
const original=readFileSync(path);
const source=original.toString();
const marker='  const actorTransitionStarted = await page.evaluate(() => Date.now());';
if(source.split(marker).length!==2)throw Error('Actor boundary marker must occur exactly once');
const gate=`  // Temporary review probe: withhold only the DOM readiness signal for 3.5s.
  await page.evaluate(() => {
    const game = document.querySelector('#game')!;
    let actual = game.getAttribute('data-phase')!;
    const observer = new MutationObserver(() => {
      const phase = game.getAttribute('data-phase')!;
      if (phase !== 'review-delay') { actual = phase; game.setAttribute('data-phase', 'review-delay'); }
    });
    observer.observe(game, {attributes: true, attributeFilter: ['data-phase']});
    game.setAttribute('data-phase', 'review-delay');
    setTimeout(() => { observer.disconnect(); game.setAttribute('data-phase', actual); }, 3500);
  });
`;
const injected=source.replace(marker,gate+marker);
const control=injected.replace("  await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player', {timeout: 3000});",'  await ready(page);').replace('  expect(await page.evaluate(() => Date.now()) - actorTransitionStarted).toBeLessThanOrEqual(3000);','');
const summaries=[];
try {
  for(const [name,text] of [['bound-rejects-delay',injected],['old-bound-control',control]]){
    writeFileSync(path,text);
    writeFileSync(`tmp/issue-223-review/${name}.spec.ts.txt`,text);
    const args=['node_modules/@playwright/test/cli.js','test',path,'--project=desktop','--grep','active bob: presentation, actor change, hidden page and restart restore anchors without duplicate loops$','--workers=1','--retries=0','--trace=off','--reporter=list,json',`--output=tmp/issue-223-review/${name}-artifacts`];
    const result=spawnSync(process.execPath,args,{encoding:'utf8',env:{...process.env,PLAYWRIGHT_JSON_OUTPUT_FILE:`tmp/issue-223-review/${name}.json`}});
    writeFileSync(`tmp/issue-223-review/${name}.log`,result.stdout+result.stderr);
    const report=JSON.parse(readFileSync(`tmp/issue-223-review/${name}.json`));
    const tests=report.suites.flatMap(s=>s.specs??[]).flatMap(s=>s.tests??[]);
    const errors=tests.flatMap(t=>t.results.flatMap(r=>r.errors??[])).map(e=>e.message??'').join('\n');
    const correct=name==='bound-rejects-delay'?result.status===1&&report.stats.unexpected===1&&/3000ms/.test(errors)&&/review-delay/.test(errors):result.status===0&&report.stats.expected===1;
    const summary={name,command:[process.execPath,...args],exitCode:result.status,stats:report.stats,correct,sourceSha256:createHash('sha256').update(text).digest('hex'),errors};
    summaries.push(summary);
    console.log(JSON.stringify(summary));
    if(!correct)throw Error(`Unexpected ${name} result`);
  }
} finally {
  writeFileSync(path,original);
  writeFileSync('tmp/issue-223-review/probe-summary.json',JSON.stringify({originalSha256:createHash('sha256').update(original).digest('hex'),restored:readFileSync(path).equals(original),results:summaries},null,2)+'\n');
}

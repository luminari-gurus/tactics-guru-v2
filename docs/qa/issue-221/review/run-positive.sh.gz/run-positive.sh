#!/usr/bin/env bash
set -euo pipefail
cd /mnt/c/Users/apexw/OneDrive/Desktop/Projects/Tactics-Guru
mkdir -p tmp/issue-223-review
npm run check:browsers 2>&1 | tee tmp/issue-223-review/environment.log
node --input-type=module <<'JS'
import {execFileSync} from 'node:child_process';
import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import os from 'node:os';
const git=(...args)=>execFileSync('git',args,{encoding:'utf8'}).trim();
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
const files=git('ls-files','src','tests','public','scripts','package.json','package-lock.json','*config*').split('\n');
const walk=dir=>readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(`${dir}/${e.name}`):[`${dir}/${e.name}`]);
writeFileSync('tmp/issue-223-review/source-build.json',JSON.stringify({createdAt:new Date().toISOString(),commit:git('rev-parse','HEAD'),base:git('rev-parse','origin/main'),dirty:!!git('status','--porcelain'),node:process.version,npm:execFileSync('npm',['--version'],{encoding:'utf8'}).trim(),platform:os.platform(),release:os.release(),arch:os.arch(),cpu:os.cpus()[0].model,cpus:os.cpus().length,memory:os.totalmem(),load:os.loadavg(),workers:1,retries:0,trace:'off',mode:'preview',basePath:'/',flags:Object.fromEntries(['PLAYWRIGHT_CHROMIUM_EXECUTABLE','PLAYWRIGHT_SERVER_MODE','PLAYWRIGHT_BASE_PATH','PLAYWRIGHT_TELEMETRY_DEV'].map(k=>[k,process.env[k]??null])),inputs:Object.fromEntries(files.map(f=>[f,hash(f)])),build:Object.fromEntries(walk('dist').map(f=>[f,hash(f)]))},null,2)+'\n');
JS
reported='(hovered origins show only ability reach without changing selection, pending commands or saves|selection labels retain the zoomed and panned camera without gameplay commands|active bob: targets, cancel, inspection, camera and live reduced motion preserve authoritative state|active bob: presentation, actor change, hidden page and restart restore anchors without duplicate loops)$'
neighbors='(target overlays follow invalid selection, action changes, keyboard, cancellation and board taps without resolving commands|active bob: initial reduced motion keeps sprite and static actor marker anchored|authored camera keeps zoom bounds and refits on real orientation changes|default authored board renders canonical units, highlights and stable restarts)$'
npx --no-install playwright test tests/battle-board.spec.ts tests/battle-animations.spec.ts --grep "$reported" --list 2>&1 | tee tmp/issue-223-review/discovery.log
npm run test:browser -- tests/battle-board.spec.ts tests/battle-animations.spec.ts --grep "$reported" --workers=1 2>&1 | tee tmp/issue-223-review/reported.log
npm run test:browser -- tests/battle-board.spec.ts tests/battle-animations.spec.ts --grep "$neighbors" --workers=1 2>&1 | tee tmp/issue-223-review/neighbors.log

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-progression.spec.ts >> review: in-flow Continue resumes an ongoing backup battle after legal defeat
- Location: tests/run-progression.spec.ts:185:1

# Error details

```
TypeError: Cannot read properties of null (reading 'continuation')
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - main "Tactics Guru game canvas" [ref=f1e2]
  - generic:
    - region "Battlefield":
      - generic [ref=f1e4]:
        - paragraph [ref=f1e5]: Tactics Guru
        - heading "Encounter 1 of 3 · forest ruins" [level=1] [ref=f1e6]
      - paragraph [ref=f1e7]: "Gold: active · White: selected · Teal: reachable"
    - complementary "Run battle controls" [ref=f1e8]:
      - generic "Actions, target and secondary tools; scroll for more" [ref=f1e9]:
        - generic [ref=f1e10]:
          - paragraph
          - generic [ref=f1e11]:
            - button "Move" [disabled] [ref=f1e12]
            - button "Wait / End turn" [disabled] [ref=f1e13]
            - generic [ref=f1e14]: Select a tile
        - paragraph [ref=f1e15]: Encounter 1 of 3 · forest ruins
        - generic [ref=f1e16]:
          - status [ref=f1e17]: Loading
          - button "Start new run" [disabled] [ref=f1e18]
        - generic [ref=f1e19]:
          - button "Save recovery" [ref=f1e20] [cursor=pointer]
          - generic [ref=f1e21]: Continued backup. Some progress may be lost.
        - paragraph [ref=f1e22]: "Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Single battle" [ref=f1e23] [cursor=pointer]:
          - /url: /
        - link "Dungeon floors" [ref=f1e24] [cursor=pointer]:
          - /url: /dungeon
        - group [ref=f1e25]:
          - generic "Privacy & analytics" [ref=f1e26] [cursor=pointer]
```

# Test source

```ts
  99  |  await page.locator('#run-new').dblclick();const fresh=await snapshot(page);expect(fresh.items.run.seed).toBe(14);expect(fresh.items.run.id).not.toBe(final.items.run.id);expect(fresh.items.ownership).toEqual({consumables:[],equipment:[],assignments:[]});expect(fresh.items.run.party.every(h=>h.hp===runContext.catalog.heroes[h.heroId].stats.maxHp)).toBe(true);
  100 |  expect(errors).toEqual([]);
  101 | });
  102 | test('legal defeat reload, native keyboard restart and isolated single-battle save',async({page})=>{
  103 |  test.setTimeout(180000);await start(page);await fight(page,true);await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  104 |  const ended=await snapshot(page);await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(ended);
  105 |  await page.locator('#run-new').focus();await page.keyboard.press('Enter');await expect(page.locator('#run-start-encounter')).toBeVisible();
  106 |  await page.getByRole('link',{name:'Single battle',exact:true}).click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  107 |  const run=await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary);expect(JSON.parse(run!).payload.items.run.encounterIndex).toBe(0);
  108 |  await page.getByRole('link',{name:'Play three-encounter run'}).click();await page.locator('#run-continue').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  109 | });
  110 | test('accepted player presentation reload preserves exact boundary without old cues',async({page})=>{
  111 |  await start(page);await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});
  112 |  await page.clock.install();await page.clock.pauseAt(new Date(Date.now()+1000));await page.locator('#battle-review').click({force:true});
  113 |  await expect(page.locator('#game')).toHaveAttribute('data-phase','presenting');const committed=await snapshot(page);
  114 |  await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  115 |  expect((await readSession(page)).state).toEqual(committed.activeBattle);expect((await readSession(page)).events).toEqual([]);expect(await page.evaluate(()=>window.fitDiagnostics().battleAudio?.lastToken)).toBe(0);
  116 |  await expect(page.locator('#battle-move')).toBeDisabled();await expect(page.locator('#battle-move')).toHaveAttribute('aria-pressed','false');
  117 | });
  118 | test('enemy presentation reload resumes the same commands and RNG as an uninterrupted run',async({page,browser,baseURL})=>{
  119 |  const other=await browser.newContext({viewport:page.viewportSize(),baseURL});const control=await other.newPage();
  120 |  try {
  121 |   for(const p of [page,control]){
  122 |    await p.clock.install();await start(p);await p.clock.pauseAt(await p.evaluate(()=>Date.now()+1000));
  123 |    for(let i=0;i<100;i++){
  124 |     const s=await readSession(p),last=s.replay?.commands.at(-1);
  125 |     if(s.phase==='presenting' && last && s.state.units.find(u=>u.id===last.unitId)!.side==='enemy')break;
  126 |     if(s.phase==='player')await p.locator('#battle-next').click({force:true});
  127 |     await p.clock.runFor(32);
  128 |    }
  129 |   }
  130 |   const boundary=await readSession(page);expect(boundary.phase).toBe('presenting');const last=boundary.replay!.commands.at(-1)!;expect(boundary.state.units.find(u=>u.id===last.unitId)!.side).toBe('enemy');
  131 |   expect((await readSession(control)).state).toEqual(boundary.state);
  132 |   await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await control.clock.resume();
  133 |   for(const p of [page,control])await expect(p.locator('#game')).toHaveAttribute('data-phase','player');
  134 |   const resumed=await readSession(page),uninterrupted=await readSession(control);expect(resumed.state).toEqual(uninterrupted.state);
  135 |   const catalog=runBattleCatalog((await snapshot(page)).items,runContext)!;const command=playerDecision(resumed.state,catalog);
  136 |   for(const p of [page,control]){await playCommand(p,command);await expect(p.locator('#game')).toHaveAttribute('data-phase','player');}
  137 |   expect((await readSession(page)).state).toEqual((await readSession(control)).state);
  138 |  }finally{await other.close();}
  139 | });
  140 | test('run startup preserves corrupt bytes, recovery captures input, and unavailable storage permits unsaved play',async({page})=>{
  141 |  await page.goto('/run');
  142 |  await expect(page.locator('#run-start')).toBeVisible();
  143 |  expect(await page.evaluate(keys=>keys.map(key=>localStorage.getItem(key)),Object.values(RUN_STORAGE_KEYS))).toEqual([null,null]);
  144 |  expect((await snapshot(page)).activeBattle).toBeNull();
  145 |  await page.evaluate(key=>localStorage.setItem(key,'{bad'),RUN_STORAGE_KEYS.primary);await page.reload();
  146 |  expect(await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary)).toBe('{bad');
  147 |  await page.locator('#run-recovery').click();await expect(page.getByRole('dialog')).toContainText('primary: invalid');
  148 |  const visited=new Set<string>();
  149 |  for(const key of ['Tab','Shift+Tab'])for(let i=0;i<8;i++){
  150 |   await page.keyboard.press(key);expect(await page.evaluate(()=>!!document.activeElement?.closest('dialog'))).toBe(true);
  151 |   visited.add(await page.evaluate(()=>document.activeElement!.id));
  152 |  }
  153 |  for(const id of await page.getByRole('dialog').getByRole('button').evaluateAll(buttons=>buttons.map(b=>b.id)))expect(visited.has(id)).toBe(true);
  154 |  await page.locator('#run-close-recovery').click();await page.locator('#run-start').click();await page.locator('#run-confirm-new').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  155 |  await page.reload();await page.addInitScript(()=>{Object.defineProperty(window,'localStorage',{get(){throw new DOMException('denied','SecurityError');}});});await page.reload();
  156 |  await page.locator('#run-unsaved').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-persistence')).toContainText('unsaved');
  157 | });
  158 | test('run preparation and dialogs retain 44px controls, native touch and narrow layout',async({page},info)=>{
  159 |  await page.goto('/run');const activate=async(selector:string)=>{if(info.project.use.hasTouch)await page.locator(selector).tap();else await page.locator(selector).click();};
  160 |  await activate('#run-start');await expect(page.locator('#run-start-encounter')).toBeVisible();
  161 |  for(const viewport of [{width:320,height:568},{width:915,height:412},{width:412,height:915}]){
  162 |   await page.setViewportSize(viewport);
  163 |   const boxes=await page.locator('#run-screen button,#run-screen a,#run-screen select').evaluateAll(nodes=>nodes.filter(n=>n.getClientRects().length).map(n=>{n.scrollIntoView({block:'nearest'});const r=n.getBoundingClientRect();return{width:r.width,height:r.height,left:r.left,right:r.right};}));
  164 |   for(const box of boxes){expect(box.width).toBeGreaterThanOrEqual(44);expect(box.height).toBeGreaterThanOrEqual(44);expect(box.left).toBeGreaterThanOrEqual(0);expect(box.right).toBeLessThanOrEqual(viewport.width);}
  165 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  166 |  }
  167 |  await activate('#run-start-encounter');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  168 |  await page.locator('#fit-restart').click();await expect(page.getByRole('dialog')).toBeVisible();const before=await snapshot(page);await page.mouse.click(3,3);expect(await snapshot(page)).toEqual(before);await page.locator('#run-cancel-new').click();
  169 |  await expect(page.locator('#fit-restart')).toBeFocused();
  170 |  await page.locator('#battle-sound').click();await page.locator('#fit-restart').click();await page.locator('#run-confirm-new').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-sound')).toHaveAttribute('aria-pressed','true');
  171 | });
  172 | 
  173 | test('cached run return cannot overwrite either slot of a newer replacement',async({page,context,baseURL})=>{
  174 |  await start(page);const first=(await snapshot(page)).items.run.id;
  175 |  await page.goto(new URL('map',baseURL).href);await expect(page.locator('#map-grid span')).toHaveCount(400);
  176 |  const replacement=await context.newPage();await replacement.goto('/run');
  177 |  await replacement.locator('#run-start').click();await replacement.locator('#run-confirm-new').click();
  178 |  const fresh=await snapshot(replacement);expect(fresh.items.run.id).not.toBe(first);expect(fresh.items.run.seed).toBe(14);
  179 |  const stored=()=>page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),RUN_STORAGE_KEYS);
  180 |  const before=await stored();await replacement.close();await page.goBack({waitUntil:'commit'});
  181 |  await expect(page.locator('#run-continue')).toBeVisible();expect(await stored()).toEqual(before);
  182 |  await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(fresh);
  183 | });
  184 | 
  185 | test('review: in-flow Continue resumes an ongoing backup battle after legal defeat',async({page})=>{
  186 |  await loadLegalDefeat(page);
  187 |  await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  188 |  const backup=await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.backup);
  189 |  const expected=JSON.parse(backup!).payload.activeBattle;expect(expected.outcome).toBe('ongoing');
  190 |  await page.getByRole('button',{name:'Save recovery',exact:true}).click();
  191 |  await page.getByRole('dialog').getByRole('button',{name:'Remove primary save',exact:true}).click();
  192 |  await page.getByRole('dialog').getByRole('button',{name:'Remove reviewed save',exact:true}).click();
  193 |  if(await page.getByRole('dialog').isVisible())await page.getByRole('dialog').getByRole('button',{name:/^(Close|Cancel)$/}).click();
  194 |  await page.getByRole('button',{name:'Continue saved run',exact:true}).click();
  195 |  await page.clock.install();await page.clock.pauseAt(await page.evaluate(()=>Date.now()+1000));
  196 |  await page.getByRole('dialog').getByRole('button',{name:'Continue',exact:true}).click({force:true});
  197 |  await page.clock.runFor(32);
  198 |  await expect(page.locator('#run-screen')).toBeHidden();await expect(page.locator('#game')).toHaveCSS('visibility','visible');
> 199 |  expect((await readSession(page)).continuation?.snapshot).toEqual(expected);expect(await page.locator('canvas').count()).toBe(1);
      |                                   ^ TypeError: Cannot read properties of null (reading 'continuation')
  200 |  await page.clock.resume();await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  201 | });
  202 | test('review: read-level SecurityError permits explicit unsaved play without changing inaccessible bytes',async({page})=>{
  203 |  await page.goto('/run');await page.evaluate(keys=>{localStorage.setItem(keys.primary,'preserve primary');localStorage.setItem(keys.backup,'preserve backup');},RUN_STORAGE_KEYS);
  204 |  await page.addInitScript(keys=>{
  205 |   const read=Storage.prototype.getItem,write=Storage.prototype.setItem,remove=Storage.prototype.removeItem,calls:string[]=[];
  206 |   const owns=(key:string)=>Object.values(keys).some(value=>value===key);
  207 |   Storage.prototype.getItem=function(key){if(owns(key))throw new DOMException('Read denied','SecurityError');return read.call(this,key);};
  208 |   Storage.prototype.setItem=function(key,value){if(owns(key))calls.push('write:'+key);return write.call(this,key,value);};
  209 |   Storage.prototype.removeItem=function(key){if(owns(key))calls.push('remove:'+key);return remove.call(this,key);};
  210 |   Object.assign(window,{reviewReadEvidence:()=>({primary:read.call(localStorage,keys.primary),backup:read.call(localStorage,keys.backup),calls})});
  211 |  },RUN_STORAGE_KEYS);
  212 |  await page.reload();await expect(page.locator('#run-continue')).toHaveCount(0);
  213 |  await page.locator('#run-recovery').click();await expect(page.getByRole('dialog')).toContainText('primary: unavailable. backup: unavailable');await page.getByRole('button',{name:'Close',exact:true}).click();
  214 |  await page.locator('#run-unsaved').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  215 |  await page.locator('#battle-next').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-persistence')).toContainText('unsaved');
  216 |  expect(await page.evaluate(()=>(window as unknown as {reviewReadEvidence:()=>unknown}).reviewReadEvidence())).toEqual({primary:'preserve primary',backup:'preserve backup',calls:[]});
  217 | });
  218 | test('review: reopened outcome recovery exports the exact retained backup after partial reset',async({page})=>{
  219 |  await loadLegalDefeat(page);const ended=await snapshot(page);
  220 |  const saved=await page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),RUN_STORAGE_KEYS);expect(saved.backup).not.toBeNull();
  221 |  await page.evaluate(primary=>{const remove=Storage.prototype.removeItem;Storage.prototype.removeItem=function(key){if(key===primary)throw new DOMException('Removal denied','SecurityError');return remove.call(this,key);};},RUN_STORAGE_KEYS.primary);
  222 |  await page.locator('#run-new').click();await expect(page.getByRole('button',{name:'Export backup save',exact:true})).toBeVisible();
  223 |  await page.getByRole('button',{name:'Close',exact:true}).click();await page.getByRole('button',{name:'Save recovery',exact:true}).click();
  224 |  await expect(page.getByRole('button',{name:'Export backup save',exact:true})).toBeVisible();
  225 |  const downloadPromise=page.waitForEvent('download');await page.getByRole('button',{name:'Export backup save',exact:true}).click();const download=await downloadPromise;
  226 |  expect(JSON.parse(readFileSync((await download.path())!,'utf8'))).toEqual({slot:'backup',text:saved.backup});
  227 |  expect(await snapshot(page)).toEqual(ended);
  228 |  expect(await page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),RUN_STORAGE_KEYS)).toEqual({primary:saved.primary,backup:null});
  229 | });
  230 | for(const dismiss of ['Escape','Close'] as const)test(`review: recovery dismissal via ${dismiss} retains connected visible keyboard focus`,async({page})=>{
  231 |  async function checkFocus(){
  232 |   const recovery=page.getByRole('button',{name:'Save recovery',exact:true});const before=await snapshot(page);
  233 |   await recovery.focus();await page.keyboard.press('Enter');await expect(page.getByRole('dialog')).toBeVisible();
  234 |   if(before.activeBattle){
  235 |    const viewport=page.viewportSize()!;
  236 |    await page.setViewportSize({width:viewport.height,height:viewport.width});
  237 |    await page.setViewportSize(viewport);
  238 |   }
  239 |   if(dismiss==='Escape')await page.keyboard.press('Escape');
  240 |   else {await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).focus();await page.keyboard.press('Enter');}
  241 |   await expect(page.getByRole('dialog')).not.toBeVisible();await expect(recovery).toBeVisible();await expect(recovery).toBeFocused();await expect(recovery).toBeInViewport();
  242 |   expect(await recovery.evaluate(node=>node.isConnected && document.activeElement===node)).toBe(true);expect(await snapshot(page)).toEqual(before);
  243 |  }
  244 |  await page.goto('/run');await page.locator('#run-start').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  245 |  await checkFocus(); // The mounted preparation controls are replaced on dismissal.
  246 |  await page.reload();await expect(page.locator('#run-continue')).toBeVisible();await checkFocus();
  247 |  await page.locator('#run-continue').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  248 |  await checkFocus(); // Battle controls stay mounted and keep their existing return behavior.
  249 | });
  250 | 
  251 | for(const exit of ['Cancel','Escape','Export'] as const)test(`review repair: startup Continue survives ${exit}`,async({page})=>{
  252 |  await page.goto('/run');await page.locator('#run-start').click();
  253 |  const saved=await snapshot(page);expect(saved.items.run.seed).toBe(13);
  254 |  const bytes=await page.evaluate(keys=>Object.values(keys).map(k=>localStorage.getItem(k)),RUN_STORAGE_KEYS);
  255 |  await page.reload();
  256 |  if(exit==='Export'){
  257 |   await page.locator('#run-recovery').click();const pending=page.waitForEvent('download');
  258 |   await page.getByRole('button',{name:'Export primary save',exact:true}).click();const download=await pending;
  259 |   expect(JSON.parse(readFileSync((await download.path())!,'utf8')).text).toBe(bytes[0]);
  260 |  }else{
  261 |   await page.locator('#run-start').click();
  262 |   if(exit==='Cancel')await page.locator('#run-cancel-new').click();else await page.keyboard.press('Escape');
  263 |  }
  264 |  await expect(page.getByRole('dialog')).not.toBeVisible();
  265 |  await page.locator('#run-continue').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  266 |  expect(await snapshot(page)).toEqual(saved);
  267 |  expect(await page.evaluate(keys=>Object.values(keys).map(k=>localStorage.getItem(k)),RUN_STORAGE_KEYS)).toEqual(bytes);
  268 | });
  269 | 
  270 | test('review repair: deleting both loaded slots starts a fresh playable run',async({page})=>{
  271 |  await start(page);const old=await snapshot(page);await page.reload();await page.locator('#run-recovery').click();
  272 |  for(const slot of ['primary','backup']){await page.locator('#run-remove-'+slot).click();await page.locator('#run-confirm-remove').click();}
  273 |  expect(await page.evaluate(keys=>Object.values(keys).map(k=>localStorage.getItem(k)),RUN_STORAGE_KEYS)).toEqual([null,null]);
  274 |  await page.locator('#run-close-recovery').click();await page.locator('#run-start').click();
  275 |  await expect(page.locator('#run-start-encounter')).toBeVisible();const fresh=await snapshot(page);
  276 |  expect(fresh.items.run.id).not.toBe(old.items.run.id);expect(fresh.items.run.seed).toBe((old.items.run.seed+1)>>>0);
  277 |  expect(fresh.activeBattle).toBeNull();expect(fresh.items.ownership).toEqual({consumables:[],equipment:[],assignments:[]});
  278 |  expect(fresh.items.run.party.every(h=>h.hp===runContext.catalog.heroes[h.heroId].stats.maxHp)).toBe(true);
  279 |  await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  280 |  await page.screenshot({path:test.info().outputPath('fresh-after-removal.png')});
  281 | });
  282 | 
  283 | for(const choice of ['continue','replace'] as const)test(`review repair: recovered storage preserves unsaved bytes until explicit ${choice}`,async({page})=>{
  284 |  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  285 |  await page.goto('/run');await page.locator('#run-start').click();await page.reload();
  286 |  await page.locator('#run-start').click();await page.locator('#run-confirm-new').click();
  287 |  const saved=await snapshot(page);expect(saved.items.run.seed).toBe(14);
  288 |  const bytes=await page.evaluate(keys=>Object.values(keys).map(k=>localStorage.getItem(k)),RUN_STORAGE_KEYS);
  289 |  await page.addInitScript(keys=>{
  290 |   Object.assign(window,{denyRunReads:true});const read=Storage.prototype.getItem;
  291 |   Storage.prototype.getItem=function(key){if((window as unknown as {denyRunReads:boolean}).denyRunReads && Object.values(keys).some(value=>value===key))throw new DOMException('Read denied','SecurityError');return read.call(this,key);};
  292 |  },RUN_STORAGE_KEYS);
  293 |  await page.reload();await page.locator('#run-unsaved').click();await page.locator('#run-start-encounter').click();
  294 |  await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  295 |  await page.evaluate(()=>Object.assign(window,{denyRunReads:false}));
  296 |  for(let i=0;i<2;i++){await page.locator('#battle-next').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');}
  297 |  expect(await page.evaluate(keys=>Object.values(keys).map(k=>localStorage.getItem(k)),RUN_STORAGE_KEYS)).toEqual(bytes);
  298 |  await expect(page.locator('#battle-persistence')).toContainText('unsaved');
  299 |  await page.getByRole('button',{name:'Save recovery',exact:true}).click();await page.locator('#run-retry-save').click();
```
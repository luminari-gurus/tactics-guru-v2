# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dungeon-exploration.spec.ts >> cold progression-format Continue retains a long saved history within the startup budget
- Location: tests/dungeon-exploration.spec.ts:230:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 2500
Received:    3844
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - main "Tactics Guru game canvas" [ref=f1e2]
  - main [ref=f1e4]:
    - heading "Dungeon · Floor 250 · Desert" [level=1] [ref=f1e5]
    - paragraph [ref=f1e6]: Three encounters per floor. Explore to find the next encounter. Defeat the goblin guardian to unlock the stairs.
    - status [ref=f1e7]: Continued saved dungeon
    - region "Floor exploration" [ref=f1e8]:
      - heading "Explore Desert · Floor 250" [level=2] [ref=f1e9]
      - generic [ref=f1e10]:
        - text: Map art
        - combobox "Map art" [ref=f1e11]:
          - option "Simple" [selected]
          - option "Legacy 8-bit"
      - paragraph [ref=f1e12]: ● Player · M encounter (including guardian) · ✓ cleared · ↑ upstairs (floor 2+) · ↓ downstairs (guardian defeated). Reveal reaches two cells, including through walls. Tap adjacent cells or use direction controls.
      - application "Floor 250 map. Player row 2, column 3. Arrow or WASD keys move one cell." [ref=f1e13]:
        - generic [aria-hidden] [ref=f1e36]: ●
      - group "Move player" [ref=f1e414]:
        - button "North" [disabled] [ref=f1e415]:
          - generic: "N"
        - button "East" [ref=f1e416] [cursor=pointer]:
          - generic: E
        - button "South" [ref=f1e417] [cursor=pointer]:
          - generic: S
        - button "West" [disabled] [ref=f1e418]:
          - generic: W
      - status [ref=f1e419]: Player cell 22 · Revealed 12/400 · Visited 1.
      - list "Discovered places" [ref=f1e420]:
        - listitem [ref=f1e421]: Upstairs · row 2, column 3 · Available · Visited
    - region "Stairs" [ref=f1e422]:
      - heading "Stairs" [level=2] [ref=f1e423]
      - paragraph [ref=f1e424]: Move onto an available stair to travel automatically. On arrival or after continuing a save, move off and back onto the stair to travel again. Upstairs is unavailable on floor 1.
      - paragraph [ref=f1e425]: Defeat the guardian and claim pending rewards to unlock descent.
    - region "Party" [ref=f1e426]:
      - heading "Party" [level=2] [ref=f1e427]
      - paragraph [ref=f1e428]: "fighter: 18/18 HP · Level 1 · XP 0/60 · Learned: basic attack, guarded strike · Accuracy 4 · Armor class 14"
      - paragraph [ref=f1e429]: "ranger: 12/12 HP · Level 1 · XP 0/60 · Learned: basic attack, high shot · Accuracy 5 · Armor class 12"
      - paragraph [ref=f1e430]: "mage: 11/11 HP · Level 1 · XP 0/60 · Learned: basic attack, magic missile · Accuracy 3 · Armor class 11"
    - region "Owned items" [ref=f1e431]:
      - heading "Owned items" [level=2] [ref=f1e432]
      - paragraph [ref=f1e433]: Charms 0/6 · Discard a charm with confirmation to free space.
      - paragraph [ref=f1e434]: No owned items yet.
    - button "Save recovery" [ref=f1e435] [cursor=pointer]
    - button "Start new dungeon" [ref=f1e436] [cursor=pointer]
    - navigation [ref=f1e437]:
      - link "Three-battle scenario" [ref=f1e438]:
        - /url: /run
      - link "Single battle" [ref=f1e439]:
        - /url: /
      - link "Map prototype" [ref=f1e440]:
        - /url: /map
    - group [ref=f1e441]:
      - generic "Privacy & analytics" [ref=f1e442] [cursor=pointer]
```

# Test source

```ts
  139 |   expect(upright.button).toBe('matrix(0.707107, 0.707107, -0.707107, 0.707107, 0, 0)');
  140 |   expect(upright.label).toBe('matrix(0.707107, -0.707107, 0.707107, 0.707107, 0, 0)');
  141 |  }
  142 |  expect(boxes[0].y).toBeLessThan(boxes[1].y);expect(boxes[2].y).toBeGreaterThan(boxes[1].y);expect(boxes[3].x).toBeLessThan(boxes[0].x);expect(boxes[1].x).toBeGreaterThan(boxes[0].x);
  143 |  await page.locator('#dungeon-map').focus();await page.keyboard.press(browserName==='webkit'?'Alt+Tab':'Tab');
  144 |  await expect(compass.getByRole('button',{name:'North',exact:true})).toBeFocused();
  145 |  expect(await compass.getByRole('button',{name:'North',exact:true}).evaluate(node=>node.matches(':focus-visible')&&getComputedStyle(node).outlineStyle==='solid')).toBe(true);
  146 |  await page.screenshot({path:test.info().outputPath('compass-focus.png')});
  147 |  for(const [name,delta] of directions){
  148 |   const before=await dungeonSnapshot(page),button=compass.getByRole('button',{name,exact:true});
  149 |   if(isMobile)await button.tap();else {await button.focus();await page.keyboard.press(name==='North'?'Enter':'Space');}
  150 |   expect((await dungeonSnapshot(page)).floors[0].position).toBe(center+delta);
  151 |   expect((await dungeonSnapshot(page)).revision).toBe(before.revision+1);
  152 |   const reverse=directions.find(([,offset])=>offset===-delta)![0];
  153 |   const back=compass.getByRole('button',{name:reverse,exact:true});if(isMobile)await back.tap();else await back.click();
  154 |   expect((await dungeonSnapshot(page)).floors[0].position).toBe(center);
  155 |  }
  156 |  if(!isMobile){
  157 |   const north=compass.getByRole('button',{name:'North',exact:true});await north.hover();await page.mouse.down();
  158 |   expect(await north.evaluate(node=>getComputedStyle(node).boxShadow)).not.toBe('none');
  159 |   await page.screenshot({path:test.info().outputPath('compass-pressed.png')});await page.mouse.up();
  160 |  }
  161 |  const wallPosition=map.cells.findIndex((_,cell)=>safe(cell)&&neighbors(cell).some(next=>!map.cells[next]));
  162 |  await load(atCell(base,wallPosition));const before=await dungeonSnapshot(page);
  163 |  for(const [name,delta] of directions){
  164 |   const unavailable=!neighbors(wallPosition).includes(wallPosition+delta)||!map.cells[wallPosition+delta];
  165 |   const button=compass.getByRole('button',{name,exact:true});
  166 |   if(unavailable){await expect(button).toBeDisabled();await button.evaluate(node=>(node as HTMLButtonElement).click());}
  167 |   else await expect(button).toBeEnabled();
  168 |  }
  169 |  expect(await dungeonSnapshot(page)).toEqual(before);
  170 |  await compass.scrollIntoViewIfNeeded();await page.screenshot({path:test.info().outputPath('compass-unavailable.png')});
  171 |  if(isMobile){await page.setViewportSize({width:320,height:740});await compass.scrollIntoViewIfNeeded();}
  172 |  expect(await page.locator('#dungeon-screen').evaluate(node=>node.scrollWidth<=node.clientWidth)).toBe(true);
  173 |  const compassBox=(await compass.boundingBox())!;expect(compassBox.x).toBeGreaterThanOrEqual(0);expect(compassBox.x+compassBox.width).toBeLessThanOrEqual(page.viewportSize()!.width);
  174 |  await load(dungeonCapacityFixture());
  175 |  for(const [name] of directions)await expect(compass.getByRole('button',{name,exact:true})).toBeDisabled();
  176 |  const reward=await dungeonSnapshot(page);await page.locator('#dungeon-map').focus();await page.keyboard.press('ArrowUp');expect(await dungeonSnapshot(page)).toEqual(reward);
  177 | });
  178 | 
  179 | test('compass keeps keyboard focus when movement disables the activated direction',async({page})=>{
  180 |  const initial=atCell(freshDungeon('compass-browser',1),27),encoded=encodeDungeon(initial);
  181 |  if(!encoded.ok)throw Error(encoded.reason);
  182 |  for(const key of ['Enter','Space']){
  183 |   await page.goto('dungeon');await page.evaluate(({key,text})=>localStorage.setItem(key,text),{key:DUNGEON_KEYS.primary,text:encoded.text});
  184 |   await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();
  185 |   const west=page.getByRole('button',{name:'West',exact:true}),map=page.locator('#dungeon-map');
  186 |   await expect(west).toBeEnabled();await west.focus();await page.keyboard.press(key);
  187 |   const moved=await dungeonSnapshot(page);expect(moved.floors[0].position).toBe(26);expect(moved.revision).toBe(initial.revision+1);
  188 |   await expect(west).toBeDisabled();await expect(map).toBeFocused();
  189 |   expect(await map.evaluate(node=>node.matches(':focus-visible')&&getComputedStyle(node).outlineStyle==='solid')).toBe(true);
  190 |   await page.screenshot({path:test.info().outputPath(`compass-focus-fallback-${key}.png`)});
  191 |   await page.keyboard.press('ArrowLeft');expect(await dungeonSnapshot(page)).toEqual(moved);await expect(map).toBeFocused();
  192 |   await page.keyboard.press('ArrowRight');const returned=await dungeonSnapshot(page);
  193 |   expect(returned.floors[0].position).toBe(27);expect(returned.revision).toBe(initial.revision+2);await expect(map).toBeFocused();await expect(west).toBeEnabled();
  194 |  }
  195 | });
  196 | 
  197 | test('real traversal, art independence, keyboard locks, active battle and exact reload',async({page,isMobile})=>{
  198 |  test.setTimeout(120000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  199 |  await page.goto('dungeon');await page.getByRole('button',{name:'Start new dungeon',exact:true}).click();await page.locator('#dungeon-confirm-new').click();
  200 |  const initial=await dungeonSnapshot(page),f=initial.floors[0],map=generateMap(f.descriptor.seed,'rooms');
  201 |  await expect(page.locator('#dungeon-start-encounter')).toHaveCount(0);await expect(page.locator('[aria-label="Discovered places"]')).not.toContainText('Upstairs');
  202 |  const adjacent=neighbors(f.position).find(n=>map.cells[n])!;
  203 |  await walkDungeon(page,adjacent,isMobile?'touch':'pointer');const stepped=await dungeonSnapshot(page);expect(stepped.revision).toBe(initial.revision+1);
  204 |  await page.locator('#dungeon-map').focus();await page.keyboard.down('ArrowUp');await page.keyboard.up('ArrowUp');const after=await dungeonSnapshot(page);
  205 |  await page.locator('#dungeon-map').dispatchEvent('keydown',{key:'ArrowUp',repeat:true});expect(await dungeonSnapshot(page)).toEqual(after);
  206 |  await page.getByRole('button',{name:'Start new dungeon',exact:true}).click();await page.keyboard.press('ArrowDown');expect(await dungeonSnapshot(page)).toEqual(after);await page.locator('#dungeon-cancel-new').click();
  207 |  await page.locator('#dungeon-map').evaluate(n=>n.dataset.identity='retained');
  208 |  await page.getByRole('combobox',{name:'Map art',exact:true}).selectOption('legacy-8bit');await expect(page.locator('#dungeon-map')).toHaveAttribute('data-art','legacy-8bit');
  209 |  if(f.descriptor.biome==='desert-v1')await expect(page.locator('#dungeon-map-feedback')).toContainText('fallback');else await expect(page.locator('#dungeon-map-feedback')).not.toContainText('fallback');expect(await dungeonSnapshot(page)).toEqual(after);
  210 |  await page.getByRole('combobox',{name:'Map art',exact:true}).selectOption('simple');expect(await dungeonSnapshot(page)).toEqual(after);
  211 |  await expect(page.locator('#dungeon-map')).toHaveAttribute('data-identity','retained');
  212 |  await expect.poll(()=>page.locator('.dungeon-directions button').evaluateAll(nodes=>nodes.length===4&&nodes.every(n=>{const b=n.getBoundingClientRect();return b.width>=44&&b.height>=44;}))).toBe(true);
  213 |  await page.locator('#dungeon-map').scrollIntoViewIfNeeded();await page.screenshot({path:test.info().outputPath('exploration-revealed.png'),fullPage:true});
  214 |  expect(await page.locator('#dungeon-screen').evaluate(n=>n.scrollWidth<=n.clientWidth)).toBe(true);
  215 |  await walkDungeon(page,poiCell(f.exploration.pois[0]),isMobile?'touch':'keyboard');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  216 |  const battle=await dungeonSnapshot(page);expect(battle.phase).toBe('battle');expect(battle.floors[0].position).toBe(poiCell(f.exploration.pois[0]));
  217 |  const command=playerDecision((await readSession(page)).state,dungeonBattle(battle)!.catalog);await playCommand(page,command);await expect(page.locator('#game')).toHaveAttribute('data-phase','player');const saved=await dungeonSnapshot(page);
  218 |  await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');expect(await dungeonSnapshot(page)).toEqual(saved);
  219 |  writeFileSync(test.info().outputPath('spatial-battle-receipt.json'),JSON.stringify({initial,stepped,saved},null,2));expect(errors).toEqual([]);
  220 | });
  221 | test('pre-progression dungeon remains incompatible and exportable',async({page})=>{
  222 |  const raw=priorDungeonEnvelope(freshDungeon('legacy-browser',13,LEGACY_ENCOUNTER_POLICY),1);
  223 |  await page.goto('dungeon');await page.evaluate(({key,raw})=>localStorage.setItem(key,raw),{key:DUNGEON_KEYS.primary,raw});await page.reload();
  224 |  await expect(page.getByRole('button',{name:'Continue saved dungeon',exact:true})).toBeDisabled();
  225 |  await page.getByRole('button',{name:'Save recovery',exact:true}).click();
  226 |  const download=page.waitForEvent('download');await page.getByRole('button',{name:'Export primary save',exact:true}).click();await download;
  227 |  expect(await page.evaluate(key=>localStorage.getItem(key),DUNGEON_KEYS.primary)).toBe(raw);
  228 | });
  229 | 
  230 | test('cold progression-format Continue retains a long saved history within the startup budget',async({page})=>{
  231 |  const base=freshDungeon('cold-browser',13),floors=Array.from({length:250},(_,i)=>{
  232 |   const descriptor=floorDescriptor(base.seed,i+1);
  233 |   return {descriptor,completed:i===249?0:3,position:descriptor.upstairs,exploration:freshExploration(descriptor.seed,descriptor.upstairs)};
  234 |  });
  235 |  const encoded=encodeDungeon({...base,depth:250,floors});if(!encoded.ok)throw Error(encoded.reason);
  236 |  await page.goto('dungeon');await page.evaluate(({key,text})=>localStorage.setItem(key,text),{key:DUNGEON_KEYS.primary,text:encoded.text});
  237 |  const begin=Date.now();await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();
  238 |  await expect(page.locator('#dungeon-map')).toBeVisible();const coldUsableMs=Date.now()-begin;
> 239 |  expect(coldUsableMs).toBeLessThanOrEqual(2500);
      |                       ^ Error: expect(received).toBeLessThanOrEqual(expected)
  240 |  const state=await dungeonSnapshot(page);expect(state.depth).toBe(250);expect(state.floors).toHaveLength(250);
  241 |  expect(await page.evaluate(key=>localStorage.getItem(key),DUNGEON_KEYS.primary)).toBe(encoded.text);
  242 |  writeFileSync(test.info().outputPath('cold-current-history.json'),JSON.stringify({floors:250,bytes:utf8Bytes(encoded.text),coldUsableMs,budgetMs:2500,rawRetained:true}));
  243 |  await page.screenshot({path:test.info().outputPath('cold-current-history.png')});
  244 | });
  245 | 
  246 | test('map input stays inert while hidden and retains discovery through resize and failed art',async({page})=>{
  247 |  await page.route('**/map-art/**',route=>route.abort());await page.goto('dungeon');await page.getByRole('button',{name:'Play unsaved dungeon',exact:true}).click();
  248 |  const before=await dungeonSnapshot(page);await page.locator('#dungeon-art').selectOption('legacy-8bit');await expect(page.locator('#dungeon-map-feedback')).toContainText('fallback');expect(await dungeonSnapshot(page)).toEqual(before);
  249 |  await page.evaluate(()=>Object.defineProperty(document,'hidden',{configurable:true,value:true}));await page.locator('#dungeon-map').focus();await page.keyboard.press('ArrowRight');expect(await dungeonSnapshot(page)).toEqual(before);
  250 |  await page.evaluate(()=>Object.defineProperty(document,'hidden',{configurable:true,value:false}));const size=page.viewportSize()!;await page.setViewportSize({width:size.height,height:size.width});expect(await dungeonSnapshot(page)).toEqual(before);
  251 |  await page.screenshot({path:test.info().outputPath('exploration-rotated-fallback.png'),fullPage:true});
  252 | });
  253 | test('records route transfer and map responsiveness against established budgets',async({page,request})=>{
  254 |  const begin=Date.now();await page.goto('dungeon');await expect(page.getByRole('heading',{name:'Dungeon floors',exact:true})).toBeVisible();const coldUsableMs=Date.now()-begin;
  255 |  await page.getByRole('button',{name:'Start new dungeon',exact:true}).click();
  256 |  const floorCreationMs=await page.locator('#dungeon-confirm-new').evaluate(button=>{const begin=performance.now();(button as HTMLButtonElement).click();return performance.now()-begin;});const timings:number[]=[];
  257 |  const start=await dungeonSnapshot(page),f=start.floors[0],map=generateMap(f.descriptor.seed,'rooms'),neighbor=neighbors(f.position).find(n=>map.cells[n]&&!f.exploration.pois.some(p=>poiCell(p)===n))!;
  258 |  for(let i=0;i<20;i++)timings.push(await page.evaluate(destination=>{const begin=performance.now();const cell=document.querySelector<HTMLElement>(`#dungeon-map [data-cell="${destination}"]`)!;cell.click();return performance.now()-begin;},i%2===0?neighbor:f.position));
  259 |  const frames=await page.evaluate(async({a,b})=>{
  260 |    const idle:number[]=[],steps:number[]=[];
  261 |    for(const [count,output] of [[30,idle],[40,steps]] as const){let previous=await new Promise<number>(r=>requestAnimationFrame(r));for(let i=0;i<count;i++){if(output===steps)document.querySelector<HTMLElement>(`#dungeon-map [data-cell="${i%2===0?b:a}"]`)!.click();const now=await new Promise<number>(r=>requestAnimationFrame(r));output.push(now-previous);previous=now;}}
  262 |    const p=(v:number[],q:number)=>[...v].sort((a,b)=>a-b)[Math.ceil(v.length*q)-1];return {idle,steps,idleP50:p(idle,.5),idleP95:p(idle,.95),stepP95:p(steps,.95)};
  263 |  },{a:f.position,b:neighbor});
  264 |  await page.locator('#dungeon-art').selectOption('legacy-8bit');if(f.descriptor.biome==='desert-v1')await expect(page.locator('#dungeon-map-feedback')).toContainText('fallback');else await expect(page.locator('#dungeon-map-feedback')).not.toContainText('fallback');
  265 |  const resources=await page.evaluate(()=>performance.getEntriesByType('resource').map(e=>({name:e.name,encodedBodySize:(e as PerformanceResourceTiming).encodedBodySize})));
  266 |  const code=[];for(const r of resources.filter(r=>/\.(js|css)$/.test(r.name))){const response=await request.get(r.name),body=await response.body();code.push({url:new URL(r.name).pathname,raw:body.length,gzip:gzipSync(body).length});}
  267 |  timings.sort((a,b)=>a-b);const p95=timings[Math.ceil(timings.length*.95)-1],gzip=code.reduce((n,r)=>n+r.gzip,0),assets=resources.filter(r=>!r.name.match(/\.(js|css)$/)).reduce((n,r)=>n+r.encodedBodySize,0);
  268 |  const diagnostics=await page.evaluate(()=>window.fitDiagnostics()),saveBytes=utf8Bytes((await page.evaluate(key=>localStorage.getItem(key),DUNGEON_KEYS.primary))??'');
  269 |  const receipt={frames,frameBudgets:{idleP50:16.7,idleP95:20,stepP95:33.4},framePasses:{idleP50:frames.idleP50<=16.7,idleP95:frames.idleP95<=20,stepP95:frames.stepP95<=33.4},commit:diagnostics.build.commit,dirty:diagnostics.build.dirty,viewport:diagnostics.viewport,userAgent:diagnostics.userAgent,floorCreationMs,descriptorBytes:utf8Bytes(canonical(f.descriptor)),saveBytes,coldUsableMs,stepP95Ms:p95,codeGzipBytes:gzip,observedAssetBytes:assets,budgets:{coldUsableMs:2500,stepP95Ms:33.4,codeGzipBytes:400000,assetBytes:1500000},passes:{cold:coldUsableMs<=2500,step:p95<=33.4,code:gzip<=400000,assets:assets<=1500000},code,timings,resources};
  270 |  writeFileSync(test.info().outputPath('exploration-performance.json'),JSON.stringify(receipt,null,2));expect(timings).toHaveLength(20);expect((await dungeonSnapshot(page)).floors[0].position).toBe(f.position);
  271 | });
  272 | 
  273 | for(const biome of ['forest','desert'] as const)test(`${biome} saved kinds, scaled inspection and reload use actual selected definitions`,async({page,isMobile})=>{
  274 |  test.setTimeout(120000);
  275 |  // Structural depth/slot fixtures isolate presentation, not preceding battle completion.
  276 |  for(const kind of ['normal','elite','vault','boss'] as const){
  277 |   if(kind==='vault')await page.setViewportSize({width:320,height:568});
  278 |   if(kind==='boss')await page.setViewportSize({width:568,height:320});
  279 |   const slot=kind==='normal'?0:kind==='boss'?2:1;
  280 |   let state: DungeonState|null=null;
  281 |   for(let seed=0;seed<128&&!state;seed++){
  282 |    const base=freshDungeon('biome-view',seed),descriptor=floorDescriptor(seed,2),selection=descriptor.encounters[slot].selection;
  283 |    if(descriptor.biome!==`${biome}-v1`||selection.kind!==kind)continue;
  284 |    const candidate={...base,depth:2,floors:[{...base.floors[0],completed:3},{descriptor,position:descriptor.upstairs,completed:slot,exploration:freshExploration(descriptor.seed,descriptor.upstairs)}]};
  285 |    const read=readDungeon(candidate);if(!read.ok)throw Error(read.reason);state=read.state;
  286 |   }
  287 |   if(!state)throw Error('No kind fixture');const encoded=encodeDungeon(state);if(!encoded.ok)throw Error(encoded.reason);
  288 |   await page.goto('dungeon');await page.evaluate(({key,text})=>localStorage.setItem(key,text),{key:DUNGEON_KEYS.primary,text:encoded.text});await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();
  289 |   await expect(page.locator('#dungeon-map')).toHaveAttribute('data-biome',biome);
  290 |   expect(await page.locator('#dungeon-screen').evaluate(n=>n.scrollWidth<=n.clientWidth)).toBe(true);
  291 |   await expect(page.locator('#dungeon-screen h1')).toHaveText(`Dungeon · Floor 2 · ${biome==='forest'?'Forest':'Desert'}`);
  292 |   const undiscovered=state.floors[1].exploration.pois.filter(p=>!state!.floors[1].exploration.revealed.includes(poiCell(p)));
  293 |   for(const p of undiscovered)await expect(page.locator(`[data-poi-id="${p.id}"]`)).toHaveCount(0);
  294 |   await walkDungeon(page,undefined,isMobile?'touch':'keyboard');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  295 |   const label=kind==='boss'?'Guardian · Goblins':`${kind[0].toUpperCase()}${kind.slice(1)} encounter ${slot+1}`;
  296 |   await expect(page.locator('#battle-heading h1')).toHaveText(`Dungeon · Floor 2 · ${biome==='forest'?'Forest':'Desert'} · ${label}`);
  297 |   expect(await page.locator('#battle-shell').evaluate(n=>n.scrollWidth<=n.clientWidth)).toBe(true);
  298 |   const before=await dungeonSnapshot(page),session=await readSession(page),built=dungeonBattle(before)!,enemy=session.state.units.find(u=>u.side==='enemy')!;
  299 |   const stats=built.catalog.enemies[enemy.defId as 'goblin_grunt'|'goblin_archer'].stats;
  300 |   await page.locator('#battle-party').click();await page.locator(`#inspect-unit-${enemy.id}`).click();
  301 |   await expect(page.locator('#battle-dialog-message')).toContainText(`HP ${enemy.hp}/${stats.maxHp}`);await expect(page.locator('#battle-dialog-message')).toContainText(`AC ${stats.armorClass}`);
  302 |   await page.locator('#battle-dialog-title').scrollIntoViewIfNeeded();await page.screenshot({path:test.info().outputPath(`${biome}-${kind}-scaled-inspection.png`)});await page.locator('#inspection-close').click();
  303 |   expect(await dungeonSnapshot(page)).toEqual(before);
  304 |   await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  305 |   expect(await dungeonSnapshot(page)).toEqual(before);await expect(page.locator('#battle-heading h1')).toContainText(label);
  306 |  }
  307 | });
  308 | 
  309 |  test('exploration cells stay square across viewport sizes and art styles',async({page})=>{
  310 |  await page.goto('dungeon');await page.getByRole('button',{name:'Play unsaved dungeon',exact:true}).click();
  311 |  for(const viewport of [{width:320,height:740},{width:393,height:852},{width:915,height:412},{width:1280,height:800}]){
  312 |   await page.setViewportSize(viewport);
  313 |   for(const art of ['simple','legacy-8bit']){
  314 |    await page.locator('#dungeon-art').selectOption(art);
  315 |    const sizes=await page.locator('#dungeon-map span').evaluateAll(cells=>cells.map(cell=>{const r=cell.getBoundingClientRect();return {width:r.width,height:r.height};}));
  316 |    expect(sizes).toHaveLength(400);
  317 |    for(const size of sizes){expect(size.width).toBeGreaterThan(0);expect(Math.abs(size.width-size.height)).toBeLessThan(0.1);expect(Math.abs(size.height-sizes[0].height)).toBeLessThan(0.1);}
  318 |   }
  319 |  }
  320 |  await page.setViewportSize({width:393,height:852});await page.locator('#dungeon-map').scrollIntoViewIfNeeded();
  321 |  await page.screenshot({path:test.info().outputPath('square-overworld-mobile.png')});
  322 | });
  323 | 
```
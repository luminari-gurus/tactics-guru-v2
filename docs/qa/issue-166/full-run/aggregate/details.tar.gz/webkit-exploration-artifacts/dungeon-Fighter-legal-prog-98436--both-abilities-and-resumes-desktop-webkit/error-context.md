# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dungeon.spec.ts >> Fighter legal progression journey earns level three uses both abilities and resumes
- Location: tests/dungeon.spec.ts:182:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Array [
    2,
-   2,
+   0,
  ]
```

# Page snapshot

```yaml
- main [ref=f2e2]:
  - heading "Dungeon defeat · Desert · Floor 2" [active] [level=1] [ref=f2e3]
  - paragraph [ref=f2e4]: "Three encounters per floor. Next: Normal encounter 1. Defeat the goblin guardian to unlock the stairs."
  - status [ref=f2e5]: Dungeon saved on this device
  - region "Floor exploration" [ref=f2e6]:
    - heading "Explore Desert · Floor 2" [level=2] [ref=f2e7]
    - generic [ref=f2e8]:
      - text: Map art
      - combobox "Map art" [ref=f2e9]:
        - option "Simple" [selected]
        - option "Legacy 8-bit"
    - paragraph [ref=f2e10]: ● Player · M encounter (including guardian) · ✓ cleared · ↑ upstairs (floor 2+) · ↓ downstairs (guardian defeated). Reveal reaches two cells, including through walls. Tap adjacent cells or use direction controls.
    - application "Floor 2 map. Player row 6, column 13. Arrow or WASD keys move one cell." [ref=f2e11]:
      - generic [aria-hidden] [ref=f2e101]: ↑
      - generic [aria-hidden] [ref=f2e124]: ●
    - group "Move player" [ref=f2e412]:
      - button "North" [disabled] [ref=f2e413]:
        - generic: "N"
      - button "East" [disabled] [ref=f2e414]:
        - generic: E
      - button "South" [disabled] [ref=f2e415]:
        - generic: S
      - button "West" [disabled] [ref=f2e416]:
        - generic: W
    - status [ref=f2e417]: Player cell 112 · Revealed 31/400 · Visited 5.
    - list "Discovered places" [ref=f2e418]:
      - listitem [ref=f2e419]: Upstairs · row 5, column 10 · Available · Visited
      - listitem [ref=f2e420]: Normal encounter 1 · Desert · Floor 2 · row 6, column 13 · Unavailable after defeat · Visited
  - region "Stairs" [ref=f2e421]:
    - heading "Stairs" [level=2] [ref=f2e422]
    - paragraph [ref=f2e423]: Move onto an available stair to travel automatically. On arrival or after continuing a save, move off and back onto the stair to travel again. Upstairs is unavailable on floor 1.
    - paragraph [ref=f2e424]: Defeat the guardian and claim pending rewards to unlock descent.
  - region "Party" [ref=f2e425]:
    - heading "Party" [level=2] [ref=f2e426]
    - paragraph [ref=f2e427]: "fighter: 0/24 HP · Level 2 · XP 175/180 · Learned: basic attack, guarded strike, second wind · Accuracy 4 · Armor class 14 · Defeated"
    - paragraph [ref=f2e428]: "ranger: 0/17 HP · Level 2 · XP 85/180 · Learned: basic attack, high shot, mark target · Accuracy 5 · Armor class 12 · Defeated"
    - paragraph [ref=f2e429]: "mage: 0/11 HP · Level 1 · XP 0/60 · Learned: basic attack, magic missile · Accuracy 3 · Armor class 11 · Defeated"
  - region "Owned items" [ref=f2e430]:
    - heading "Owned items" [level=2] [ref=f2e431]
    - paragraph [ref=f2e432]: Charms 0/6 · Discard a charm with confirmation to free space.
    - paragraph [ref=f2e433]: No owned items yet.
  - button "Save recovery" [ref=f2e434] [cursor=pointer]
  - button "Start new dungeon" [ref=f2e435] [cursor=pointer]
  - navigation [ref=f2e436]:
    - link "Three-battle scenario" [ref=f2e437]:
      - /url: /run
    - link "Single battle" [ref=f2e438]:
      - /url: /
    - link "Map prototype" [ref=f2e439]:
      - /url: /map
  - group [ref=f2e440]:
    - generic "Privacy & analytics" [ref=f2e441] [cursor=pointer]
```

# Test source

```ts
  117 |   for(let i=0;i<20;i++) {
  118 |    const s=await snapshot(page),command=journeyPreparation(s);if(!command)break;
  119 |    if(command.type==='claimReward')await page.getByRole('button',{name:`Claim ${dungeonContent.items[command.itemId].label}`,exact:true}).click();
  120 |    else if(command.type==='useItem'){await page.getByRole('combobox',{name:'Healing Draught target',exact:true}).selectOption(command.heroId);await page.getByRole('button',{name:'Use Healing Draught',exact:true}).click();}
  121 |    else if(command.type==='equipItem'){const row=page.locator(`[data-instance-id="${command.instanceId}"]`);await row.locator('select').selectOption(command.heroId);await row.getByRole('button',{name:'Equip Warding Charm',exact:true}).click();}
  122 |    else throw Error('Unexpected preparation command');await page.locator('#dungeon-item-confirm').click();
  123 |   }
  124 |  }
  125 |  const final=await snapshot(page);writeFileSync(test.info().outputPath('mage-production-journey.json'),JSON.stringify({seed:17,records,final,used,blocked,expired}));
  126 |  expect(final.phase).toBe('defeat');expect(final.party).toEqual(witness.state.party);expect(used).toEqual({snare:true,missiles:true});expect(blocked&&expired).toBe(true);expect(errors).toEqual([]);
  127 |  await page.screenshot({path:test.info().outputPath('mage-terminal-journey.png'),fullPage:true});
  128 | });
  129 | 
  130 | test('Ranger legal progression journey earns level three uses Mark and Pin and resumes',async({page,isMobile})=>{
  131 |  test.setTimeout(600000);page.setDefaultTimeout(10000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  132 |  const witness=rangerJourney(1),used={mark:false,pin:false};expect(witness.used).toEqual({mark:true,pin:true});expect(witness.state.phase).toBe('defeat');
  133 |  await seed(page,freshDungeon('ranger-production-journey',1));
  134 |  const records:unknown[]=[];let consumed=false;
  135 |  for(const expected of witness.records) {
  136 |   const position=await snapshot(page);
  137 |   if(position.depth<expected.entry.depth){await walkDungeon(page,position.floors[position.depth-1].descriptor.downstairs,isMobile?'touch':'keyboard');expect((await snapshot(page)).depth).toBe(expected.entry.depth);}
  138 |   await walkDungeon(page,undefined,isMobile?'touch':'keyboard');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  139 |   const entry=await snapshot(page);expect(entry.party).toEqual(expected.entry.party);
  140 |   expect(entry.activeBattle!.units.every(u=>u.markedBy===undefined&&u.movementBlock===undefined)).toBe(true);
  141 |   let steps=0;
  142 |   while((await snapshot(page)).phase==='battle'&&steps++<500) {
  143 |    await expect.poll(async()=>{const s=await snapshot(page);return s.phase!=='battle'||(await readSession(page)).phase==='player';}).toBe(true);
  144 |    const current=await snapshot(page);if(current.phase!=='battle')break;
  145 |    const before=await readSession(page),built=dungeonBattle(current)!,command=rangerDecision(before.state,built.catalog,used);
  146 |    await playCommand(page,command);
  147 |    await expect.poll(async()=>{const s=await snapshot(page);return s.phase!=='battle'||(await readSession(page)).state.commandCount>before.state.commandCount;}).toBe(true);
  148 |    await expect.poll(async()=>{const s=await snapshot(page);return s.phase!=='battle'||(await readSession(page)).phase==='player';}).toBe(true);
  149 |    if((await snapshot(page)).phase==='battle')consumed ||= (await readSession(page)).events.some(e=>e.type==='markConsumed');
  150 |    if(command.type==='useAbility'&&(command.abilityId==='ability:mark_target'||command.abilityId==='ability:pinning_shot')) {
  151 |     const kind=command.abilityId==='ability:mark_target'?'mark':'pin';used[kind]=true;
  152 |     const after=await readSession(page),targetId='unitId' in command.target?command.target.unitId:0;
  153 |     expect(after.state.rng).toEqual(before.state.rng);expect(after.state.units.map(u=>u.hp)).toEqual(before.state.units.map(u=>u.hp));
  154 |     expect(current.party.find(h=>h.heroId==='ranger')!.level).toBeGreaterThanOrEqual(kind==='mark'?2:3);
  155 |     const affected=after.state.units.find(u=>u.id===targetId)!;
  156 |     if(kind==='mark')expect(affected.markedBy).toBe(command.unitId);
  157 |     else expect(affected.movementBlock).toEqual({sourceId:command.unitId,abilityId:'ability:pinning_shot'});
  158 |     await page.locator('#battle-party').click();await page.locator(`#inspect-unit-${targetId}`).click();
  159 |     await expect(page.getByRole('dialog')).toContainText(kind==='mark'?'Marked by Ranger':'Pinned by Ranger');
  160 |     await page.screenshot({path:test.info().outputPath(`production-ranger-${kind}-inspection.png`)});await page.locator('#inspection-close').click();
  161 |     const saved=await snapshot(page);await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();
  162 |     await expect(page.locator('#game')).toHaveAttribute('data-phase','player');expect((await snapshot(page)).activeBattle).toEqual(saved.activeBattle);expect((await readSession(page)).events).toEqual([]);
  163 |    }
  164 |   }
  165 |   const record=JSON.parse((await page.locator('#game').getAttribute('data-dungeon-battle-record'))!);
  166 |   expect(record.state).toEqual(expected.state);let replayed=record.replay?.initial??record.continuation.snapshot;const events:unknown[]=[];
  167 |   for(const c of record.replay?.commands??record.continuation.commands){const r=dispatch(replayed,c,dungeonBattle(record.entry)!.catalog);if(!r.ok)throw Error(r.reason);replayed=r.state;events.push(...r.events);}
  168 |   expect(replayed).toEqual(record.state);expect(events).toEqual(record.events);records.push(record);
  169 |   for(let i=0;i<20;i++) {
  170 |    const s=await snapshot(page),command=journeyPreparation(s);if(!command)break;
  171 |    if(command.type==='claimReward')await page.getByRole('button',{name:`Claim ${dungeonContent.items[command.itemId].label}`,exact:true}).click();
  172 |    else if(command.type==='useItem'){await page.getByRole('combobox',{name:'Healing Draught target',exact:true}).selectOption(command.heroId);await page.getByRole('button',{name:'Use Healing Draught',exact:true}).click();}
  173 |    else if(command.type==='equipItem'){const row=page.locator(`[data-instance-id="${command.instanceId}"]`);await row.locator('select').selectOption(command.heroId);await row.getByRole('button',{name:'Equip Warding Charm',exact:true}).click();}
  174 |    else throw Error('Unexpected preparation command');await page.locator('#dungeon-item-confirm').click();
  175 |   }
  176 |  }
  177 |  const final=await snapshot(page);writeFileSync(test.info().outputPath('ranger-production-journey.json'),JSON.stringify({seed:1,records,final,used,consumed}));
  178 |  expect(final.phase).toBe('defeat');expect(final.party).toEqual(witness.state.party);expect(used).toEqual({mark:true,pin:true});expect(consumed).toBe(true);expect(errors).toEqual([]);
  179 |  await page.screenshot({path:test.info().outputPath('ranger-terminal-journey.png'),fullPage:true});
  180 | });
  181 | 
  182 | test('Fighter legal progression journey earns level three uses both abilities and resumes',async({page,isMobile})=>{
  183 |  test.setTimeout(600000);page.setDefaultTimeout(10000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  184 |  // Canonical unplayed level-1 seed, with no fabricated progression, inventory or combat boundary.
  185 |  await seed(page,freshDungeon('fighter-production-journey',190));
  186 |  const records:unknown[]=[];let healed=false,taunted=false;
  187 |  for(let depth=1;depth<=2;depth++) {
  188 |   for(let slot=0;slot<3;slot++) {
  189 |    await walkDungeon(page,undefined,isMobile?'touch':'keyboard');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  190 |    const entry=await snapshot(page);expect(entry.depth).toBe(depth);expect(entry.floors[depth-1].completed).toBe(slot);
  191 |    expect(entry.activeBattle!.units.every(u=>!u.secondWindUsed && u.tauntedBy===undefined)).toBe(true);
  192 |    let steps=0;
  193 |    while((await snapshot(page)).phase==='battle' && steps++<500) {
  194 |     await expect.poll(async()=>{const s=await snapshot(page);return s.phase!=='battle'||(await readSession(page)).phase==='player';}).toBe(true);
  195 |     const s=await snapshot(page);if(s.phase!=='battle')break;
  196 |     const before=await readSession(page),built=dungeonBattle(s)!;
  197 |     const command=fighterDecision(before.state,built.catalog,taunted);
  198 |     await playCommand(page,command);
  199 |     await expect.poll(async()=>{const current=await snapshot(page);return current.phase!=='battle'||(await readSession(page)).state.commandCount>before.state.commandCount;}).toBe(true);
  200 |     await expect.poll(async()=>{const current=await snapshot(page);return current.phase!=='battle'||(await readSession(page)).phase==='player';}).toBe(true);
  201 |     if(command.type==='useAbility' && (command.abilityId==='ability:second_wind'&&!healed || command.abilityId==='ability:taunt'&&!taunted)) {
  202 |      const after=await readSession(page);expect(after.state.rng).toEqual(before.state.rng);
  203 |      const fighter=after.state.units.find(u=>u.defId==='fighter')!;
  204 |      expect(s.party.find(h=>h.heroId==='fighter')!.level).toBeGreaterThanOrEqual(command.abilityId==='ability:taunt'?3:2);
  205 |      if(command.abilityId==='ability:second_wind'){healed=true;expect(fighter.secondWindUsed).toBe(true);expect(fighter.hp).toBeGreaterThan(before.state.units.find(u=>u.id===fighter.id)!.hp);}
  206 |      else {taunted=true;expect(after.state.units.some(u=>u.tauntedBy===fighter.id)).toBe(true);}
  207 |      await page.locator('#battle-log-open').click();await expect(page.getByRole('dialog')).toContainText(command.abilityId==='ability:second_wind'?'heals':'taunted by');
  208 |      await page.screenshot({path:test.info().outputPath(command.abilityId==='ability:second_wind'?'production-heal-log.png':'production-taunt-log.png')});await page.locator('#log-close').click();
  209 |      const saved=await snapshot(page);await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();
  210 |      await expect(page.locator('#game')).toHaveAttribute('data-phase','player');expect((await snapshot(page)).activeBattle).toEqual(saved.activeBattle);expect((await readSession(page)).events).toEqual([]);
  211 |      await page.locator('#battle-party').click();await expect(page.getByRole('dialog')).toContainText('Second Wind');await page.screenshot({path:test.info().outputPath(command.abilityId==='ability:second_wind'?'production-heal-resumed.png':'production-taunt-resumed.png')});await page.locator('#inspection-close').click();
  212 |     }
  213 |    }
  214 |    await expect(page.locator('#dungeon-screen')).toBeVisible();const completed=await snapshot(page);
  215 |    // This fixed legal policy reaches the second guardian and ends in defeat after both unlocks.
  216 |    // A terminal defeat is a complete journey; winning two floors is not an issue acceptance gate.
> 217 |    if(completed.phase==='defeat'){expect([depth,slot]).toEqual([2,2]);expect(healed&&taunted).toBe(true);}
      |                                                        ^ Error: expect(received).toEqual(expected) // deep equality
  218 |    else expect(completed.floors[depth-1].completed).toBe(slot+1);
  219 |    const record=JSON.parse((await page.locator('#game').getAttribute('data-dungeon-battle-record'))!);
  220 |    let replayed=record.replay?.initial??record.continuation.snapshot;const events:unknown[]=[];
  221 |    for(const c of record.replay?.commands??record.continuation.commands){const r=dispatch(replayed,c,dungeonBattle(record.entry)!.catalog);if(!r.ok)throw Error(r.reason);replayed=r.state;events.push(...r.events);}
  222 |    expect(replayed).toEqual(record.state);expect(events).toEqual(record.events);records.push(record);
  223 |    for(let i=0;i<20;i++) {
  224 |     const s=await snapshot(page),command=journeyPreparation(s);if(!command)break;
  225 |     if(command.type==='claimReward')await page.getByRole('button',{name:`Claim ${dungeonContent.items[command.itemId].label}`,exact:true}).click();
  226 |     else if(command.type==='useItem'){await page.getByRole('combobox',{name:'Healing Draught target',exact:true}).selectOption(command.heroId);await page.getByRole('button',{name:'Use Healing Draught',exact:true}).click();}
  227 |     else if(command.type==='equipItem'){const row=page.locator(`[data-instance-id="${command.instanceId}"]`);await row.locator('select').selectOption(command.heroId);await row.getByRole('button',{name:'Equip Warding Charm',exact:true}).click();}
  228 |     else throw Error('Unexpected preparation command');
  229 |     await page.locator('#dungeon-item-confirm').click();
  230 |    }
  231 |   }
  232 |   if(depth===1){const s=await snapshot(page);await walkDungeon(page,s.floors[0].descriptor.downstairs,isMobile?'touch':'keyboard');expect((await snapshot(page)).depth).toBe(2);}
  233 |  }
  234 |  const final=await snapshot(page);expect(final.floors.map(f=>f.completed)).toEqual([3,2]);expect(final.phase).toBe('defeat');expect(final.party.find(h=>h.heroId==='fighter')!.level).toBeGreaterThanOrEqual(3);expect(healed).toBe(true);expect(taunted).toBe(true);expect(errors).toEqual([]);
  235 |  writeFileSync(test.info().outputPath('fighter-production-journey.json'),JSON.stringify({seed:190,records,final,healed,taunted}));await page.screenshot({path:test.info().outputPath('fighter-terminal-journey.png'),fullPage:true});
  236 | });
  237 | 
  238 | test('automatic stairs preserve healed Fighter carry and fresh battle resources',async({page,isMobile})=>{
  239 |  test.setTimeout(90000);
  240 |  // Generate the legal boundary under current rules; the historical #163 receipt remains immutable.
  241 |  const record=healedFighterBoundary();expect(record.state.units.find(u=>u.defId==='fighter')!.secondWindUsed).toBe(true);
  242 |  const completed=acceptDungeonBattle(record.entry,record.state);if(!completed.ok)throw Error(completed.reason);
  243 |  const approach=atStairApproach(completed.state),party=approach.party,ownership=approach.ownership;
  244 |  expect(party.find(h=>h.heroId==='fighter')!.hp).toBeGreaterThan(0);expect(party.find(h=>h.heroId==='fighter')!.learned).toContain('ability:second_wind');
  245 |  await seed(page,approach);await walkDungeon(page,approach.floors[0].descriptor.downstairs,isMobile?'touch':'keyboard');
  246 |  const arrived=await snapshot(page);expect(arrived.depth).toBe(2);expect(arrived.revision).toBe(approach.revision+1);expect(arrived.party).toEqual(party);expect(arrived.ownership).toEqual(ownership);
  247 |  expect(arrived.party.every(h=>!Object.hasOwn(h,'secondWindUsed')&&!Object.hasOwn(h,'tauntedBy'))).toBe(true);
  248 |  await page.screenshot({path:test.info().outputPath('healed-party-automatic-arrival.png'),fullPage:true});
  249 |  await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();expect(await snapshot(page)).toEqual(arrived);
  250 |  await walkDungeon(page,undefined,isMobile?'touch':'keyboard');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  251 |  const entry=await snapshot(page),built=dungeonBattle(entry)!;expect(built.state.units.find(u=>u.defId==='fighter')!.hp).toBe(party.find(h=>h.heroId==='fighter')!.hp);
  252 |  expect((await readSession(page)).state.units.every(u=>!u.secondWindUsed&&u.tauntedBy===undefined)).toBe(true);
  253 |  await page.locator('#battle-party').click();await page.locator('#inspect-unit-1').click();await expect(page.getByRole('dialog')).toContainText('Second Wind 1/1');
  254 |  await page.screenshot({path:test.info().outputPath('fresh-resource-after-automatic-stairs.png')});
  255 | });
  256 | async function seed(page:Page,s:DungeonState){const encoded=encodeDungeon(s);if(!encoded.ok)throw Error(encoded.reason);await page.goto('dungeon');await page.evaluate(({key,text})=>{localStorage.setItem(key,text);}, {key:DUNGEON_KEYS.primary,text:encoded.text});await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();}
  257 | function fixture(slot:number){for(let seed=1;seed<=50;seed++){const f=dungeonVictoryBoundary(seed,slot);if(f)return f;}throw Error('No legal fixture');}
  258 | test('read-only entry, keyboard new dungeon, real action and active resume',async({page})=>{
  259 |  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('dungeon');
  260 |  await expect(page.getByRole('button',{name:'Continue saved dungeon',exact:true})).toBeDisabled();
  261 |  expect(await page.evaluate(()=>localStorage.length)).toBe(0);
  262 |  await page.getByRole('button',{name:'Start new dungeon',exact:true}).focus();await page.keyboard.press('Enter');await page.locator('#dungeon-confirm-new').click();
  263 |  await expect(page.locator('#dungeon-descend')).toHaveCount(0);await expect(page.locator('#dungeon-ascend')).toHaveCount(0);
  264 |  const frame=await page.locator('#dungeon-screen').boundingBox();expect(frame!.y).toBe(0);expect(frame!.height).toBe(page.viewportSize()!.height);
  265 |  expect(await page.locator('#dungeon-screen').evaluate(n=>n.scrollWidth<=n.clientWidth)).toBe(true);
  266 |  await page.screenshot({path:test.info().outputPath('floor-entry.png'),fullPage:true});
  267 |  await walkDungeon(page);await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  268 |  const before=await snapshot(page),cmd=playerDecision((await readSession(page)).state,dungeonBattle(before)!.catalog);
  269 |  await playCommand(page,cmd);await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  270 |  const saved=await snapshot(page);await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();
  271 |  await expect(page.locator('#game')).toHaveAttribute('data-phase','player');expect((await readSession(page)).state).toEqual(saved.activeBattle);expect((await readSession(page)).events).toEqual([]);
  272 |  await page.screenshot({path:test.info().outputPath('battle-resumed.png')});expect(errors).toEqual([]);
  273 | });
  274 | test('legal reward and guardian boundaries, travel reload, backtracking and isolated saves',async({page})=>{
  275 |  test.setTimeout(180000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  276 |  for(const slot of [0,1,2]){
  277 |   const f=fixture(slot);writeFileSync(test.info().outputPath(`legal-boundary-${slot}.json`),JSON.stringify(f));
  278 |   await seed(page,f.snapshot);await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  279 |   await playCommand(page,f.command);await expect(page.locator('#dungeon-screen')).toBeVisible();
  280 |   const s=await snapshot(page),result=dispatch(f.snapshot.activeBattle!,f.command,dungeonBattle(f.snapshot)!.catalog);expect(result.ok).toBe(true);
  281 |   if(result.ok){const expected=acceptDungeonBattle(f.snapshot,result.state);expect(expected.ok).toBe(true);if(expected.ok)expect(s).toEqual(expected.state);}
  282 |   if(slot<2){
  283 |    await expect(page.locator('#dungeon-descend')).toHaveCount(0);await expect(page.getByRole('heading',{name:'Choose one reward'})).toBeVisible();
  284 |    await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();expect(await snapshot(page)).toEqual(s);
  285 |    await page.getByRole('button',{name:/^Claim /}).first().click();await page.locator('#dungeon-item-cancel').click();expect(await snapshot(page)).toEqual(s);
  286 |    await page.getByRole('button',{name:/^Claim /}).first().click();await page.locator('#dungeon-item-confirm').click();expect((await snapshot(page)).phase).toBe('ready');
  287 |   }else{
  288 |    await page.evaluate(()=>localStorage.setItem('tactics-guru:phaser:run:primary:v1','preserved-short-run'));
  289 |    await walkDungeon(page,s.floors[s.depth-1].descriptor.downstairs);expect((await snapshot(page)).depth).toBe(2);const second=await snapshot(page);
  290 |    await page.screenshot({path:test.info().outputPath('automatic-descent.png'),fullPage:true});
  291 |    await page.reload();await page.getByRole('button',{name:'Continue saved dungeon',exact:true}).click();expect(await snapshot(page)).toEqual(second);
  292 |    await reenterDungeonStair(page,'ascend');const returned=await snapshot(page);expect(returned.depth).toBe(1);expect(returned.floors[0].completed).toBe(3);expect(returned.ownership).toEqual(second.ownership);expect(returned.floors[0].position).toBe(returned.floors[0].descriptor.downstairs);
  293 |    await expect(page.locator('#dungeon-start-encounter')).toHaveCount(0);await reenterDungeonStair(page,'descend');const revisited=await snapshot(page);expect(revisited.floors.map(f=>f.descriptor)).toEqual(second.floors.map(f=>f.descriptor));expect(revisited.floors.map(f=>f.completed)).toEqual(second.floors.map(f=>f.completed));
  294 |    expect((await snapshot(page)).depth).toBe(2);expect((await snapshot(page)).party).toEqual(second.party);expect((await snapshot(page)).ownership).toEqual(second.ownership);
  295 |    expect(await page.evaluate(()=>localStorage.getItem('tactics-guru:phaser:run:primary:v1'))).toBe('preserved-short-run');
  296 |    await page.screenshot({path:test.info().outputPath('floor-two-revisited.png'),fullPage:true});
  297 |   }
  298 |  }
  299 |  expect(errors).toEqual([]);
  300 | });
  301 | test('corrupt bytes stay exportable and uncertain travel requires explicit recovery',async({page})=>{
  302 |  test.setTimeout(90000);const f=fixture(2),result=dispatch(f.snapshot.activeBattle!,f.command,dungeonBattle(f.snapshot)!.catalog);if(!result.ok)throw Error('fixture failed');
  303 |  const cleared=acceptDungeonBattle(f.snapshot,result.state);if(!cleared.ok)throw Error(cleared.reason);
  304 |  const approach=atStairApproach(cleared.state);await seed(page,approach);await page.evaluate(()=>{const original=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){original.call(this,k,v);if(k==='tactics-guru:phaser:dungeon:primary:v1')throw Error('uncertain primary write');};});
  305 |  await page.locator(`#dungeon-map [data-cell="${approach.floors[0].descriptor.downstairs}"]`).click();expect(await snapshot(page)).toEqual(approach);await expect(page.locator('.dungeon-status')).toContainText('Travel not published');
  306 |  await page.getByRole('button',{name:'Save recovery',exact:true}).click();await page.locator('#dungeon-continue-primary').click();expect((await snapshot(page)).depth).toBe(2);
  307 |  await page.evaluate(key=>localStorage.setItem(key,'broken save bytes'),DUNGEON_KEYS.primary).catch(()=>{});await page.reload();
  308 |  await page.getByRole('button',{name:'Save recovery',exact:true}).click();
  309 |  const downloadPromise=page.waitForEvent('download');await page.getByRole('button',{name:'Export primary save',exact:true}).click();await downloadPromise;
  310 |  expect(await page.evaluate(key=>localStorage.getItem(key),DUNGEON_KEYS.primary)).toBe('broken save bytes');
  311 |  await page.getByRole('button',{name:'Save recovery',exact:true}).click();await page.locator('#dungeon-remove-primary').click();await page.locator('#dungeon-remove-cancel').click();
  312 |  expect(await page.evaluate(key=>localStorage.getItem(key),DUNGEON_KEYS.primary)).toBe('broken save bytes');
  313 | });
  314 | 
  315 | test('confirmed charm discard frees full capacity without cancelling or duplicating the pending reward',async({page,isMobile})=>{
  316 |  const initial=dungeonCapacityFixture();await seed(page,initial);
  317 |  const target=initial.ownership.equipment[0].instanceId;
```
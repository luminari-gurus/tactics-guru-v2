# Verification timing report

Source: 28cba2a3fe3aab8a36e9d87579945ec68768c19b (dirty: false)
Conditions: Serial final repair qualification; original aggregate finished; same Linux host and pinned engines; no other task-owned browser GPU work; dependencies unchanged
Complete: true; passed: true

| Stage | Result | Wall seconds | Counts |
| --- | --- | ---: | --- |
| units | passed | 21.49 | {"total":1049,"passed":1049,"failed":0,"pending":0,"todo":0} |
| typecheck-app | passed | 0.46 | {} |
| typecheck-domain | passed | 0.08 | {} |
| build-integration | passed | 3.61 | {"total":2,"passed":2,"failed":0,"pending":0,"todo":0} |
| build-root | passed | 0.63 | {} |
| performance | passed | 41.95 | {"samples":18} |

Wall time includes process startup, server startup and teardown. Summed test durations are work, not wall time.
Queue time is unavailable for this local runner. Raw reports/logs retain failures and skips.

Content subset: {"total":223,"passed":223,"failed":0,"pending":0}; summed test work 15.50s (included in units, not a separate wall-time phase).

## units: slowest files

- tests/unit/dungeon.test.ts: 20.39s
- tests/unit/dungeonBattle.test.ts: 18.35s
- tests/unit/runBattle.test.ts: 14.61s
- tests/unit/authoredEncounters.test.ts: 12.25s
- tests/unit/measureFitPreview.test.ts: 11.85s
- tests/unit/runRecoveryFixtures.test.ts: 10.87s
- tests/unit/overworldMap.test.ts: 9.07s
- tests/unit/battleSession.test.ts: 7.65s
- tests/unit/battlefieldSimulation.test.ts: 5.25s
- tests/unit/battlefieldContinuation.test.ts: 3.47s

## build-integration: slowest files

- tests/integration/buildHeaders.test.ts: 3.12s

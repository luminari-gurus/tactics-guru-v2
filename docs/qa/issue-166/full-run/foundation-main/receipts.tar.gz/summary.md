# Verification timing report

Source: 03b1e899ad091ba79ba65b08487204427b23de1e (dirty: false)
Conditions: Serial foundation merge with main b343ab0; unchanged dependencies and foundation content/art; no parallel browser GPU jobs
Complete: true; passed: true

| Stage | Result | Wall seconds | Counts |
| --- | --- | ---: | --- |
| units | passed | 22.65 | {"total":1032,"passed":1032,"failed":0,"pending":0,"todo":0} |
| typecheck-app | passed | 0.76 | {} |
| typecheck-domain | passed | 0.11 | {} |
| build-integration | passed | 4.42 | {"total":2,"passed":2,"failed":0,"pending":0,"todo":0} |
| build-root | passed | 0.86 | {} |

Wall time includes process startup, server startup and teardown. Summed test durations are work, not wall time.
Queue time is unavailable for this local runner. Raw reports/logs retain failures and skips.

Content subset: {"total":222,"passed":222,"failed":0,"pending":0}; summed test work 13.93s (included in units, not a separate wall-time phase).

## units: slowest files

- tests/unit/dungeon.test.ts: 21.45s
- tests/unit/dungeonBattle.test.ts: 15.50s
- tests/unit/runBattle.test.ts: 13.81s
- tests/unit/measureFitPreview.test.ts: 11.32s
- tests/unit/authoredEncounters.test.ts: 11.04s
- tests/unit/runRecoveryFixtures.test.ts: 9.74s
- tests/unit/overworldMap.test.ts: 8.09s
- tests/unit/battleSession.test.ts: 6.31s
- tests/unit/battlefieldSimulation.test.ts: 4.43s
- tests/unit/turns.test.ts: 2.82s

## build-integration: slowest files

- tests/integration/buildHeaders.test.ts: 3.77s

# Verification timing report

Source: f4616ae301da4be133455334d4c2b38e3583c8f7 (dirty: false)
Conditions: Serial combined main b343ab0 and Shaman integration; conflicts resolved at f4616ae; unchanged dependencies; one worker and no parallel browser GPU jobs
Complete: true; passed: true

| Stage | Result | Wall seconds | Counts |
| --- | --- | ---: | --- |
| units | passed | 24.59 | {"total":1069,"passed":1069,"failed":0,"pending":0,"todo":0} |
| typecheck-app | passed | 0.57 | {} |
| typecheck-domain | passed | 0.09 | {} |
| build-integration | passed | 4.13 | {"total":2,"passed":2,"failed":0,"pending":0,"todo":0} |
| build-root | passed | 0.73 | {} |
| performance | passed | 42.58 | {"samples":18} |

Wall time includes process startup, server startup and teardown. Summed test durations are work, not wall time.
Queue time is unavailable for this local runner. Raw reports/logs retain failures and skips.

Content subset: {"total":223,"passed":223,"failed":0,"pending":0}; summed test work 17.25s (included in units, not a separate wall-time phase).

## units: slowest files

- tests/unit/dungeon.test.ts: 23.37s
- tests/unit/dungeonBattle.test.ts: 20.50s
- tests/unit/runBattle.test.ts: 16.08s
- tests/unit/authoredEncounters.test.ts: 13.52s
- tests/unit/measureFitPreview.test.ts: 12.61s
- tests/unit/runRecoveryFixtures.test.ts: 11.43s
- tests/unit/overworldMap.test.ts: 10.06s
- tests/unit/battleSession.test.ts: 7.52s
- tests/unit/battlefieldSimulation.test.ts: 5.03s
- tests/unit/saveEnvelope.test.ts: 3.86s

## build-integration: slowest files

- tests/integration/buildHeaders.test.ts: 3.59s

# Verification timing report

Source: 3197945cdcf79e2788d2271ac3f328ea9d3d577d (dirty: false)
Conditions: Qualification only; not a full baseline
Complete: true; passed: true

| Stage | Result | Wall seconds | Counts |
| --- | --- | ---: | --- |
| tooling | passed | 0.41 | {} |
| typecheck-app | passed | 0.88 | {} |
| typecheck-domain | passed | 0.14 | {} |

Wall time includes process startup, server startup and teardown. Summed test durations are work, not wall time.
Queue time is unavailable for this local runner. Raw reports/logs retain failures and skips.

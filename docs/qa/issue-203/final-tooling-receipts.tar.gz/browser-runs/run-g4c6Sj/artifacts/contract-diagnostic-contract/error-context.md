# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: contract.spec.ts >> diagnostic contract
- Location: tmp/browser-diagnostics-WVapX6/contract.spec.ts:3:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "intentional mismatch"
Received: "Browser diagnostic contract"
```

# Page snapshot

```yaml
- paragraph [ref=e2]: Browser diagnostic contract
```

# Test source

```ts
  1 | 
  2 |       import { test, expect } from '@playwright/test';
  3 |       test('diagnostic contract', async ({ page }) => {
  4 |         await page.setContent('<p>Browser diagnostic contract</p>');
> 5 |         expect(await page.locator('p').textContent()).toBe(process.env.DIAGNOSTIC_EXPECTED);
    |                                                       ^ Error: expect(received).toBe(expected) // Object.is equality
  6 |       });
  7 |     
```
import {spawnSync} from 'node:child_process';
import {mkdirSync,openSync,closeSync,readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {stages,runStages,stageEnvironment} from '../../scripts/verify-full.mjs';
import {sourceIdentity,digest} from '../../scripts/verification-report.mjs';
const directory=resolve('tmp/issue-163-full/focused-assets');mkdirSync(directory,{recursive:true});
const source=sourceIdentity(process.cwd()),filter=['-g','battle direct entry and refresh resolve public assets'];
const original=id=>stages.find(s=>s.id===id);
const focused=(id,from,args)=>({...original(from),id,args,needs:[]});
const plan=[
  focused('assets-root-preview','chromium',[...original('chromium').args,'tests/public-asset-base.spec.ts',...filter]),
  focused('assets-root-dev','assets-root-dev',[...original('assets-root-dev').args,...filter]),
  {...original('build-prefix'),needs:[]},
  {...focused('assets-prefix-preview','assets-prefix-preview',[...original('assets-prefix-preview').args,...filter]),needs:['build-prefix']},
  focused('assets-prefix-dev','assets-prefix-dev',[...original('assets-prefix-dev').args,...filter]),
  {...original('restore-root'),needs:[]},
  {...original('performance'),needs:['restore-root']},
];
const inventory=path=>readdirSync(path,{withFileTypes:true}).flatMap(e=>e.isDirectory()?inventory(join(path,e.name)):[{path:join(path,e.name).replaceAll('\\','/'),sha256:digest(readFileSync(join(path,e.name)))}]);
writeFileSync(join(directory,'initial-root-files.json'),JSON.stringify(inventory('dist'),null,2));
const result=runStages(plan,stage=>{
  const argv=[...stage.args],log=join(directory,stage.id+'.log');
  if(stage.browser)argv.push('--reporter=line,json','--output',join(directory,stage.id+'-artifacts'));
  if(stage.id==='performance')argv.push('--',join(directory,'performance.json'));
  const fd=openSync(log,'w');let child;
  try{child=spawnSync(process.execPath,['C:/Users/apexw/.codex/tmp/issue163-tools/package/bin/npm-cli.js',...argv],{env:stageEnvironment(stage,directory),stdio:['ignore',fd,fd]});}
  finally{closeSync(fd);}
  if(['build-prefix','restore-root'].includes(stage.id)&&child.status===0)writeFileSync(join(directory,stage.id+'-files.json'),JSON.stringify(inventory('dist'),null,2));
  return {exitCode:child.status,signal:child.signal,error:child.error?.message,command:['npm',...argv],log};
},results=>{writeFileSync(join(directory,'summary.json'),JSON.stringify({source,prerequisites:'968 unit tests and both type scopes retained; last source changes are test fixtures/config and a comment only',results},null,2));console.log(results.at(-1).id+': '+results.at(-1).status);});
process.exitCode=result.exitCode;

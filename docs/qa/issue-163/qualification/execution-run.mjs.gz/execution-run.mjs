import { spawnSync } from 'node:child_process';
import { mkdirSync, openSync, closeSync, readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { stages, runStages, stageEnvironment } from '../../scripts/verify-full.mjs';
import { sourceIdentity, digest } from '../../scripts/verification-report.mjs';

const root=process.cwd(), directory=resolve('tmp/issue-163-full/qualification');
mkdirSync(directory,{recursive:true});
const source=sourceIdentity(root), previous=JSON.parse(readFileSync('docs/qa/issue-163/feature-inputs.json','utf8'));
if(source.inputHash!==previous.inputHash)throw Error('Verification inputs changed since passing unit/type evidence');
writeFileSync(join(directory,'source.json'),JSON.stringify(source,null,2));
const reusable={units:'docs/qa/issue-163/full-units-final2.log.gz',typecheck:'docs/qa/issue-163/iteration8-typecheck.log.gz'};
const inventory=path=>readdirSync(path,{withFileTypes:true}).flatMap(e=>e.isDirectory()?inventory(join(path,e.name)):[{path:join(path,e.name).replaceAll('\\','/'),sha256:digest(readFileSync(join(path,e.name)))}]);
const result=runStages(stages,stage=>{
  if(reusable[stage.id])return {exitCode:0,reused:true,evidence:reusable[stage.id],evidenceSha256:digest(readFileSync(reusable[stage.id])),testedInputs:source.inputHash};
  const log=join(directory,stage.id+'.log'), argv=[...stage.args];
  if(stage.browser)argv.push('--reporter=line,json','--output',join(directory,stage.id+'-artifacts'));
  if(stage.id==='performance')argv.push('--',join(directory,'performance.json'));
  console.log('Running '+stage.id);
  const fd=openSync(log,'w');let child;
  try{child=spawnSync(process.execPath,['C:/Users/apexw/.codex/tmp/issue163-tools/package/bin/npm-cli.js',...argv],{cwd:root,env:stageEnvironment(stage,directory),stdio:['ignore',fd,fd]});}
  finally{closeSync(fd);}
  if(stage.id==='build-root' && child.status===0)writeFileSync(join(directory,'build-root-files.json'),JSON.stringify(inventory('dist'),null,2));
  return {exitCode:child.status,signal:child.signal,error:child.error?.message,command:['npm',...argv],log};
},results=>{
  writeFileSync(join(directory,'summary.json'),JSON.stringify({source,results},null,2));
  console.log(results.at(-1).id+': '+results.at(-1).status);
});
console.log('Qualification finished: '+directory);
process.exitCode=result.exitCode;

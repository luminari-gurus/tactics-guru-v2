#!/bin/bash
set -eu
task_root=/home/aiwithapex/.cache/issue163-webkit-linux
task_out=/mnt/c/Users/apexw/OneDrive/Desktop/Projects/Tactics-Guru/tmp/issue-163-full
export PATH=/home/aiwithapex/.cache/issue163-tools/bin:/home/aiwithapex/.cache/issue163-tools/node-v24.19.0-linux-x64/bin:/usr/local/bin:/usr/bin:/bin
git -C "$task_root" checkout --quiet --detach 9157214fe4a7ebc2df5bd21f9de4200c26e7f3bf
cd "$task_root"
# Deliberately invalid: a WebKit run must never try this Chromium-only override.
export PLAYWRIGHT_CHROMIUM_EXECUTABLE=/invalid/chromium-override-must-not-reach-webkit
unset PLAYWRIGHT_BASE_PATH PLAYWRIGHT_SERVER_MODE PLAYWRIGHT_TELEMETRY_DEV
node --input-type=module > "$task_out/engine-linux-source.json" <<'JS'
import fs from 'node:fs';import os from 'node:os';import crypto from 'node:crypto';import {createRequire} from 'node:module';import {sourceIdentity} from './scripts/verification-report.mjs';
const require=createRequire(import.meta.url),files=JSON.parse(fs.readFileSync('/mnt/c/Users/apexw/OneDrive/Desktop/Projects/Tactics-Guru/tmp/issue-163-full/qualification/build-root-files.json','utf8'));
for(const f of files)if(crypto.createHash('sha256').update(fs.readFileSync(f.path)).digest('hex')!==f.sha256)throw Error('Build copy differs: '+f.path);
console.log(JSON.stringify({source:sourceIdentity(process.cwd()),node:process.version,platform:process.platform,arch:process.arch,release:os.release(),playwright:require('@playwright/test/package.json').version,chromiumOverride:'deliberately invalid sentinel',servedBuild:'d208a6b Windows root artifact; all 100 files verified',files},null,2));
JS
export PLAYWRIGHT_JSON_OUTPUT_FILE="$task_out/engine-linux-acceptance.json"
node node_modules/playwright/cli.js test -c playwright.device-acceptance.config.ts --reporter=line,json --output "$task_out/engine-linux-acceptance-artifacts" > "$task_out/engine-linux-acceptance.log" 2>&1

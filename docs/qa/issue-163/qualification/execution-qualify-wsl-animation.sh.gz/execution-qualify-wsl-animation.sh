#!/bin/bash
set -eu
cd /home/aiwithapex/.cache/issue163-webkit-linux
task_out=/mnt/c/Users/apexw/OneDrive/Desktop/Projects/Tactics-Guru/tmp/issue-163-full
export PATH=/home/aiwithapex/.cache/issue163-tools/bin:/home/aiwithapex/.cache/issue163-tools/node-v24.19.0-linux-x64/bin:/usr/local/bin:/usr/bin:/bin
export PLAYWRIGHT_CHROMIUM_EXECUTABLE=/invalid/chromium-override-must-not-reach-webkit
mkdir -p tmp/issue-163
cat > tmp/issue-163/webkit-animation.config.ts <<'TS'
import {defineConfig,devices} from '@playwright/test';
import {resolve} from 'node:path';
import base from '../../playwright.config';
export default defineConfig({...base,testDir:resolve('tests'),testMatch:'**/battle-animations.spec.ts',
  grep:/spent action and effective Guarded/,
  use:{baseURL:'http://127.0.0.1:4173/',launchOptions:{}},
  webServer:{...base.webServer,cwd:process.cwd()},
  projects:[{name:'webkit-launch-override',use:{...devices['iPhone 13'],launchOptions:{}}}],
});
TS
node --input-type=module > "$task_out/engine-linux-browser.json" <<'JS'
import fs from 'node:fs';import {webkit} from '@playwright/test';
const browser=await webkit.launch();
try{console.log(JSON.stringify({engine:'webkit',version:browser.version(),executable:webkit.executablePath(),node:process.version,chromiumOverride:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE},null,2));}
finally{await browser.close();}
JS
cp tmp/issue-163/webkit-animation.config.ts "$task_out/webkit-animation.config.ts.txt"
export PLAYWRIGHT_JSON_OUTPUT_FILE="$task_out/engine-linux-animation.json"
node node_modules/playwright/cli.js test -c tmp/issue-163/webkit-animation.config.ts --reporter=line,json --output "$task_out/engine-linux-animation-artifacts" > "$task_out/engine-linux-animation.log" 2>&1

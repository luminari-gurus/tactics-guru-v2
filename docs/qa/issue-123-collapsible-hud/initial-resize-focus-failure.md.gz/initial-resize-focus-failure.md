# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-hud-collapse.spec.ts >> collapsed runtime errors remain reachable and recovery modal returns to visible toggle
- Location: tests/battle-hud-collapse.spec.ts:82:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('dialog')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('dialog') with timeout 5000ms
  - waiting for getByRole('dialog')

```

```yaml
- main "Tactics Guru game canvas"
- region "Battlefield":
  - paragraph: Tactics Guru
  - heading "Forest Ruins" [level=1]
  - paragraph: "Gold: active · White: selected · Teal: reachable"
- complementary "Battle controls":
  - paragraph: Round 1 · Your turn
  - img "Mage portrait"
  - heading "Mage" [level=2]
  - paragraph: HP 11/11
  - paragraph: AC 11 · Accuracy +3
  - paragraph: No status effects
  - paragraph: Move ready / Action ready
  - paragraph: Choose your action
  - button "Move":
    - strong: Move
    - text: Uses movement
  - button "Basic attack":
    - strong: Basic attack
    - text: Uses action
  - button "Magic Missile":
    - strong: Magic Missile
    - text: Uses action
  - button "Wait / End turn":
    - strong: Wait / End turn
    - text: Ends turn immediately
  - paragraph: Choose an action, then a target. Wait ends the turn immediately.
  - region "Target and action preview":
    - text: Target / destination
    - combobox "Target / destination" [disabled]:
      - option "Choose target" [selected]
    - paragraph: Select a tile
    - paragraph
    - paragraph: Choose an action and target
    - button "Review action" [disabled]
    - button "Cancel action" [disabled]
  - navigation "Secondary battle tools":
    - button "Inspect party"
    - button "Battle log"
    - button "Enable sound"
  - paragraph: Sound off
  - status: Battle ready
  - button "Restart battle"
  - text: Continued saved battle
  - button "Save recovery"
  - paragraph: "Gold: active · White: selected · Teal: reachable · Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
  - link "Play three-encounter run":
    - /url: /run
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { projectTile } from '../src/geometry/iso';
  3  | import { confirmRestart, readSession } from './helpers/battlePolicy';
  4  | 
  5  | async function settled(page:Page) {
  6  |   await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve())))));
  7  |   return JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  8  | }
  9  | async function activate(page:Page, selector='#battle-hud-toggle') {
  10 |   if(test.info().project.use.hasTouch) await page.locator(selector).tap();
  11 |   else await page.locator(selector).click();
  12 | }
  13 | for(const [width,height] of [[390,844],[360,640],[844,390],[915,412]]) {
  14 |   test(`mobile HUD preserves intent, geometry and accessible input at ${width}x${height}`,async({page},info)=>{
  15 |     await page.setViewportSize({width,height});
  16 |     const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  17 |     await page.goto('/');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  18 |     const toggle=page.locator('#battle-hud-toggle');await expect(toggle).toHaveAttribute('aria-expanded','true');
  19 |     await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});
  20 |     const before=await page.locator('#game').getAttribute('data-session');
  21 |     const actor=await page.locator('#battle-actor').textContent(),preview=await page.locator('#battle-preview').textContent();
  22 |     const initial=await settled(page);
  23 |     for(let i=0;i<3;i++) {
  24 |       await activate(page);await expect(toggle).toHaveAttribute('aria-expanded','false');
  25 |       await expect(page.locator('#battle-hud-contents')).toBeHidden();
  26 |       const collapsed=await settled(page);
  27 |       expect(collapsed.region.width*collapsed.region.height).toBeGreaterThan(initial.region.width*initial.region.height);
  28 |       expect(collapsed.selectionEvents).toBe(initial.selectionEvents);
  29 |       expect(await page.locator('#game').getAttribute('data-session')).toBe(before);
  30 |       const box=(await toggle.boundingBox())!;expect(box.width).toBeGreaterThanOrEqual(44);expect(box.height).toBeGreaterThanOrEqual(44);
  31 |       expect(box.x).toBeGreaterThanOrEqual(0);expect(box.y+box.height).toBeLessThanOrEqual(height);
  32 |       await toggle.focus();await page.keyboard.press('Tab');
  33 |       expect(await page.evaluate(()=>!!document.activeElement?.closest('#battle-hud-contents'))).toBe(false);
  34 |       await toggle.focus();await page.keyboard.press('Enter');await expect(toggle).toHaveAttribute('aria-expanded','true');
  35 |       expect(await page.locator('#battle-actor').textContent()).toBe(actor);expect(await page.locator('#battle-preview').textContent()).toBe(preview);
  36 |       expect(await page.locator('#game').getAttribute('data-session')).toBe(before);
  37 |     }
  38 |     await page.locator('#battle-review').focus();await page.keyboard.press('Enter');
  39 |     await expect(page.getByRole('dialog')).toBeVisible();
  40 |     // Native modal capture blocks the toggle while reviewing.
  41 |     await page.keyboard.press('Tab');expect(await page.evaluate(()=>!!document.activeElement?.closest('dialog'))).toBe(true);
  42 |     await page.locator('#dialog-cancel').click();
  43 |     await activate(page);await page.screenshot({path:info.outputPath(`collapsed-${width}x${height}.png`)});
  44 |     const collapsed=await settled(page);
  45 |     const cell=collapsed.tiles.find((tile:any)=>{
  46 |       const p=projectTile(tile),x=collapsed.transform.x+p.x*collapsed.transform.scale,y=collapsed.transform.y+p.y*collapsed.transform.scale;
  47 |       return x>collapsed.region.x+20&&x<collapsed.region.x+collapsed.region.width-20&&y>collapsed.region.y+20&&y<collapsed.region.y+collapsed.region.height-20;
  48 |     });
  49 |     expect(cell).toBeTruthy();const p=projectTile(cell),x=collapsed.transform.x+p.x*collapsed.transform.scale,y=collapsed.transform.y+p.y*collapsed.transform.scale;
  50 |     if(info.project.use.hasTouch)await page.touchscreen.tap(x,y);else await page.mouse.click(x,y);
  51 |     expect((await settled(page)).selectionEvents).toBe(collapsed.selectionEvents+1);
  52 |     expect((await readSession(page)).state).toEqual(JSON.parse(before!).state);
  53 |     await page.setViewportSize({width:1280,height:720});await expect(toggle).toBeHidden();await expect(page.locator('#battle-hud-contents')).toBeVisible();
  54 |     await page.setViewportSize({width:height,height:width});await expect(toggle).toHaveAttribute('aria-expanded','false');
  55 |     await activate(page);await page.locator('#fit-restart').click();await confirmRestart(page);await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  56 |     await activate(page);await expect(toggle).toHaveAttribute('aria-expanded','false');
  57 |     await page.reload();await expect(toggle).toHaveAttribute('aria-expanded','true');
  58 |     expect(errors).toEqual([]);
  59 |   });
  60 | }
  61 | 
  62 | test('collapsed camera navigation, stale gestures and presentation remain safe',async({page})=>{
  63 |   await page.setViewportSize({width:915,height:412});await page.goto('/');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  64 |   await activate(page);const initial=await settled(page),r=initial.region;
  65 |   await page.mouse.move(r.x+r.width/2,r.y+r.height/2);await page.mouse.wheel(0,-180);
  66 |   const zoomed=await settled(page);expect(zoomed.transform.scale).toBeGreaterThan(initial.transform.scale);
  67 |   await page.mouse.down();await page.mouse.move(r.x+r.width/2+25,r.y+r.height/2+10,{steps:4});await page.mouse.up();
  68 |   const panned=await settled(page);const count=(await readSession(page)).state.commandCount;
  69 |   await activate(page);await activate(page);const restored=await settled(page);
  70 |   expect(restored.transform.scale).toBeCloseTo(panned.transform.scale,5);expect(restored.selectionEvents).toBe(panned.selectionEvents);
  71 |   // Resize resets an in-flight pointer before its release can select a tile.
  72 |   await page.mouse.move(r.x+r.width/2,r.y+r.height/2);await page.mouse.down();await page.setViewportSize({width:844,height:390});await settled(page);await page.mouse.up();
  73 |   expect((await settled(page)).selectionEvents).toBe(restored.selectionEvents);expect((await readSession(page)).state.commandCount).toBe(count);
  74 |   await activate(page);await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
  75 |   await page.clock.install();await page.clock.pauseAt(new Date(Date.now()+1000));await page.locator('#dialog-confirm').click({force:true});
  76 |   await expect(page.locator('#game')).toHaveAttribute('data-phase','presenting');
  77 |   await page.locator('#battle-hud-toggle').click({force:true});await page.locator('#battle-hud-toggle').click({force:true});
  78 |   await expect(page.locator('#battle-next')).toBeDisabled();expect((await readSession(page)).state.commandCount).toBe(count+1);
  79 |   await page.clock.resume();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  80 | });
  81 | 
  82 | test('collapsed runtime errors remain reachable and recovery modal returns to visible toggle',async({page})=>{
  83 |   await page.setViewportSize({width:390,height:844});await page.goto('/');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  84 |   await activate(page);await page.evaluate(()=>window.dispatchEvent(new ErrorEvent('error',{message:'controlled HUD acceptance error'})));
  85 |   await activate(page);await expect(page.locator('#fit-status')).toContainText('Error:');
  86 |   await page.reload();await page.locator('#save-continue').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  87 |   await activate(page);await page.setViewportSize({width:1280,height:720});
> 88 |   await page.locator('#fit-restart').focus();await page.keyboard.press('Enter');await expect(page.getByRole('dialog')).toBeVisible();
     |                                                                                                                        ^ Error: expect(locator).toBeVisible() failed
  89 |   await page.setViewportSize({width:390,height:844});
  90 |   await page.locator('#save-cancel-reset').click();await expect(page.locator('#battle-hud-toggle')).toBeFocused();
  91 |   await expect(page.locator('#battle-hud-contents')).toBeHidden();
  92 | });
  93 | 
```
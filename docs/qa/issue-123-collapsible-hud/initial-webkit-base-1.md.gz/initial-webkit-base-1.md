# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-persistence.spec.ts >> changed saved data refuses an old confirmation and requires fresh review
- Location: tests/battle-persistence.spec.ts:179:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('#fit-restart')
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" locator('#fit-restart') with timeout 5000ms
  - waiting for locator('#fit-restart')
    14 × locator resolved to <button type="button" id="fit-restart">Restart battle</button>
       - unexpected value "inactive"

```

```yaml
- button "Restart battle"
```

# Test source

```ts
  85  |   const errors:string[]=[];for(const p of [page,control])p.on('pageerror',e=>errors.push(e.message));
  86  |   try {
  87  |     for(const p of [page,control]){await p.clock.install();await seedTwo(p);}
  88  |     if(side==='player'){
  89  |       for(const p of [page,control]){await chooseMove(p);await freeze(p);await p.locator('#dialog-confirm').click({force:true});}
  90  |     }else {
  91  |       // Wait through actual player controls and advance just enough to reach an enemy's accepted command.
  92  |       for(const p of [page,control]){
  93  |         await freeze(p);
  94  |         for(let i=0;i<30;i++){
  95  |           const s=await readSession(p),command=s.replay?.commands.at(-1);
  96  |           if(s.phase==='presenting' && command && s.state.units.find(u=>u.id===command.unitId)!.side==='enemy')break;
  97  |           if(s.phase==='player')await p.locator('#battle-next').click({force:true});
  98  |           await p.clock.runFor(32);
  99  |         }
  100 |       }
  101 |     }
  102 |     const boundary=await readSession(page);expect(boundary.phase).toBe('presenting');expect((await readSession(control)).state).toEqual(boundary.state);
  103 |     const last=boundary.replay!.commands.at(-1)!;expect(boundary.state.units.find(u=>u.id===last.unitId)!.side).toBe(side);
  104 |     const save=(await stored(page)).primary!,decoded=decodeBattleSave(save,catalog);expect(decoded.ok).toBe(true);if(decoded.ok)expect(decoded.state).toEqual(boundary.state);
  105 |     await page.reload();await page.clock.resume();await expect(page.locator('#save-continue')).toBeVisible();
  106 |     await page.locator('#save-continue').click();await control.clock.resume();
  107 |     await ready(page);await ready(control);
  108 |     expect((await readSession(page)).state).toEqual((await readSession(control)).state);
  109 |     const resumed=await readSession(page);expect(resumed.continuation!.snapshot).toEqual(boundary.state);
  110 |     expect(resumed.replay).toBeNull();
  111 |     const future=(await readSession(control)).events.slice(boundary.events.length);
  112 |     expect(resumed.events).toEqual(future);
  113 |     // Next legal player command and ensuing enemy continuation must also agree.
  114 |     const command=playerDecision(resumed.state);
  115 |     await playCommand(page,command);await playCommand(control,command);await ready(page);await ready(control);
  116 |     expect((await readSession(page)).state).toEqual((await readSession(control)).state);
  117 |     expect((await readSession(page)).events).toEqual((await readSession(control)).events.slice(boundary.events.length));
  118 |     await expect(page.locator('canvas')).toHaveCount(1);expect(errors).toEqual([]);
  119 |   } finally {await controlContext.close();}
  120 | });
  121 | 
  122 | test('backup recovery retains damaged primary, exports exact text, removes only after confirmation and resumes saving',async({page})=>{
  123 |   await seedTwo(page);const snapshot=(await stored(page)).primary!;
  124 |   const broken='\ud800\u0000<script>bad</script>'+'x'.repeat(20000);
  125 |   await page.evaluate(({keys,snapshot,broken})=>{localStorage.setItem(keys.backup,snapshot);localStorage.setItem(keys.primary,broken);localStorage.setItem('unrelated','keep');},{keys,snapshot,broken});
  126 |   await page.reload();await expect(page.locator('#save-continue')).toHaveText('Continue backup');
  127 |   await expect(page.getByRole('dialog')).toContainText('some progress may be lost');
  128 |   const downloading=page.waitForEvent('download');await page.locator('#save-export').click();const download=await downloading;
  129 |   const file=await download.path();expect(file).not.toBeNull();const exported=JSON.parse(readFileSync(file!,'utf8'));
  130 |   expect(exported.slots).toEqual(expect.arrayContaining([{slot:'primary',text:broken},{slot:'backup',text:snapshot}]));
  131 |   await page.locator('#save-continue').click();await ready(page);await expect(page.locator('#battle-save-status')).toContainText('unsaved');
  132 |   const before=(await readSession(page)).state.commandCount;await playCommand(page,playerDecision((await readSession(page)).state));await ready(page);
  133 |   expect((await readSession(page)).state.commandCount).toBeGreaterThan(before);expect((await stored(page)).primary).toBe(broken);
  134 |   await page.locator('#battle-recovery').click();await page.locator('#save-remove-primary').click();await page.locator('#save-cancel-remove').click();
  135 |   expect((await stored(page)).primary).toBe(broken);
  136 |   await page.locator('#save-remove-primary').click();await page.locator('#save-confirm-remove').click();
  137 |   expect((await stored(page)).primary).toBeNull();await page.locator('#save-retry').click();await page.locator('#save-close').click();
  138 |   await expect(page.locator('#battle-save-status')).toContainText('Battle saved');
  139 |   const decoded=decodeBattleSave((await stored(page)).primary!,catalog);expect(decoded.ok).toBe(true);if(decoded.ok)expect(decoded.state).toEqual((await readSession(page)).state);
  140 |   expect(await page.evaluate(()=>localStorage.getItem('unrelated'))).toBe('keep');
  141 | });
  142 | 
  143 | test('unknown storage blocks startup until retry; writes remain nonfatal during play',async({page})=>{
  144 |   await page.addInitScript(()=>{
  145 |     const get=Storage.prototype.getItem,set=Storage.prototype.setItem;
  146 |     Object.assign(window,{denyRead:true,denyWrite:false});
  147 |     Storage.prototype.getItem=function(key){if((window as any).denyRead && key.startsWith('tactics-guru:phaser:'))throw new DOMException('Denied','SecurityError');return get.call(this,key);};
  148 |     Storage.prototype.setItem=function(key,value){if((window as any).denyWrite && key.startsWith('tactics-guru:phaser:'))throw new DOMException('Full','QuotaExceededError');return set.call(this,key,value);};
  149 |   });
  150 |   await page.goto('/');await expect(page.getByRole('dialog')).toContainText('unreadable');expect(await page.locator('#game').getAttribute('data-session')).toBeNull();
  151 |   await page.locator('#save-new').click();await page.locator('#save-confirm-reset').click();
  152 |   await expect(page.getByRole('dialog')).toContainText('Reset incomplete');expect(await page.locator('#game').getAttribute('data-session')).toBeNull();
  153 |   await page.evaluate(()=>Object.assign(window,{denyRead:false,denyWrite:true}));await page.locator('#save-retry').click();await ready(page);
  154 |   await expect(page.locator('#battle-save-status')).toContainText('unsaved');
  155 |   const before=(await readSession(page)).state.commandCount;await page.locator('#battle-next').click();await ready(page);
  156 |   expect((await readSession(page)).state.commandCount).toBeGreaterThan(before);
  157 |   await page.evaluate(()=>Object.assign(window,{denyWrite:false}));await page.locator('#battle-recovery').click();await page.locator('#save-retry').click();await page.locator('#save-close').click();
  158 |   await expect(page.locator('#battle-save-status')).toContainText('Battle saved');
  159 | });
  160 | 
  161 | test('failed partial reset retains battle, seed, recovery copies and usable controls; a retry succeeds once',async({page})=>{
  162 |   await seedTwo(page);const before=await readSession(page),old=await stored(page);
  163 |   await page.evaluate(keys=>{
  164 |     const remove=Storage.prototype.removeItem;
  165 |     Storage.prototype.removeItem=function(key){if(key===keys.primary)throw new DOMException('Denied','SecurityError');return remove.call(this,key);};
  166 |     Object.assign(window,{restoreRemove:()=>{Storage.prototype.removeItem=remove;}});
  167 |   },keys);
  168 |   await page.locator('#fit-restart').click();await page.locator('#save-confirm-reset').click();
  169 |   await expect(page.getByRole('dialog')).toContainText('Reset incomplete');expect((await readSession(page)).state).toEqual(before.state);
  170 |   expect((await stored(page)).backup).toBeNull();expect((await stored(page)).primary).toBe(old.primary);
  171 |   const downloadEvent=page.waitForEvent('download');await page.locator('#save-export').click();const download=await downloadEvent;
  172 |   expect(JSON.parse(readFileSync((await download.path())!,'utf8')).slots).toEqual(expect.arrayContaining([{slot:'primary',text:old.primary},{slot:'backup',text:old.backup}]));
  173 |   await page.locator('#save-close').click();await expect(page.locator('#fit-restart')).toBeEnabled();await expect(page.locator('#fit-status')).toHaveText('Battle ready');
  174 |   await page.evaluate(()=>(window as any).restoreRemove());await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);
  175 |   expect((await readSession(page)).state.seed).toBe(3);await expect(page.locator('canvas')).toHaveCount(1);
  176 |   await page.reload();await page.locator('#save-continue').click();await ready(page);expect((await readSession(page)).state.seed).toBe(3);
  177 | });
  178 | 
  179 | test('changed saved data refuses an old confirmation and requires fresh review',async({page})=>{
  180 |   await seedTwo(page);await page.locator('#fit-restart').click();
  181 |   await page.evaluate(keys=>localStorage.setItem(keys.primary,'changed'),keys);
  182 |   await page.locator('#save-confirm-reset').click();await expect(page.getByRole('dialog')).toContainText('Reset incomplete');
  183 |   expect((await stored(page)).primary).toBe('changed');expect((await readSession(page)).state.seed).toBe(2);
  184 |   await page.locator('#save-close').click();await page.locator('#fit-restart').click();await page.locator('#save-cancel-reset').click();
> 185 |   expect((await stored(page)).primary).toBe('changed');await expect(page.locator('#fit-restart')).toBeFocused();
      |                                                                                                   ^ Error: expect(locator).toBeFocused() failed
  186 | });
  187 | 
  188 | test('successful reset with failed fresh save cannot recover an old battle on reload',async({page})=>{
  189 |   await seedTwo(page);
  190 |   await page.evaluate(()=>{
  191 |     const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('tactics-guru:phaser:'))throw new DOMException('Full','QuotaExceededError');return set.call(this,key,value);};
  192 |   });
  193 |   await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);expect((await readSession(page)).state.seed).toBe(3);
  194 |   expect(await stored(page)).toEqual({primary:null,backup:null});await expect(page.locator('#battle-save-status')).toContainText('unsaved');
  195 |   await page.reload();await ready(page);expect((await readSession(page)).state.seed).toBe(1);await expect(page.getByRole('dialog')).not.toBeVisible();
  196 | });
  197 | 
  198 | for(const invalid of ['{broken',JSON.stringify({kind:'tactics-guru:battle-snapshot',format:99,payload:{},digest:'sha256:'+'0'.repeat(64)})])test(`invalid startup requires explicit reset: ${invalid.slice(0,12)}`,async({page})=>{
  199 |   await page.goto('/?scene=proof');await page.evaluate(({keys,invalid})=>localStorage.setItem(keys.primary,invalid),{keys,invalid});
  200 |   await page.goto('/');await expect(page.getByRole('dialog')).toContainText('needs recovery');await expect(page.locator('#save-continue')).toHaveCount(0);
  201 |   if(invalid.includes('"format":99'))await expect(page.getByRole('dialog')).toContainText('incompatible');
  202 |   expect((await stored(page)).primary).toBe(invalid);await page.locator('#save-new').click();
  203 |   await expect(page.locator('#save-confirm-reset')).toBeFocused();
  204 |   await page.locator('#save-cancel-reset').click();
  205 |   await expect(page.locator('#save-new')).toBeFocused();
  206 |   expect((await stored(page)).primary).toBe(invalid);await page.locator('#save-new').click();await page.locator('#save-confirm-reset').click();await ready(page);
  207 |   expect((await readSession(page)).state.seed).toBe(1);expect((await stored(page)).primary).not.toBe(invalid);
  208 | });
  209 | 
  210 | test.describe('browser history with BFCache enabled',()=>{
  211 |   test.beforeEach(async({page})=>{
  212 |     await page.addInitScript(()=>window.addEventListener('pageshow',event=>{
  213 |       if(event.persisted)sessionStorage.setItem('test:bfcache-return',location.href);
  214 |     }));
  215 |   });
  216 | 
  217 |   for(const cached of ['battle','recovery dialog'])test(`cached ${cached} cannot overwrite either slot of its replacement`,async({page,baseURL})=>{
  218 |     const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  219 |     const first=new URL('./?history=first',baseURL).href,map=new URL('map',baseURL).href;
  220 |     await page.goto(first);await ready(page);
  221 |     expect((await readSession(page)).state.seed).toBe(1);
  222 |     if(cached==='recovery dialog'){await page.reload();await expect(page.locator('#save-continue')).toBeVisible();}
  223 |     await page.goto(map);await expect(page.locator('#map-grid span')).toHaveCount(400);await page.goto(baseURL!);
  224 |     await page.locator('#save-new').click();await page.locator('#save-confirm-reset').click();await ready(page);
  225 |     const replacement=await readSession(page),saved=await stored(page);
  226 |     expect(replacement.state.seed).toBe(2);
  227 |     await page.goBack({waitUntil:'commit'});await expect(page).toHaveURL(map);
  228 |     await page.goBack({waitUntil:'commit'});
  229 |     await expect(page.locator('#save-continue')).toBeVisible();
  230 |     expect(await page.evaluate(()=>sessionStorage.getItem('test:bfcache-return'))).toBe(first);
  231 |     expect(await stored(page)).toEqual(saved);
  232 |     expect(await page.locator('#game').getAttribute('data-session')).toBeNull();
  233 |     await page.screenshot({path:test.info().outputPath('cached-return-recovery.png')});
  234 |     await page.locator('#save-continue').click();await ready(page);
  235 |     expect((await readSession(page)).state).toEqual(replacement.state);
  236 |     expect(await stored(page)).toEqual(saved);
  237 |     await page.locator('#battle-next').click();await ready(page);
  238 |     const after=await stored(page);
  239 |     for(const text of [after.primary,after.backup]){
  240 |       const decoded=decodeBattleSave(text!,catalog);expect(decoded.ok).toBe(true);
  241 |       if(decoded.ok)expect(decoded.state.seed).toBe(2);
  242 |     }
  243 |     expect(errors).toEqual([]);
  244 |   });
  245 | 
  246 |   for(const departure of ['player','presentation'])test(`cached return after restart at ${departure} preserves the accepted boundary`,async({page,baseURL})=>{
  247 |     const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  248 |     const first=new URL('./?history=first',baseURL).href,map=new URL('map',baseURL).href;
  249 |     await page.goto(first);await ready(page);
  250 |     await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);
  251 |     // Observe the last accepted boundary before the application's pagehide shutdown.
  252 |     await page.evaluate(keys=>window.addEventListener('pagehide',()=>{
  253 |       sessionStorage.setItem('test:departure',JSON.stringify({
  254 |         primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup),
  255 |       }));
  256 |     },{capture:true,once:true}),keys);
  257 |     if(departure==='presentation'){
  258 |       await page.evaluate(map=>{
  259 |         document.querySelector<HTMLButtonElement>('#battle-next')!.click();
  260 |         sessionStorage.setItem('test:departure-phase',document.querySelector<HTMLElement>('#game')!.dataset.phase!);
  261 |         location.assign(map);
  262 |       },map);
  263 |       await expect(page).toHaveURL(map);
  264 |       expect(await page.evaluate(()=>sessionStorage.getItem('test:departure-phase'))).toBe('presenting');
  265 |     }else await page.goto(map);
  266 |     await expect(page.locator('#map-grid span')).toHaveCount(400);
  267 |     const saved=JSON.parse((await page.evaluate(()=>sessionStorage.getItem('test:departure')))!);
  268 |     expect(await stored(page)).toEqual(saved);
  269 |     await page.goBack({waitUntil:'commit'});
  270 |     await expect(page.locator('#save-continue')).toBeVisible();
  271 |     expect(await page.evaluate(()=>sessionStorage.getItem('test:bfcache-return'))).toBe(first);
  272 |     expect(await stored(page)).toEqual(saved);
  273 |     await page.locator('#save-continue').click();await ready(page);
  274 |     const continued=await readSession(page),decoded=decodeBattleSave(saved.primary,catalog);
  275 |     expect(decoded.ok).toBe(true);
  276 |     if(decoded.ok)expect(continued.continuation!.snapshot).toEqual(decoded.state);
  277 |     expect(continued.state.seed).toBe(2);
  278 |     if(departure==='player'){expect(await stored(page)).toEqual(saved);expect(continued.events).toEqual([]);}
  279 |     await page.screenshot({path:test.info().outputPath(`continued-${departure}.png`)});
  280 |     expect(errors).toEqual([]);
  281 |   });
  282 | });
  283 | 
```
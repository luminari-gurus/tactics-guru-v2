# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-progression.spec.ts >> legal three encounter run, rewards, preparation, final resume and fresh restart
- Location: tests/run-progression.spec.ts:48:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 3
+ Received  + 3

@@ -1,9 +1,9 @@
  Object {
    "activeBattle": Object {
      "activeIndex": 2,
-     "commandCount": 5,
+     "commandCount": 6,
      "format": 1,
      "initiative": Array [
        5,
        3,
        4,
@@ -62,15 +62,15 @@
          "side": "player",
        },
        Object {
          "cell": Object {
            "x": 3,
-           "y": 3,
+           "y": 7,
          },
          "defId": "goblin_grunt",
          "hasActed": false,
-         "hasMoved": false,
+         "hasMoved": true,
          "hp": 5,
          "id": 4,
          "side": "enemy",
        },
        Object {
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Encounter 2 of 3 · woodland crossing" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable"
    - complementary "Run battle controls" [ref=e8]:
      - button "Show battle controls" [active] [ref=e9] [cursor=pointer]
```

# Test source

```ts
  1   | import {expect,test,type Page} from '@playwright/test';
  2   | import {readFileSync,writeFileSync} from 'node:fs';
  3   | import {readSession,playCommand} from './helpers/battlePolicy';
  4   | import {playerDecision} from './helpers/playerPolicy';
  5   | import {runContext} from './helpers/runItemFixtures';
  6   | import {runBattleCatalog,type RunSnapshot} from '../src/domain/runSaveEnvelope';
  7   | import {replayRunBattle} from '../src/domain/runBattle';
  8   | // Exercise actual BFCache rather than Playwright's default disabled cache.
  9   | test.use({launchOptions:{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE,ignoreDefaultArgs:['--disable-back-forward-cache']}});
  10  | import {RUN_STORAGE_KEYS} from '../src/persistence/runStorage';
  11  | async function snapshot(page:Page):Promise<RunSnapshot>{return JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);}
  12  | async function start(page:Page){
  13  |  await page.goto('/run');await page.locator('#run-start').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  14  |  await expect(page.locator('#battle-actor')).toBeVisible();
  15  |  const drawable=await page.locator('#battle-board-region').boundingBox();
  16  |  expect(drawable!.width).toBeGreaterThan(0);
  17  |  expect(drawable!.height).toBeGreaterThanOrEqual(page.viewportSize()!.height*0.3-1);
  18  | }
  19  | async function ready(page:Page){await expect.poll(async()=>await page.locator('#game').getAttribute('data-phase')??'boundary',{timeout:15000}).toMatch(/player|ended|boundary/);}
  20  | async function fight(page:Page,wait=false,collapse=false){
  21  |  for(let i=0;i<500;i++){
  22  |   await ready(page);const current=await snapshot(page);if(current.items.run.phase!=='battle')break;
  23  |   if(collapse && await page.locator('#battle-hud-toggle').isVisible() && await page.locator('#battle-hud-toggle').getAttribute('aria-expanded')==='false')await page.locator('#battle-hud-toggle').click();
  24  |   const battle=await readSession(page);expect(battle.phase).toBe('player');const catalog=runBattleCatalog(current.items,runContext)!;
  25  |   await playCommand(page,wait?{type:'endTurn',unitId:battle.state.initiative[battle.state.activeIndex]}:playerDecision(battle.state,catalog));
  26  |   if(collapse && await page.locator('#battle-hud-toggle').isVisible()) {
> 27  |    const before=await snapshot(page);await page.locator('#battle-hud-toggle').click();expect(await snapshot(page)).toEqual(before);
      |                                                                                                                    ^ Error: expect(received).toEqual(expected) // deep equality
  28  |   }
  29  |  }
  30  |  await expect(page.locator('#run-screen')).toBeVisible();
  31  | }
  32  | async function prepare(page:Page){
  33  |  const current=await snapshot(page),offer=current.items.offer!;
  34  |  const choice=offer.options.find(o=>o.itemId==='item:healing_draught')??offer.options[0];
  35  |  await page.getByRole('button',{name:`Claim ${runContext.items[choice.itemId].label}`,exact:true}).click();await page.locator('#item-confirm').click();
  36  |  await expect(page.locator('#run-start-encounter')).toBeVisible();
  37  |  for(const equipment of (await snapshot(page)).items.ownership.equipment){
  38  |   const now=await snapshot(page);if(now.items.ownership.assignments.some(a=>a.instanceId===equipment.instanceId))continue;
  39  |   const def=runContext.items[equipment.itemId];const hero=now.items.run.party.find(h=>h.hp>0 && def.eligibleHeroes.includes(h.heroId));
  40  |   if(hero){await page.locator(`[id="target-${equipment.instanceId}"]`).selectOption(hero.heroId);await page.getByRole('button',{name:`Equip ${def.label}`,exact:true}).click();await page.locator('#item-confirm').click();}
  41  |  }
  42  |  for(const hero of (await snapshot(page)).items.run.party){
  43  |   const now=await snapshot(page);if(hero.hp===0 || hero.hp===runContext.catalog.heroes[hero.heroId].stats.maxHp || !now.items.ownership.consumables.length)continue;
  44  |   await page.locator('[id="target-item:healing_draught"]').selectOption(hero.heroId);
  45  |   await page.getByRole('button',{name:'Use Healing Draught',exact:true}).click();await page.locator('#item-confirm').click();
  46  |  }
  47  | }
  48  | test('legal three encounter run, rewards, preparation, final resume and fresh restart',async({page})=>{
  49  |  test.setTimeout(300000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await start(page);await page.locator('#battle-sound').click();const records=[];
  50  |  for(let index=0;index<3;index++){
  51  |   await fight(page,false,true);if(index===0)await page.screenshot({path:test.info().outputPath('run-reward.png')});const current=await snapshot(page);expect(current.items.run.phase).toBe(index===2?'victory':'reward');expect(current.items.run.encounterIndex).toBe(index);
  52  |   const record=JSON.parse((await page.locator('#game').getAttribute('data-run-battle-record'))!);const replay=replayRunBattle(record.replay,record.entry,runContext);expect(replay.ok).toBe(true);if(replay.ok){expect(replay.state).toEqual(record.state);expect(replay.events).toEqual(record.events);}records.push(record);
  53  |   if(index<2){
  54  |    // The pending offer and claimed/prepared boundary survive the real Continue path.
  55  |    if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(current);}
  56  |    await prepare(page);const prepared=await snapshot(page);if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(prepared);}
  57  |    await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  58  |    if(await page.locator('#battle-hud-toggle').isVisible()){
  59  |     await expect(page.locator('#battle-hud-toggle')).toHaveAttribute('aria-expanded',index===0?'false':'true');
  60  |     if(index===0)await page.locator('#battle-hud-toggle').click();
  61  |    }
  62  |    await expect(page.locator('#battle-sound')).toHaveAttribute('aria-pressed',index===0?'true':'false');
  63  |   }
  64  |  }
  65  |  const final=await snapshot(page);await expect(page.getByRole('heading',{name:'Run victory',exact:true})).toBeVisible();
  66  |  await page.screenshot({path:test.info().outputPath('run-victory.png')});
  67  |  writeFileSync(test.info().outputPath('run-records.json'),JSON.stringify(records,null,2));
  68  |  await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(final);
  69  |  await page.locator('#run-new').dblclick();const fresh=await snapshot(page);expect(fresh.items.run.seed).toBe(14);expect(fresh.items.run.id).not.toBe(final.items.run.id);expect(fresh.items.ownership).toEqual({consumables:[],equipment:[],assignments:[]});expect(fresh.items.run.party.every(h=>h.hp===runContext.catalog.heroes[h.heroId].stats.maxHp)).toBe(true);
  70  |  expect(errors).toEqual([]);
  71  | });
  72  | test('legal defeat reload, native keyboard restart and isolated single-battle save',async({page})=>{
  73  |  test.setTimeout(180000);await start(page);await fight(page,true);await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  74  |  const ended=await snapshot(page);await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(ended);
  75  |  await page.locator('#run-new').focus();await page.keyboard.press('Enter');await expect(page.locator('#run-start-encounter')).toBeVisible();
  76  |  await page.getByRole('link',{name:'Single battle',exact:true}).click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  77  |  const run=await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary);expect(JSON.parse(run!).payload.items.run.encounterIndex).toBe(0);
  78  |  await page.getByRole('link',{name:'Play three-encounter run'}).click();await page.locator('#run-continue').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  79  | });
  80  | test('accepted player presentation reload preserves exact boundary without old cues',async({page})=>{
  81  |  await start(page);await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
  82  |  await page.clock.install();await page.clock.pauseAt(new Date(Date.now()+1000));await page.locator('#dialog-confirm').click({force:true});
  83  |  await expect(page.locator('#game')).toHaveAttribute('data-phase','presenting');const committed=await snapshot(page);
  84  |  await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  85  |  expect((await readSession(page)).state).toEqual(committed.activeBattle);expect((await readSession(page)).events).toEqual([]);expect(await page.evaluate(()=>window.fitDiagnostics().battleAudio?.lastToken)).toBe(0);
  86  | });
  87  | test('enemy presentation reload resumes the same commands and RNG as an uninterrupted run',async({page,browser,baseURL})=>{
  88  |  const other=await browser.newContext({viewport:page.viewportSize(),baseURL});const control=await other.newPage();
  89  |  try {
  90  |   for(const p of [page,control]){
  91  |    await p.clock.install();await start(p);await p.clock.pauseAt(await p.evaluate(()=>Date.now()+1000));
  92  |    for(let i=0;i<100;i++){
  93  |     const s=await readSession(p),last=s.replay?.commands.at(-1);
  94  |     if(s.phase==='presenting' && last && s.state.units.find(u=>u.id===last.unitId)!.side==='enemy')break;
  95  |     if(s.phase==='player')await p.locator('#battle-next').click({force:true});
  96  |     await p.clock.runFor(32);
  97  |    }
  98  |   }
  99  |   const boundary=await readSession(page);expect(boundary.phase).toBe('presenting');const last=boundary.replay!.commands.at(-1)!;expect(boundary.state.units.find(u=>u.id===last.unitId)!.side).toBe('enemy');
  100 |   expect((await readSession(control)).state).toEqual(boundary.state);
  101 |   await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await control.clock.resume();
  102 |   for(const p of [page,control])await expect(p.locator('#game')).toHaveAttribute('data-phase','player');
  103 |   const resumed=await readSession(page),uninterrupted=await readSession(control);expect(resumed.state).toEqual(uninterrupted.state);
  104 |   const catalog=runBattleCatalog((await snapshot(page)).items,runContext)!;const command=playerDecision(resumed.state,catalog);
  105 |   for(const p of [page,control]){await playCommand(p,command);await expect(p.locator('#game')).toHaveAttribute('data-phase','player');}
  106 |   expect((await readSession(page)).state).toEqual((await readSession(control)).state);
  107 |  }finally{await other.close();}
  108 | });
  109 | test('run startup preserves corrupt bytes, recovery captures input, and unavailable storage permits unsaved play',async({page})=>{
  110 |  await page.goto('/run');await page.evaluate(key=>localStorage.setItem(key,'{bad'),RUN_STORAGE_KEYS.primary);await page.reload();
  111 |  expect(await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary)).toBe('{bad');
  112 |  await page.locator('#run-recovery').click();await expect(page.getByRole('dialog')).toContainText('primary: invalid');
  113 |  const visited=new Set<string>();
  114 |  for(const key of ['Tab','Shift+Tab'])for(let i=0;i<8;i++){
  115 |   await page.keyboard.press(key);expect(await page.evaluate(()=>!!document.activeElement?.closest('dialog'))).toBe(true);
  116 |   visited.add(await page.evaluate(()=>document.activeElement!.id));
  117 |  }
  118 |  for(const id of await page.getByRole('dialog').getByRole('button').evaluateAll(buttons=>buttons.map(b=>b.id)))expect(visited.has(id)).toBe(true);
  119 |  await page.locator('#run-close-recovery').click();await page.locator('#run-start').click();await page.locator('#run-confirm-new').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  120 |  await page.reload();await page.addInitScript(()=>{Object.defineProperty(window,'localStorage',{get(){throw new DOMException('denied','SecurityError');}});});await page.reload();
  121 |  await page.locator('#run-unsaved').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-persistence')).toContainText('unsaved');
  122 | });
  123 | test('run preparation and dialogs retain 44px controls, native touch and narrow layout',async({page},info)=>{
  124 |  await page.goto('/run');const activate=async(selector:string)=>{if(info.project.use.hasTouch)await page.locator(selector).tap();else await page.locator(selector).click();};
  125 |  await activate('#run-start');await expect(page.locator('#run-start-encounter')).toBeVisible();
  126 |  for(const viewport of [{width:320,height:568},{width:915,height:412},{width:412,height:915}]){
  127 |   await page.setViewportSize(viewport);
```
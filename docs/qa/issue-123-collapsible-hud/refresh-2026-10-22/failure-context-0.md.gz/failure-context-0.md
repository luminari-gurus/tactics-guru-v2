# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-hud-collapse.spec.ts >> opt-in input report captures landscape touches locally
- Location: tests/battle-hud-collapse.spec.ts:133:2

# Error details

```
Error: touchscreen.tap: hasTouch must be enabled on the browser context before using the touchscreen.
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Battle controls" [ref=e8]:
      - button "Hide battle controls" [expanded] [ref=e9] [cursor=pointer]: Hide HUD
      - generic [ref=e10]:
        - generic "Acting unit information; scroll for details" [ref=e11]:
          - paragraph [ref=e12]: Round 1 · Your turn
          - generic [ref=e13]:
            - img "Mage portrait" [ref=e15]
            - generic [ref=e16]:
              - heading "Mage" [level=2] [ref=e17]
              - paragraph [ref=e18]: HP 11/11
              - paragraph [ref=e21]: AC 11 · Accuracy +3
              - paragraph [ref=e22]: No status effects
          - paragraph [ref=e23]: Move ready / Action ready
        - generic "Actions, target and secondary tools; scroll for more" [ref=e24]:
          - generic [ref=e25]:
            - paragraph [ref=e26]: Choose your action
            - generic "Acting unit actions" [ref=e27]:
              - button "Move" [pressed] [ref=e28] [cursor=pointer]:
                - strong [ref=e29]: Move
                - generic [ref=e30]: Uses movement
              - button "Basic attack" [ref=e31] [cursor=pointer]:
                - strong [ref=e32]: Basic attack
                - generic [ref=e33]: Uses action
              - button "Magic Missile" [ref=e34] [cursor=pointer]:
                - strong [ref=e35]: Magic Missile
                - generic [ref=e36]: Uses action
              - button "Wait / End turn" [ref=e37] [cursor=pointer]:
                - strong [ref=e38]: Wait / End turn
                - generic [ref=e39]: Ends turn immediately
            - text: Ability
            - combobox "Ability" [ref=e40]:
              - option "Magic Missile" [selected]
            - paragraph [ref=e41]: Range 1–5 · Living target, including allies · automatic force damage · uses action
            - paragraph [ref=e42]: Choose an action, then a target. Wait ends the turn immediately.
            - region "Target and action preview" [ref=e43]:
              - generic [ref=e44]: Target / destination
              - combobox "Target / destination" [ref=e45]:
                - option "Choose target" [selected]
                - option "(0, 9) · cost 1"
                - option "(1, 10) · cost 1"
                - option "(0, 8) · cost 2"
                - option "(2, 9) · cost 2"
                - option "(0, 10) · cost 2"
                - option "(1, 11) · cost 2"
                - option "(0, 7) · cost 3"
                - option "(3, 9) · cost 3"
                - option "(2, 10) · cost 3"
                - option "(0, 11) · cost 3"
                - option "(2, 11) · cost 3"
                - option "(0, 6) · cost 4"
                - option "(1, 7) · cost 4"
                - option "(3, 8) · cost 4"
                - option "(4, 9) · cost 4"
                - option "(3, 10) · cost 4"
                - option "(3, 11) · cost 4"
              - paragraph [ref=e46]: Select a tile
              - paragraph
              - paragraph [ref=e47]: Select a destination
              - generic [ref=e48]:
                - button "Review action" [disabled] [ref=e49]
                - button "Cancel action" [ref=e50] [cursor=pointer]
            - navigation "Secondary battle tools" [ref=e51]:
              - button "Inspect party" [ref=e52] [cursor=pointer]
              - button "Battle log" [ref=e53] [cursor=pointer]
              - button "Enable sound" [ref=e54] [cursor=pointer]
            - paragraph [ref=e55]: Sound off
          - generic [ref=e56]:
            - status [ref=e57]: Battle ready
            - button "Restart battle" [ref=e58] [cursor=pointer]
          - generic [ref=e59]:
            - generic [ref=e60]: Battle saved on this device
            - button "Save recovery" [ref=e61] [cursor=pointer]
          - paragraph [ref=e62]: "Gold: active · White: selected · Teal: reachable · Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
          - link "Play three-encounter run" [ref=e63] [cursor=pointer]:
            - /url: /run
          - group [ref=e64]:
            - generic "Privacy & analytics" [ref=e65] [cursor=pointer]
  - group [ref=e66]:
    - generic "Input report" [ref=e67] [cursor=pointer]
```

# Test source

```ts
  38  |     }
  39  |     await page.locator('#battle-review').focus();await page.keyboard.press('Enter');
  40  |     await expect(page.getByRole('dialog')).toBeVisible();
  41  |     // Native modal capture blocks the toggle while reviewing.
  42  |     await page.keyboard.press('Tab');expect(await page.evaluate(()=>!!document.activeElement?.closest('dialog'))).toBe(true);
  43  |     await page.locator('#dialog-cancel').click();
  44  |     await activate(page);await page.screenshot({path:info.outputPath(`collapsed-${width}x${height}.png`)});
  45  |     const collapsed=await settled(page);
  46  |     const cell=collapsed.tiles.find((tile:any)=>{
  47  |       const p=projectTile(tile),x=collapsed.transform.x+p.x*collapsed.transform.scale,y=collapsed.transform.y+p.y*collapsed.transform.scale;
  48  |       return x>collapsed.region.x+20&&x<collapsed.region.x+collapsed.region.width-20&&y>collapsed.region.y+20&&y<collapsed.region.y+collapsed.region.height-20;
  49  |     });
  50  |     expect(cell).toBeTruthy();const p=projectTile(cell),x=collapsed.transform.x+p.x*collapsed.transform.scale,y=collapsed.transform.y+p.y*collapsed.transform.scale;
  51  |     if(info.project.use.hasTouch)await page.touchscreen.tap(x,y);else await page.mouse.click(x,y);
  52  |     const picked=await settled(page);expect(picked.selectionEvents).toBe(collapsed.selectionEvents+1);
  53  |     expect(picked.selected).toEqual({x:cell.x,y:cell.y,elevation:cell.elevation});
  54  |     expect((await readSession(page)).state).toEqual(JSON.parse(before!).state);
  55  |     await page.setViewportSize({width:1280,height:720});await expect(toggle).toBeHidden();await expect(page.locator('#battle-hud-contents')).toBeVisible();
  56  |     await page.setViewportSize({width:height,height:width});await expect(toggle).toHaveAttribute('aria-expanded','false');
  57  |     await page.setViewportSize({width:1280,height:720});await expect(page.locator('#battle-hud-contents')).toBeVisible();
  58  |     await page.locator('#fit-restart').click();await confirmRestart(page);await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  59  |     await page.setViewportSize({width:height,height:width});await expect(toggle).toHaveAttribute('aria-expanded','false');
  60  |     await page.reload();await expect(toggle).toHaveAttribute('aria-expanded','true');
  61  |     expect(errors).toEqual([]);
  62  |   });
  63  | }
  64  | 
  65  | test('collapsed camera navigation, stale gestures and presentation remain safe',async({page})=>{
  66  |   await page.setViewportSize({width:915,height:412});await page.goto('/');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  67  |   await activate(page);const initial=await settled(page),r=initial.region;
  68  |   await page.mouse.move(r.x+r.width/2,r.y+r.height/2);await page.mouse.wheel(0,-180);
  69  |   const zoomed=await settled(page);expect(zoomed.transform.scale).toBeGreaterThan(initial.transform.scale);
  70  |   await page.mouse.down();await page.mouse.move(r.x+r.width/2+25,r.y+r.height/2+10,{steps:4});await page.mouse.up();
  71  |   const panned=await settled(page);const count=(await readSession(page)).state.commandCount;
  72  |   await activate(page);await activate(page);const restored=await settled(page);
  73  |   expect(restored.transform.scale).toBeCloseTo(panned.transform.scale,5);expect(restored.selectionEvents).toBe(panned.selectionEvents);
  74  |   // Resize resets an in-flight pointer before its release can select a tile.
  75  |   await page.mouse.move(r.x+r.width/2,r.y+r.height/2);await page.mouse.down();await page.setViewportSize({width:844,height:390});await settled(page);await page.mouse.up();
  76  |   expect((await settled(page)).selectionEvents).toBe(restored.selectionEvents);expect((await readSession(page)).state.commandCount).toBe(count);
  77  |   await activate(page);await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
  78  |   await page.clock.install();await page.clock.pauseAt(new Date(Date.now()+1000));await page.locator('#dialog-confirm').click({force:true});
  79  |   await expect(page.locator('#game')).toHaveAttribute('data-phase','presenting');
  80  |   await page.locator('#battle-hud-toggle').click({force:true});await page.locator('#battle-hud-toggle').click({force:true});
  81  |   await expect(page.locator('#battle-next')).toBeDisabled();expect((await readSession(page)).state.commandCount).toBe(count+1);
  82  |   await page.clock.resume();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  83  | });
  84  | 
  85  | test('collapsed runtime errors remain reachable and recovery modal returns to visible toggle',async({page})=>{
  86  |   await page.setViewportSize({width:390,height:844});await page.goto('/');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  87  |   await activate(page);await page.evaluate(()=>window.dispatchEvent(new ErrorEvent('error',{message:'controlled HUD acceptance error'})));
  88  |   await activate(page);await expect(page.locator('#fit-status')).toContainText('Error:');
  89  |   await page.reload();await page.locator('#save-continue').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  90  |   await activate(page);await page.setViewportSize({width:1280,height:720});
  91  |   await expect(page.locator('#battle-hud-contents')).toBeVisible();
  92  |   await page.locator('#fit-restart').focus();await page.keyboard.press('Enter');await expect(page.getByRole('dialog')).toBeVisible();
  93  |   await page.setViewportSize({width:390,height:844});
  94  |   await page.locator('#save-cancel-reset').click();await expect(page.locator('#battle-hud-toggle')).toBeFocused();
  95  |   await expect(page.locator('#battle-hud-contents')).toBeHidden();
  96  | });
  97  | 
  98  | for(const route of ['/', '/run', '/dungeon'])for(const collapsed of [false,true]) {
  99  |   test(`touch contact stream supports landscape pinch and pan ${route} collapsed=${collapsed}`,async({page})=>{
  100 |     await page.setViewportSize({width:915,height:412});await page.goto(route);
  101 |     if(route==='/run'){await page.locator('#run-start').click();await page.locator('#run-start-encounter').click();}
  102 |     if(route==='/dungeon'){
  103 |       await page.getByRole('button',{name:'Start new dungeon',exact:true}).click();
  104 |       await page.locator('#dungeon-confirm-new').click();await walkDungeon(page);
  105 |     }
  106 |     await expect(page.locator('#game')).toHaveAttribute('data-phase','player');if(collapsed)await activate(page);
  107 |     const initial=await settled(page),r=initial.region,x=r.x+r.width/2,y=r.y+r.height/2;
  108 |     const contact=(identifier:number,x:number)=>({identifier,clientX:x,clientY:y});
  109 |     const touch=async(type:string,changed:ReturnType<typeof contact>[],active=changed)=>page.evaluate(({type,changed,active})=>{
  110 |       const canvas=document.querySelector('canvas')!;
  111 |       // WebKit exposes Touch but prohibits constructing it. Inject contact records
  112 |       // through DOM listeners; native Chromium multitouch is tested separately.
  113 |       const make=(p:{identifier:number;clientX:number;clientY:number})=>({...p,target:canvas,pageX:p.clientX,pageY:p.clientY,screenX:p.clientX,screenY:p.clientY});
  114 |       const event=Object.assign(new Event(type,{bubbles:true,cancelable:true}),{changedTouches:changed.map(make),touches:active.map(make),targetTouches:active.map(make)});
  115 |       canvas.dispatchEvent(event);
  116 |     },{type,changed,active});
  117 |     await touch('touchstart',[contact(1,x-30),contact(2,x+30)]);
  118 |     // Compatibility pointer events must not add a third contact or reset touches.
  119 |     await page.locator('canvas').dispatchEvent('pointerdown',{pointerType:'touch',pointerId:700,button:0,clientX:x-30,clientY:y});
  120 |     await page.locator('canvas').dispatchEvent('pointercancel',{pointerType:'touch',pointerId:700,clientX:0,clientY:0});
  121 |     await touch('touchmove',[contact(1,x-60),contact(2,x+60)]);
  122 |     const zoomed=await settled(page);expect(zoomed.transform.scale).toBeCloseTo(initial.transform.scale*2,6);
  123 |     await touch('touchend',[contact(2,x+60)],[contact(1,x-60)]);
  124 |     await touch('touchmove',[contact(1,x-30)]);
  125 |     const panned=await settled(page);expect(panned.transform.scale).toBeCloseTo(zoomed.transform.scale,6);expect(panned.transform.x).toBeCloseTo(zoomed.transform.x+30,6);
  126 |     await touch('touchcancel',[contact(1,x-30)],[]);
  127 |     await touch('touchmove',[contact(1,x)],[]);
  128 |     const cancelled=await settled(page);expect(cancelled.transform).toEqual(panned.transform);
  129 |     expect(cancelled.selectionEvents).toBe(initial.selectionEvents);expect(cancelled.commandCount).toBe(initial.commandCount);
  130 |   });
  131 | }
  132 | 
  133 |  test('opt-in input report captures landscape touches locally',async({page})=>{
  134 |   await page.setViewportSize({width:844,height:390});
  135 |   await page.goto('/?input-debug=1');
  136 |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  137 |   const region=(await page.locator('#battle-board-region').boundingBox())!;
> 138 |   await page.touchscreen.tap(region.x+region.width/2,region.y+region.height/2);
      |                          ^ Error: touchscreen.tap: hasTouch must be enabled on the browser context before using the touchscreen.
  139 |   await page.getByText('Input report',{exact:true}).click();
  140 |   await page.getByRole('button',{name:'Capture / copy report'}).click();
  141 |   const report=JSON.parse(await page.getByRole('textbox',{name:'Input diagnostic report'}).inputValue());
  142 |   expect(report.counts.touchstart).toBeGreaterThan(0);
  143 |   expect(report.counts['accepted-start']).toBeGreaterThan(0);
  144 |   expect(report.build.commit).toBeTruthy();
  145 |   await page.goto('/');
  146 |   await expect(page.getByText('Input report',{exact:true})).toHaveCount(0);
  147 | });
  148 | 
```
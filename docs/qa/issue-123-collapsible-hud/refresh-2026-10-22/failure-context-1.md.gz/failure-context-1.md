# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-progression.spec.ts >> legal run outcomes, earned rewards, terminal resume and fresh restart
- Location: tests/run-progression.spec.ts:50:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

Expected: {"elevation": 0, "x": 11, "y": 11}
Received: null
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Encounter 2 of 3 · woodland crossing" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Run battle controls" [ref=e8]:
      - button "Hide battle controls" [expanded] [ref=e9] [cursor=pointer]: Hide HUD
      - generic [ref=e10]:
        - generic "Acting unit information; scroll for details" [active] [ref=e11]:
          - paragraph [ref=e12]: Round 1 · Your turn
          - generic [ref=e13]:
            - img "Mage portrait" [ref=e15]
            - generic [ref=e16]:
              - heading "Mage" [level=2] [ref=e17]
              - paragraph [ref=e18]: HP 3/11
              - paragraph [ref=e21]: AC 11 · Accuracy +3
              - paragraph [ref=e22]: No status effects
          - paragraph [ref=e23]: Move ready / Action ready
        - generic "Actions, target and secondary tools; scroll for more" [ref=e24]:
          - generic [ref=e25]:
            - paragraph [ref=e26]: Choose your action
            - generic "Acting unit actions" [ref=e27]:
              - button "Move" [pressed] [ref=e28] [cursor=pointer]:
                - strong [ref=e29]: Move
                - generic [ref=e30]: Uses movement
              - button "Basic attack" [ref=e31] [cursor=pointer]:
                - strong [ref=e32]: Basic attack
                - generic [ref=e33]: Uses action
              - button "Magic Missile" [ref=e34] [cursor=pointer]:
                - strong [ref=e35]: Magic Missile
                - generic [ref=e36]: Uses action
              - button "Wait / End turn" [ref=e37] [cursor=pointer]:
                - strong [ref=e38]: Wait / End turn
                - generic [ref=e39]: Ends turn immediately
            - text: Ability
            - combobox "Ability" [ref=e40]:
              - option "Magic Missile" [selected]
            - paragraph [ref=e41]: Range 1–5 · Living target, including allies · automatic force damage · uses action
            - paragraph [ref=e42]: Choose an action, then a target. Wait ends the turn immediately.
            - region "Target and action preview" [ref=e43]:
              - generic [ref=e44]: Target / destination
              - combobox "Target / destination" [ref=e45]:
                - option "Choose target" [selected]
                - option "(7, 9) · cost 1"
                - option "(6, 10) · cost 1"
                - option "(8, 10) · cost 1"
                - option "(7, 11) · cost 1"
                - option "(7, 8) · cost 2"
                - option "(6, 9) · cost 2"
                - option "(8, 9) · cost 2"
                - option "(9, 10) · cost 2"
                - option "(6, 11) · cost 2"
                - option "(8, 11) · cost 2"
                - option "(7, 7) · cost 3"
                - option "(6, 8) · cost 3"
                - option "(8, 8) · cost 3"
                - option "(5, 9) · cost 3"
                - option "(9, 9) · cost 3"
                - option "(10, 10) · cost 3"
                - option "(5, 11) · cost 3"
                - option "(9, 11) · cost 3"
                - option "(7, 6) · cost 4"
                - option "(6, 7) · cost 4"
                - option "(8, 7) · cost 4"
                - option "(5, 8) · cost 4"
                - option "(9, 8) · cost 4"
                - option "(4, 9) · cost 4"
                - option "(10, 9) · cost 4"
                - option "(11, 10) · cost 4"
                - option "(4, 11) · cost 4"
                - option "(10, 11) · cost 4"
              - paragraph [ref=e46]: Select a tile
              - paragraph
              - paragraph [ref=e47]: Select a destination
              - generic [ref=e48]:
                - button "Review action" [disabled] [ref=e49]
                - button "Cancel action" [ref=e50] [cursor=pointer]
            - navigation "Secondary battle tools" [ref=e51]:
              - button "Inspect party" [ref=e52] [cursor=pointer]
              - button "Battle log" [ref=e53] [cursor=pointer]
              - button "Mute" [pressed] [ref=e54] [cursor=pointer]
            - paragraph [ref=e55]: Sound on
          - paragraph [ref=e56]: Encounter 2 of 3 · woodland crossing
          - generic [ref=e57]:
            - status [ref=e58]: Battle ready
            - button "Start new run" [ref=e59] [cursor=pointer]
          - generic [ref=e60]:
            - button "Save recovery" [ref=e61] [cursor=pointer]
            - generic [ref=e62]: Run saved on this device
          - paragraph [ref=e63]: "Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
          - link "Single battle" [ref=e64] [cursor=pointer]:
            - /url: /
          - link "Dungeon floors" [ref=e65] [cursor=pointer]:
            - /url: /dungeon
          - group [ref=e66]:
            - generic "Privacy & analytics" [ref=e67] [cursor=pointer]
```

# Test source

```ts
  1   | import {expect,test,type Page} from '@playwright/test';
  2   | import {readFileSync,writeFileSync} from 'node:fs';
  3   | import {readSession,playCommand} from './helpers/battlePolicy';
  4   | import {playerDecision} from './helpers/playerPolicy';
  5   | import {runContext} from './helpers/runItemFixtures';
  6   | import {runBattleCatalog,type RunSnapshot} from '../src/domain/runSaveEnvelope';
  7   | import {replayRunBattle} from '../src/domain/runBattle';
  8   | // Exercise actual BFCache rather than Playwright's default disabled cache.
  9   | test.use({launchOptions:{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE,ignoreDefaultArgs:['--disable-back-forward-cache']}});
  10  | import {RUN_STORAGE_KEYS} from '../src/persistence/runStorage';
  11  | async function snapshot(page:Page):Promise<RunSnapshot>{return JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);}
  12  | async function start(page:Page){
  13  |  await page.goto('/run');await page.locator('#run-start').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  14  |  await expect(page.locator('#battle-actor')).toBeVisible();
  15  |  const drawable=await page.locator('#battle-board-region').boundingBox();
  16  |  expect(drawable!.width).toBeGreaterThan(0);
  17  |  expect(drawable!.height).toBeGreaterThanOrEqual(page.viewportSize()!.height*0.3-1);
  18  | }
  19  | async function ready(page:Page){await expect.poll(async()=>await page.locator('#game').getAttribute('data-phase')??'boundary',{timeout:15000}).toMatch(/player|ended|boundary/);}
  20  | async function fight(page:Page,wait=false,collapse=false){
  21  |  for(let i=0;i<500;i++){
  22  |   await ready(page);const current=await snapshot(page);if(current.items.run.phase!=='battle')break;
  23  |   if(collapse && await page.locator('#battle-hud-toggle').isVisible() && await page.locator('#battle-hud-toggle').getAttribute('aria-expanded')==='false')await page.locator('#battle-hud-toggle').click();
  24  |   const battle=await readSession(page);expect(battle.phase).toBe('player');const catalog=runBattleCatalog(current.items,runContext)!;
  25  |   await playCommand(page,wait?{type:'endTurn',unitId:battle.state.initiative[battle.state.activeIndex]}:playerDecision(battle.state,catalog));
  26  |   if(collapse && await page.locator('#battle-hud-toggle').isVisible()) {
  27  |    // Enemy presentations continue while the toggle is used; final replay/state
  28  |    // equivalence below verifies the run without assuming time stopped here.
  29  |    await page.locator('#battle-hud-toggle').click();
  30  |   }
  31  |  }
  32  |  await expect(page.locator('#run-screen')).toBeVisible();
  33  | }
  34  | async function prepare(page:Page){
  35  |  const current=await snapshot(page),offer=current.items.offer!;
  36  |  const choice=offer.options.find(o=>o.itemId==='item:healing_draught')??offer.options[0];
  37  |  await page.getByRole('button',{name:`Claim ${runContext.items[choice.itemId].label}`,exact:true}).click();await page.locator('#item-confirm').click();
  38  |  await expect(page.locator('#run-start-encounter')).toBeVisible();
  39  |  for(const equipment of (await snapshot(page)).items.ownership.equipment){
  40  |   const now=await snapshot(page);if(now.items.ownership.assignments.some(a=>a.instanceId===equipment.instanceId))continue;
  41  |   const def=runContext.items[equipment.itemId];const hero=now.items.run.party.find(h=>h.hp>0 && def.eligibleHeroes.includes(h.heroId));
  42  |   if(hero){await page.locator(`[id="target-${equipment.instanceId}"]`).selectOption(hero.heroId);await page.getByRole('button',{name:`Equip ${def.label}`,exact:true}).click();await page.locator('#item-confirm').click();}
  43  |  }
  44  |  for(const hero of (await snapshot(page)).items.run.party){
  45  |   const now=await snapshot(page);if(hero.hp===0 || hero.hp===runContext.catalog.heroes[hero.heroId].stats.maxHp || !now.items.ownership.consumables.length)continue;
  46  |   await page.locator('[id="target-item:healing_draught"]').selectOption(hero.heroId);
  47  |   await page.getByRole('button',{name:'Use Healing Draught',exact:true}).click();await page.locator('#item-confirm').click();
  48  |  }
  49  | }
  50  | test('legal run outcomes, earned rewards, terminal resume and fresh restart',async({page})=>{
  51  |  test.setTimeout(300000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await start(page);await page.locator('#battle-sound').click();const records=[];
  52  |  for(let index=0;index<3;index++){
  53  |   // Each encounter constructs a fresh shared renderer; prior selections cannot leak.
  54  |   const board=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  55  |   expect(board.selected).toBeNull();expect(board.selectionEvents).toBe(0);
  56  |   await expect(page.locator('#battle-move')).toHaveAttribute('aria-pressed','true');
  57  |   await expect(page.locator('#battle-target')).toHaveValue('');await expect(page.locator('#battle-review')).toBeDisabled();
  58  |   const runBefore=await snapshot(page);
  59  |   const corner=board.tiles.find((t:{x:number;y:number})=>t.x===11&&t.y===11);
  60  |   const x=(corner.x-corner.y)*40,y=(corner.x+corner.y)*20-corner.elevation*24;
  61  |   await page.mouse.click(board.transform.x+x*board.transform.scale,board.transform.y+y*board.transform.scale);
> 62  |   expect(JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!).selected).toEqual({x:11,y:11,elevation:corner.elevation});
      |                                                                                                  ^ Error: expect(received).toEqual(expected) // deep equality
  63  |   expect(await snapshot(page)).toEqual(runBefore);
  64  |   // Each new scene owns exactly its current actor cue; a finished encounter tears it down.
  65  |   await expect.poll(async()=>{
  66  |    const report=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  67  |    const actor=report.units.find((unit:any)=>unit.id===report.activeId);
  68  |    expect(report.units.filter((unit:any)=>unit.id!==report.activeId).every((unit:any)=>unit.bobOffset===0)).toBe(true);
  69  |    return actor.bobOffset;
  70  |   }).toBeLessThan(-0.2);
  71  |   const beforeBob=await snapshot(page);
  72  |   await page.screenshot({path:test.info().outputPath(`encounter-${index+1}-active-bob.png`)});
  73  |   expect(await snapshot(page)).toEqual(beforeBob);
  74  |   await fight(page,false,true);
  75  |   await expect(page.locator('#game')).not.toHaveAttribute('data-battle-report');if(index===0)await page.screenshot({path:test.info().outputPath('run-reward.png')});const current=await snapshot(page);expect(index===2?['victory','defeat']:['reward','defeat']).toContain(current.items.run.phase);expect(current.items.run.encounterIndex).toBe(index);
  76  |   const record=JSON.parse((await page.locator('#game').getAttribute('data-run-battle-record'))!);const replay=replayRunBattle(record.replay,record.entry,runContext);expect(replay.ok).toBe(true);if(replay.ok){expect(replay.state).toEqual(record.state);expect(replay.events).toEqual(record.events);}records.push(record);
  77  |   if(current.items.run.phase==='defeat')break;
  78  |   if(index<2){
  79  |    // The pending offer and claimed/prepared boundary survive the real Continue path.
  80  |    if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(current);}
  81  |    await prepare(page);const prepared=await snapshot(page);if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(prepared);}
  82  |    await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  83  |    if(await page.locator('#battle-hud-toggle').isVisible()){
  84  |     await expect(page.locator('#battle-hud-toggle')).toHaveAttribute('aria-expanded',index===0?'false':'true');
  85  |     if(index===0)await page.locator('#battle-hud-toggle').click();
  86  |    }
  87  |    await expect(page.locator('#battle-sound')).toHaveAttribute('aria-pressed',index===0?'true':'false');
  88  |   }
  89  |  }
  90  |  const final=await snapshot(page);await expect(page.getByRole('heading',{name:final.items.run.phase==='victory'?'Run victory':'Run defeat',exact:true})).toBeVisible();
  91  |  await page.screenshot({path:test.info().outputPath('run-terminal.png')});
  92  |  writeFileSync(test.info().outputPath('run-records.json'),JSON.stringify(records,null,2));
  93  |  await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(final);
  94  |  await page.locator('#run-new').dblclick();const fresh=await snapshot(page);expect(fresh.items.run.seed).toBe(14);expect(fresh.items.run.id).not.toBe(final.items.run.id);expect(fresh.items.ownership).toEqual({consumables:[],equipment:[],assignments:[]});expect(fresh.items.run.party.every(h=>h.hp===runContext.catalog.heroes[h.heroId].stats.maxHp)).toBe(true);
  95  |  expect(errors).toEqual([]);
  96  | });
  97  | test('legal defeat reload, native keyboard restart and isolated single-battle save',async({page})=>{
  98  |  test.setTimeout(180000);await start(page);await fight(page,true);await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  99  |  const ended=await snapshot(page);await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(ended);
  100 |  await page.locator('#run-new').focus();await page.keyboard.press('Enter');await expect(page.locator('#run-start-encounter')).toBeVisible();
  101 |  await page.getByRole('link',{name:'Single battle',exact:true}).click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  102 |  const run=await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary);expect(JSON.parse(run!).payload.items.run.encounterIndex).toBe(0);
  103 |  await page.getByRole('link',{name:'Play three-encounter run'}).click();await page.locator('#run-continue').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  104 | });
  105 | test('accepted player presentation reload preserves exact boundary without old cues',async({page})=>{
  106 |  await start(page);await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
  107 |  await page.clock.install();await page.clock.pauseAt(new Date(Date.now()+1000));await page.locator('#dialog-confirm').click({force:true});
  108 |  await expect(page.locator('#game')).toHaveAttribute('data-phase','presenting');const committed=await snapshot(page);
  109 |  await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  110 |  expect((await readSession(page)).state).toEqual(committed.activeBattle);expect((await readSession(page)).events).toEqual([]);expect(await page.evaluate(()=>window.fitDiagnostics().battleAudio?.lastToken)).toBe(0);
  111 |  await expect(page.locator('#battle-move')).toBeDisabled();await expect(page.locator('#battle-move')).toHaveAttribute('aria-pressed','false');
  112 | });
  113 | test('enemy presentation reload resumes the same commands and RNG as an uninterrupted run',async({page,browser,baseURL})=>{
  114 |  const other=await browser.newContext({viewport:page.viewportSize(),baseURL});const control=await other.newPage();
  115 |  try {
  116 |   for(const p of [page,control]){
  117 |    await p.clock.install();await start(p);await p.clock.pauseAt(await p.evaluate(()=>Date.now()+1000));
  118 |    for(let i=0;i<100;i++){
  119 |     const s=await readSession(p),last=s.replay?.commands.at(-1);
  120 |     if(s.phase==='presenting' && last && s.state.units.find(u=>u.id===last.unitId)!.side==='enemy')break;
  121 |     if(s.phase==='player')await p.locator('#battle-next').click({force:true});
  122 |     await p.clock.runFor(32);
  123 |    }
  124 |   }
  125 |   const boundary=await readSession(page);expect(boundary.phase).toBe('presenting');const last=boundary.replay!.commands.at(-1)!;expect(boundary.state.units.find(u=>u.id===last.unitId)!.side).toBe('enemy');
  126 |   expect((await readSession(control)).state).toEqual(boundary.state);
  127 |   await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await control.clock.resume();
  128 |   for(const p of [page,control])await expect(p.locator('#game')).toHaveAttribute('data-phase','player');
  129 |   const resumed=await readSession(page),uninterrupted=await readSession(control);expect(resumed.state).toEqual(uninterrupted.state);
  130 |   const catalog=runBattleCatalog((await snapshot(page)).items,runContext)!;const command=playerDecision(resumed.state,catalog);
  131 |   for(const p of [page,control]){await playCommand(p,command);await expect(p.locator('#game')).toHaveAttribute('data-phase','player');}
  132 |   expect((await readSession(page)).state).toEqual((await readSession(control)).state);
  133 |  }finally{await other.close();}
  134 | });
  135 | test('run startup preserves corrupt bytes, recovery captures input, and unavailable storage permits unsaved play',async({page})=>{
  136 |  await page.goto('/run');
  137 |  await expect(page.locator('#run-start')).toBeVisible();
  138 |  expect(await page.evaluate(keys=>keys.map(key=>localStorage.getItem(key)),Object.values(RUN_STORAGE_KEYS))).toEqual([null,null]);
  139 |  expect((await snapshot(page)).activeBattle).toBeNull();
  140 |  await page.evaluate(key=>localStorage.setItem(key,'{bad'),RUN_STORAGE_KEYS.primary);await page.reload();
  141 |  expect(await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary)).toBe('{bad');
  142 |  await page.locator('#run-recovery').click();await expect(page.getByRole('dialog')).toContainText('primary: invalid');
  143 |  const visited=new Set<string>();
  144 |  for(const key of ['Tab','Shift+Tab'])for(let i=0;i<8;i++){
  145 |   await page.keyboard.press(key);expect(await page.evaluate(()=>!!document.activeElement?.closest('dialog'))).toBe(true);
  146 |   visited.add(await page.evaluate(()=>document.activeElement!.id));
  147 |  }
  148 |  for(const id of await page.getByRole('dialog').getByRole('button').evaluateAll(buttons=>buttons.map(b=>b.id)))expect(visited.has(id)).toBe(true);
  149 |  await page.locator('#run-close-recovery').click();await page.locator('#run-start').click();await page.locator('#run-confirm-new').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  150 |  await page.reload();await page.addInitScript(()=>{Object.defineProperty(window,'localStorage',{get(){throw new DOMException('denied','SecurityError');}});});await page.reload();
  151 |  await page.locator('#run-unsaved').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-persistence')).toContainText('unsaved');
  152 | });
  153 | test('run preparation and dialogs retain 44px controls, native touch and narrow layout',async({page},info)=>{
  154 |  await page.goto('/run');const activate=async(selector:string)=>{if(info.project.use.hasTouch)await page.locator(selector).tap();else await page.locator(selector).click();};
  155 |  await activate('#run-start');await expect(page.locator('#run-start-encounter')).toBeVisible();
  156 |  for(const viewport of [{width:320,height:568},{width:915,height:412},{width:412,height:915}]){
  157 |   await page.setViewportSize(viewport);
  158 |   const boxes=await page.locator('#run-screen button,#run-screen a,#run-screen select').evaluateAll(nodes=>nodes.filter(n=>n.getClientRects().length).map(n=>{n.scrollIntoView({block:'nearest'});const r=n.getBoundingClientRect();return{width:r.width,height:r.height,left:r.left,right:r.right};}));
  159 |   for(const box of boxes){expect(box.width).toBeGreaterThanOrEqual(44);expect(box.height).toBeGreaterThanOrEqual(44);expect(box.left).toBeGreaterThanOrEqual(0);expect(box.right).toBeLessThanOrEqual(viewport.width);}
  160 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  161 |  }
  162 |  await activate('#run-start-encounter');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
```
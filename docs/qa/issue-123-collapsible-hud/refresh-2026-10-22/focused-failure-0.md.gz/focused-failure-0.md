# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-progression.spec.ts >> legal run outcomes, earned rewards, terminal resume and fresh restart
- Location: tests/run-progression.spec.ts:50:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

Expected: {"elevation": 0, "x": 11, "y": 11}
Received: null
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Encounter 2 of 3 · woodland crossing" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Run battle controls" [ref=e8]:
      - button "Show battle controls" [active] [ref=e9] [cursor=pointer]: Show HUD
```

# Test source

```ts
  1   | import {expect,test,type Page} from '@playwright/test';
  2   | import {readFileSync,writeFileSync} from 'node:fs';
  3   | import {readSession,playCommand} from './helpers/battlePolicy';
  4   | import {playerDecision} from './helpers/playerPolicy';
  5   | import {runContext} from './helpers/runItemFixtures';
  6   | import {runBattleCatalog,type RunSnapshot} from '../src/domain/runSaveEnvelope';
  7   | import {replayRunBattle} from '../src/domain/runBattle';
  8   | // Exercise actual BFCache rather than Playwright's default disabled cache.
  9   | test.use({launchOptions:{executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE,ignoreDefaultArgs:['--disable-back-forward-cache']}});
  10  | import {RUN_STORAGE_KEYS} from '../src/persistence/runStorage';
  11  | async function snapshot(page:Page):Promise<RunSnapshot>{return JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);}
  12  | async function start(page:Page){
  13  |  await page.goto('/run');await page.locator('#run-start').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  14  |  await expect(page.locator('#battle-actor')).toBeVisible();
  15  |  const drawable=await page.locator('#battle-board-region').boundingBox();
  16  |  expect(drawable!.width).toBeGreaterThan(0);
  17  |  expect(drawable!.height).toBeGreaterThanOrEqual(page.viewportSize()!.height*0.3-1);
  18  | }
  19  | async function ready(page:Page){await expect.poll(async()=>await page.locator('#game').getAttribute('data-phase')??'boundary',{timeout:15000}).toMatch(/player|ended|boundary/);}
  20  | async function fight(page:Page,wait=false,collapse=false){
  21  |  for(let i=0;i<500;i++){
  22  |   await ready(page);const current=await snapshot(page);if(current.items.run.phase!=='battle')break;
  23  |   if(collapse && await page.locator('#battle-hud-toggle').isVisible() && await page.locator('#battle-hud-toggle').getAttribute('aria-expanded')==='false')await page.locator('#battle-hud-toggle').click();
  24  |   const battle=await readSession(page);expect(battle.phase).toBe('player');const catalog=runBattleCatalog(current.items,runContext)!;
  25  |   await playCommand(page,wait?{type:'endTurn',unitId:battle.state.initiative[battle.state.activeIndex]}:playerDecision(battle.state,catalog));
  26  |   if(collapse && await page.locator('#battle-hud-toggle').isVisible()) {
  27  |    // Enemy presentations continue while the toggle is used; final replay/state
  28  |    // equivalence below verifies the run without assuming time stopped here.
  29  |    await page.locator('#battle-hud-toggle').click();
  30  |   }
  31  |  }
  32  |  await expect(page.locator('#run-screen')).toBeVisible();
  33  | }
  34  | async function prepare(page:Page){
  35  |  const current=await snapshot(page),offer=current.items.offer!;
  36  |  const choice=offer.options.find(o=>o.itemId==='item:healing_draught')??offer.options[0];
  37  |  await page.getByRole('button',{name:`Claim ${runContext.items[choice.itemId].label}`,exact:true}).click();await page.locator('#item-confirm').click();
  38  |  await expect(page.locator('#run-start-encounter')).toBeVisible();
  39  |  for(const equipment of (await snapshot(page)).items.ownership.equipment){
  40  |   const now=await snapshot(page);if(now.items.ownership.assignments.some(a=>a.instanceId===equipment.instanceId))continue;
  41  |   const def=runContext.items[equipment.itemId];const hero=now.items.run.party.find(h=>h.hp>0 && def.eligibleHeroes.includes(h.heroId));
  42  |   if(hero){await page.locator(`[id="target-${equipment.instanceId}"]`).selectOption(hero.heroId);await page.getByRole('button',{name:`Equip ${def.label}`,exact:true}).click();await page.locator('#item-confirm').click();}
  43  |  }
  44  |  for(const hero of (await snapshot(page)).items.run.party){
  45  |   const now=await snapshot(page);if(hero.hp===0 || hero.hp===runContext.catalog.heroes[hero.heroId].stats.maxHp || !now.items.ownership.consumables.length)continue;
  46  |   await page.locator('[id="target-item:healing_draught"]').selectOption(hero.heroId);
  47  |   await page.getByRole('button',{name:'Use Healing Draught',exact:true}).click();await page.locator('#item-confirm').click();
  48  |  }
  49  | }
  50  | test('legal run outcomes, earned rewards, terminal resume and fresh restart',async({page})=>{
  51  |  test.setTimeout(300000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await start(page);await page.locator('#battle-sound').click();const records=[];
  52  |  for(let index=0;index<3;index++){
  53  |   // Let the shared ResizeObserver/camera fit settle after restoring the HUD
  54  |   // at an encounter boundary before deriving a pointer coordinate from its report.
  55  |   await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve())))));
  56  |   // Each encounter constructs a fresh shared renderer; prior selections cannot leak.
  57  |   const board=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  58  |   expect(board.selected).toBeNull();expect(board.selectionEvents).toBe(0);
  59  |   await expect(page.locator('#battle-move')).toHaveAttribute('aria-pressed','true');
  60  |   await expect(page.locator('#battle-target')).toHaveValue('');await expect(page.locator('#battle-review')).toBeDisabled();
  61  |   const runBefore=await snapshot(page);
  62  |   const corner=board.tiles.find((t:{x:number;y:number})=>t.x===11&&t.y===11);
  63  |   const x=(corner.x-corner.y)*40,y=(corner.x+corner.y)*20-corner.elevation*24;
  64  |   await page.mouse.click(board.transform.x+x*board.transform.scale,board.transform.y+y*board.transform.scale);
> 65  |   expect(JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!).selected).toEqual({x:11,y:11,elevation:corner.elevation});
      |                                                                                                  ^ Error: expect(received).toEqual(expected) // deep equality
  66  |   expect(await snapshot(page)).toEqual(runBefore);
  67  |   // Each new scene owns exactly its current actor cue; a finished encounter tears it down.
  68  |   await expect.poll(async()=>{
  69  |    const report=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  70  |    const actor=report.units.find((unit:any)=>unit.id===report.activeId);
  71  |    expect(report.units.filter((unit:any)=>unit.id!==report.activeId).every((unit:any)=>unit.bobOffset===0)).toBe(true);
  72  |    return actor.bobOffset;
  73  |   }).toBeLessThan(-0.2);
  74  |   const beforeBob=await snapshot(page);
  75  |   await page.screenshot({path:test.info().outputPath(`encounter-${index+1}-active-bob.png`)});
  76  |   expect(await snapshot(page)).toEqual(beforeBob);
  77  |   await fight(page,false,true);
  78  |   await expect(page.locator('#game')).not.toHaveAttribute('data-battle-report');if(index===0)await page.screenshot({path:test.info().outputPath('run-reward.png')});const current=await snapshot(page);expect(index===2?['victory','defeat']:['reward','defeat']).toContain(current.items.run.phase);expect(current.items.run.encounterIndex).toBe(index);
  79  |   const record=JSON.parse((await page.locator('#game').getAttribute('data-run-battle-record'))!);const replay=replayRunBattle(record.replay,record.entry,runContext);expect(replay.ok).toBe(true);if(replay.ok){expect(replay.state).toEqual(record.state);expect(replay.events).toEqual(record.events);}records.push(record);
  80  |   if(current.items.run.phase==='defeat')break;
  81  |   if(index<2){
  82  |    // The pending offer and claimed/prepared boundary survive the real Continue path.
  83  |    if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(current);}
  84  |    await prepare(page);const prepared=await snapshot(page);if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(prepared);}
  85  |    await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  86  |    if(await page.locator('#battle-hud-toggle').isVisible()){
  87  |     await expect(page.locator('#battle-hud-toggle')).toHaveAttribute('aria-expanded',index===0?'false':'true');
  88  |     if(index===0)await page.locator('#battle-hud-toggle').click();
  89  |    }
  90  |    await expect(page.locator('#battle-sound')).toHaveAttribute('aria-pressed',index===0?'true':'false');
  91  |   }
  92  |  }
  93  |  const final=await snapshot(page);await expect(page.getByRole('heading',{name:final.items.run.phase==='victory'?'Run victory':'Run defeat',exact:true})).toBeVisible();
  94  |  await page.screenshot({path:test.info().outputPath('run-terminal.png')});
  95  |  writeFileSync(test.info().outputPath('run-records.json'),JSON.stringify(records,null,2));
  96  |  await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(final);
  97  |  await page.locator('#run-new').dblclick();const fresh=await snapshot(page);expect(fresh.items.run.seed).toBe(14);expect(fresh.items.run.id).not.toBe(final.items.run.id);expect(fresh.items.ownership).toEqual({consumables:[],equipment:[],assignments:[]});expect(fresh.items.run.party.every(h=>h.hp===runContext.catalog.heroes[h.heroId].stats.maxHp)).toBe(true);
  98  |  expect(errors).toEqual([]);
  99  | });
  100 | test('legal defeat reload, native keyboard restart and isolated single-battle save',async({page})=>{
  101 |  test.setTimeout(180000);await start(page);await fight(page,true);await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  102 |  const ended=await snapshot(page);await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(ended);
  103 |  await page.locator('#run-new').focus();await page.keyboard.press('Enter');await expect(page.locator('#run-start-encounter')).toBeVisible();
  104 |  await page.getByRole('link',{name:'Single battle',exact:true}).click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  105 |  const run=await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary);expect(JSON.parse(run!).payload.items.run.encounterIndex).toBe(0);
  106 |  await page.getByRole('link',{name:'Play three-encounter run'}).click();await page.locator('#run-continue').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  107 | });
  108 | test('accepted player presentation reload preserves exact boundary without old cues',async({page})=>{
  109 |  await start(page);await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
  110 |  await page.clock.install();await page.clock.pauseAt(new Date(Date.now()+1000));await page.locator('#dialog-confirm').click({force:true});
  111 |  await expect(page.locator('#game')).toHaveAttribute('data-phase','presenting');const committed=await snapshot(page);
  112 |  await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  113 |  expect((await readSession(page)).state).toEqual(committed.activeBattle);expect((await readSession(page)).events).toEqual([]);expect(await page.evaluate(()=>window.fitDiagnostics().battleAudio?.lastToken)).toBe(0);
  114 |  await expect(page.locator('#battle-move')).toBeDisabled();await expect(page.locator('#battle-move')).toHaveAttribute('aria-pressed','false');
  115 | });
  116 | test('enemy presentation reload resumes the same commands and RNG as an uninterrupted run',async({page,browser,baseURL})=>{
  117 |  const other=await browser.newContext({viewport:page.viewportSize(),baseURL});const control=await other.newPage();
  118 |  try {
  119 |   for(const p of [page,control]){
  120 |    await p.clock.install();await start(p);await p.clock.pauseAt(await p.evaluate(()=>Date.now()+1000));
  121 |    for(let i=0;i<100;i++){
  122 |     const s=await readSession(p),last=s.replay?.commands.at(-1);
  123 |     if(s.phase==='presenting' && last && s.state.units.find(u=>u.id===last.unitId)!.side==='enemy')break;
  124 |     if(s.phase==='player')await p.locator('#battle-next').click({force:true});
  125 |     await p.clock.runFor(32);
  126 |    }
  127 |   }
  128 |   const boundary=await readSession(page);expect(boundary.phase).toBe('presenting');const last=boundary.replay!.commands.at(-1)!;expect(boundary.state.units.find(u=>u.id===last.unitId)!.side).toBe('enemy');
  129 |   expect((await readSession(control)).state).toEqual(boundary.state);
  130 |   await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await control.clock.resume();
  131 |   for(const p of [page,control])await expect(p.locator('#game')).toHaveAttribute('data-phase','player');
  132 |   const resumed=await readSession(page),uninterrupted=await readSession(control);expect(resumed.state).toEqual(uninterrupted.state);
  133 |   const catalog=runBattleCatalog((await snapshot(page)).items,runContext)!;const command=playerDecision(resumed.state,catalog);
  134 |   for(const p of [page,control]){await playCommand(p,command);await expect(p.locator('#game')).toHaveAttribute('data-phase','player');}
  135 |   expect((await readSession(page)).state).toEqual((await readSession(control)).state);
  136 |  }finally{await other.close();}
  137 | });
  138 | test('run startup preserves corrupt bytes, recovery captures input, and unavailable storage permits unsaved play',async({page})=>{
  139 |  await page.goto('/run');
  140 |  await expect(page.locator('#run-start')).toBeVisible();
  141 |  expect(await page.evaluate(keys=>keys.map(key=>localStorage.getItem(key)),Object.values(RUN_STORAGE_KEYS))).toEqual([null,null]);
  142 |  expect((await snapshot(page)).activeBattle).toBeNull();
  143 |  await page.evaluate(key=>localStorage.setItem(key,'{bad'),RUN_STORAGE_KEYS.primary);await page.reload();
  144 |  expect(await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary)).toBe('{bad');
  145 |  await page.locator('#run-recovery').click();await expect(page.getByRole('dialog')).toContainText('primary: invalid');
  146 |  const visited=new Set<string>();
  147 |  for(const key of ['Tab','Shift+Tab'])for(let i=0;i<8;i++){
  148 |   await page.keyboard.press(key);expect(await page.evaluate(()=>!!document.activeElement?.closest('dialog'))).toBe(true);
  149 |   visited.add(await page.evaluate(()=>document.activeElement!.id));
  150 |  }
  151 |  for(const id of await page.getByRole('dialog').getByRole('button').evaluateAll(buttons=>buttons.map(b=>b.id)))expect(visited.has(id)).toBe(true);
  152 |  await page.locator('#run-close-recovery').click();await page.locator('#run-start').click();await page.locator('#run-confirm-new').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  153 |  await page.reload();await page.addInitScript(()=>{Object.defineProperty(window,'localStorage',{get(){throw new DOMException('denied','SecurityError');}});});await page.reload();
  154 |  await page.locator('#run-unsaved').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-persistence')).toContainText('unsaved');
  155 | });
  156 | test('run preparation and dialogs retain 44px controls, native touch and narrow layout',async({page},info)=>{
  157 |  await page.goto('/run');const activate=async(selector:string)=>{if(info.project.use.hasTouch)await page.locator(selector).tap();else await page.locator(selector).click();};
  158 |  await activate('#run-start');await expect(page.locator('#run-start-encounter')).toBeVisible();
  159 |  for(const viewport of [{width:320,height:568},{width:915,height:412},{width:412,height:915}]){
  160 |   await page.setViewportSize(viewport);
  161 |   const boxes=await page.locator('#run-screen button,#run-screen a,#run-screen select').evaluateAll(nodes=>nodes.filter(n=>n.getClientRects().length).map(n=>{n.scrollIntoView({block:'nearest'});const r=n.getBoundingClientRect();return{width:r.width,height:r.height,left:r.left,right:r.right};}));
  162 |   for(const box of boxes){expect(box.width).toBeGreaterThanOrEqual(44);expect(box.height).toBeGreaterThanOrEqual(44);expect(box.left).toBeGreaterThanOrEqual(0);expect(box.right).toBeLessThanOrEqual(viewport.width);}
  163 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  164 |  }
  165 |  await activate('#run-start-encounter');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
```
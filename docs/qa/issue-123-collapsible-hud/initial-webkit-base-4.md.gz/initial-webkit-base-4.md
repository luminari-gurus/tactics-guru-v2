# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-progression.spec.ts >> run preparation and dialogs retain 44px controls, native touch and narrow layout
- Location: tests/run-progression.spec.ts:115:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('#fit-restart')
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" locator('#fit-restart') with timeout 5000ms
  - waiting for locator('#fit-restart')
    14 × locator resolved to <button type="button" id="fit-restart">Start new run</button>
       - unexpected value "inactive"

```

```yaml
- button "Start new run"
```

# Test source

```ts
  26  |  await expect(page.locator('#run-screen')).toBeVisible();
  27  | }
  28  | async function prepare(page:Page){
  29  |  const current=await snapshot(page),offer=current.items.offer!;
  30  |  const choice=offer.options.find(o=>o.itemId==='item:healing_draught')??offer.options[0];
  31  |  await page.getByRole('button',{name:`Claim ${runContext.items[choice.itemId].label}`,exact:true}).click();await page.locator('#item-confirm').click();
  32  |  await expect(page.locator('#run-start-encounter')).toBeVisible();
  33  |  for(const equipment of (await snapshot(page)).items.ownership.equipment){
  34  |   const now=await snapshot(page);if(now.items.ownership.assignments.some(a=>a.instanceId===equipment.instanceId))continue;
  35  |   const def=runContext.items[equipment.itemId];const hero=now.items.run.party.find(h=>h.hp>0 && def.eligibleHeroes.includes(h.heroId));
  36  |   if(hero){await page.locator(`[id="target-${equipment.instanceId}"]`).selectOption(hero.heroId);await page.getByRole('button',{name:`Equip ${def.label}`,exact:true}).click();await page.locator('#item-confirm').click();}
  37  |  }
  38  |  for(const hero of (await snapshot(page)).items.run.party){
  39  |   const now=await snapshot(page);if(hero.hp===0 || hero.hp===runContext.catalog.heroes[hero.heroId].stats.maxHp || !now.items.ownership.consumables.length)continue;
  40  |   await page.locator('[id="target-item:healing_draught"]').selectOption(hero.heroId);
  41  |   await page.getByRole('button',{name:'Use Healing Draught',exact:true}).click();await page.locator('#item-confirm').click();
  42  |  }
  43  | }
  44  | test('legal three encounter run, rewards, preparation, final resume and fresh restart',async({page})=>{
  45  |  test.setTimeout(300000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await start(page);await page.locator('#battle-sound').click();const records=[];
  46  |  for(let index=0;index<3;index++){
  47  |   await fight(page);if(index===0)await page.screenshot({path:test.info().outputPath('run-reward.png')});const current=await snapshot(page);expect(current.items.run.phase).toBe(index===2?'victory':'reward');expect(current.items.run.encounterIndex).toBe(index);
  48  |   const record=JSON.parse((await page.locator('#game').getAttribute('data-run-battle-record'))!);const replay=replayRunBattle(record.replay,record.entry,runContext);expect(replay.ok).toBe(true);if(replay.ok){expect(replay.state).toEqual(record.state);expect(replay.events).toEqual(record.events);}records.push(record);
  49  |   if(index<2){
  50  |    // The pending offer and claimed/prepared boundary survive the real Continue path.
  51  |    if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(current);}
  52  |    await prepare(page);const prepared=await snapshot(page);if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(prepared);}
  53  |    await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  54  |    await expect(page.locator('#battle-sound')).toHaveAttribute('aria-pressed',index===0?'true':'false');
  55  |   }
  56  |  }
  57  |  const final=await snapshot(page);await expect(page.getByRole('heading',{name:'Run victory',exact:true})).toBeVisible();
  58  |  await page.screenshot({path:test.info().outputPath('run-victory.png')});
  59  |  writeFileSync(test.info().outputPath('run-records.json'),JSON.stringify(records,null,2));
  60  |  await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(final);
  61  |  await page.locator('#run-new').dblclick();const fresh=await snapshot(page);expect(fresh.items.run.seed).toBe(14);expect(fresh.items.run.id).not.toBe(final.items.run.id);expect(fresh.items.ownership).toEqual({consumables:[],equipment:[],assignments:[]});expect(fresh.items.run.party.every(h=>h.hp===runContext.catalog.heroes[h.heroId].stats.maxHp)).toBe(true);
  62  |  expect(errors).toEqual([]);
  63  | });
  64  | test('legal defeat reload, native keyboard restart and isolated single-battle save',async({page})=>{
  65  |  test.setTimeout(180000);await start(page);await fight(page,true);await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  66  |  const ended=await snapshot(page);await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(ended);
  67  |  await page.locator('#run-new').focus();await page.keyboard.press('Enter');await expect(page.locator('#run-start-encounter')).toBeVisible();
  68  |  await page.getByRole('link',{name:'Single battle',exact:true}).click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  69  |  const run=await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary);expect(JSON.parse(run!).payload.items.run.encounterIndex).toBe(0);
  70  |  await page.getByRole('link',{name:'Play three-encounter run'}).click();await page.locator('#run-continue').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  71  | });
  72  | test('accepted player presentation reload preserves exact boundary without old cues',async({page})=>{
  73  |  await start(page);await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
  74  |  await page.clock.install();await page.clock.pauseAt(new Date(Date.now()+1000));await page.locator('#dialog-confirm').click({force:true});
  75  |  await expect(page.locator('#game')).toHaveAttribute('data-phase','presenting');const committed=await snapshot(page);
  76  |  await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  77  |  expect((await readSession(page)).state).toEqual(committed.activeBattle);expect((await readSession(page)).events).toEqual([]);expect(await page.evaluate(()=>window.fitDiagnostics().battleAudio?.lastToken)).toBe(0);
  78  | });
  79  | test('enemy presentation reload resumes the same commands and RNG as an uninterrupted run',async({page,browser,baseURL})=>{
  80  |  const other=await browser.newContext({viewport:page.viewportSize(),baseURL});const control=await other.newPage();
  81  |  try {
  82  |   for(const p of [page,control]){
  83  |    await p.clock.install();await start(p);await p.clock.pauseAt(await p.evaluate(()=>Date.now()+1000));
  84  |    for(let i=0;i<100;i++){
  85  |     const s=await readSession(p),last=s.replay?.commands.at(-1);
  86  |     if(s.phase==='presenting' && last && s.state.units.find(u=>u.id===last.unitId)!.side==='enemy')break;
  87  |     if(s.phase==='player')await p.locator('#battle-next').click({force:true});
  88  |     await p.clock.runFor(32);
  89  |    }
  90  |   }
  91  |   const boundary=await readSession(page);expect(boundary.phase).toBe('presenting');const last=boundary.replay!.commands.at(-1)!;expect(boundary.state.units.find(u=>u.id===last.unitId)!.side).toBe('enemy');
  92  |   expect((await readSession(control)).state).toEqual(boundary.state);
  93  |   await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await control.clock.resume();
  94  |   for(const p of [page,control])await expect(p.locator('#game')).toHaveAttribute('data-phase','player');
  95  |   const resumed=await readSession(page),uninterrupted=await readSession(control);expect(resumed.state).toEqual(uninterrupted.state);
  96  |   const catalog=runBattleCatalog((await snapshot(page)).items,runContext)!;const command=playerDecision(resumed.state,catalog);
  97  |   for(const p of [page,control]){await playCommand(p,command);await expect(p.locator('#game')).toHaveAttribute('data-phase','player');}
  98  |   expect((await readSession(page)).state).toEqual((await readSession(control)).state);
  99  |  }finally{await other.close();}
  100 | });
  101 | test('run startup preserves corrupt bytes, recovery captures input, and unavailable storage permits unsaved play',async({page})=>{
  102 |  await page.goto('/run');await page.evaluate(key=>localStorage.setItem(key,'{bad'),RUN_STORAGE_KEYS.primary);await page.reload();
  103 |  expect(await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary)).toBe('{bad');
  104 |  await page.locator('#run-recovery').click();await expect(page.getByRole('dialog')).toContainText('primary: invalid');
  105 |  const visited=new Set<string>();
  106 |  for(const key of ['Tab','Shift+Tab'])for(let i=0;i<8;i++){
  107 |   await page.keyboard.press(key);expect(await page.evaluate(()=>!!document.activeElement?.closest('dialog'))).toBe(true);
  108 |   visited.add(await page.evaluate(()=>document.activeElement!.id));
  109 |  }
  110 |  for(const id of await page.getByRole('dialog').getByRole('button').evaluateAll(buttons=>buttons.map(b=>b.id)))expect(visited.has(id)).toBe(true);
  111 |  await page.locator('#run-close-recovery').click();await page.locator('#run-start').click();await page.locator('#run-confirm-new').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  112 |  await page.reload();await page.addInitScript(()=>{Object.defineProperty(window,'localStorage',{get(){throw new DOMException('denied','SecurityError');}});});await page.reload();
  113 |  await page.locator('#run-unsaved').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-persistence')).toContainText('unsaved');
  114 | });
  115 | test('run preparation and dialogs retain 44px controls, native touch and narrow layout',async({page},info)=>{
  116 |  await page.goto('/run');const activate=async(selector:string)=>{if(info.project.use.hasTouch)await page.locator(selector).tap();else await page.locator(selector).click();};
  117 |  await activate('#run-start');await expect(page.locator('#run-start-encounter')).toBeVisible();
  118 |  for(const viewport of [{width:320,height:568},{width:915,height:412},{width:412,height:915}]){
  119 |   await page.setViewportSize(viewport);
  120 |   const boxes=await page.locator('#run-screen button,#run-screen a,#run-screen select').evaluateAll(nodes=>nodes.filter(n=>n.getClientRects().length).map(n=>{n.scrollIntoView({block:'nearest'});const r=n.getBoundingClientRect();return{width:r.width,height:r.height,left:r.left,right:r.right};}));
  121 |   for(const box of boxes){expect(box.width).toBeGreaterThanOrEqual(44);expect(box.height).toBeGreaterThanOrEqual(44);expect(box.left).toBeGreaterThanOrEqual(0);expect(box.right).toBeLessThanOrEqual(viewport.width);}
  122 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  123 |  }
  124 |  await activate('#run-start-encounter');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  125 |  await page.locator('#fit-restart').click();await expect(page.getByRole('dialog')).toBeVisible();const before=await snapshot(page);await page.mouse.click(3,3);expect(await snapshot(page)).toEqual(before);await page.locator('#run-cancel-new').click();
> 126 |  await expect(page.locator('#fit-restart')).toBeFocused();
      |                                             ^ Error: expect(locator).toBeFocused() failed
  127 |  await page.locator('#battle-sound').click();await page.locator('#fit-restart').click();await page.locator('#run-confirm-new').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-sound')).toHaveAttribute('aria-pressed','true');
  128 | });
  129 | 
  130 | test('cached run return cannot overwrite either slot of a newer replacement',async({page,context,baseURL})=>{
  131 |  await start(page);const first=(await snapshot(page)).items.run.id;
  132 |  await page.goto(new URL('map',baseURL).href);await expect(page.locator('#map-grid span')).toHaveCount(400);
  133 |  const replacement=await context.newPage();await replacement.goto('/run');
  134 |  await replacement.locator('#run-start').click();await replacement.locator('#run-confirm-new').click();
  135 |  const fresh=await snapshot(replacement);expect(fresh.items.run.id).not.toBe(first);expect(fresh.items.run.seed).toBe(14);
  136 |  const stored=()=>page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),RUN_STORAGE_KEYS);
  137 |  const before=await stored();await replacement.close();await page.goBack({waitUntil:'commit'});
  138 |  await expect(page.locator('#run-continue')).toBeVisible();expect(await stored()).toEqual(before);
  139 |  await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(fresh);
  140 | });
  141 | 
  142 | test('review: in-flow Continue resumes an ongoing backup battle after legal defeat',async({page})=>{
  143 |  test.setTimeout(90000);await start(page);await fight(page,true);
  144 |  await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  145 |  const backup=await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.backup);
  146 |  const expected=JSON.parse(backup!).payload.activeBattle;expect(expected.outcome).toBe('ongoing');
  147 |  await page.getByRole('button',{name:'Save recovery',exact:true}).click();
  148 |  await page.getByRole('dialog').getByRole('button',{name:'Remove primary save',exact:true}).click();
  149 |  await page.getByRole('dialog').getByRole('button',{name:'Remove reviewed save',exact:true}).click();
  150 |  if(await page.getByRole('dialog').isVisible())await page.getByRole('dialog').getByRole('button',{name:/^(Close|Cancel)$/}).click();
  151 |  await page.getByRole('button',{name:'Continue saved run',exact:true}).click();
  152 |  await page.clock.install();await page.clock.pauseAt(await page.evaluate(()=>Date.now()+1000));
  153 |  await page.getByRole('dialog').getByRole('button',{name:'Continue',exact:true}).click({force:true});
  154 |  await page.clock.runFor(32);
  155 |  await expect(page.locator('#run-screen')).toBeHidden();await expect(page.locator('#game')).toHaveCSS('visibility','visible');
  156 |  expect((await readSession(page)).continuation?.snapshot).toEqual(expected);expect(await page.locator('canvas').count()).toBe(1);
  157 |  await page.clock.resume();await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  158 | });
  159 | test('review: read-level SecurityError permits explicit unsaved play without changing inaccessible bytes',async({page})=>{
  160 |  await page.goto('/run');await page.evaluate(keys=>{localStorage.setItem(keys.primary,'preserve primary');localStorage.setItem(keys.backup,'preserve backup');},RUN_STORAGE_KEYS);
  161 |  await page.addInitScript(keys=>{
  162 |   const read=Storage.prototype.getItem,write=Storage.prototype.setItem,remove=Storage.prototype.removeItem,calls:string[]=[];
  163 |   const owns=(key:string)=>Object.values(keys).some(value=>value===key);
  164 |   Storage.prototype.getItem=function(key){if(owns(key))throw new DOMException('Read denied','SecurityError');return read.call(this,key);};
  165 |   Storage.prototype.setItem=function(key,value){if(owns(key))calls.push('write:'+key);return write.call(this,key,value);};
  166 |   Storage.prototype.removeItem=function(key){if(owns(key))calls.push('remove:'+key);return remove.call(this,key);};
  167 |   Object.assign(window,{reviewReadEvidence:()=>({primary:read.call(localStorage,keys.primary),backup:read.call(localStorage,keys.backup),calls})});
  168 |  },RUN_STORAGE_KEYS);
  169 |  await page.reload();await expect(page.locator('#run-continue')).toHaveCount(0);
  170 |  await page.locator('#run-recovery').click();await expect(page.getByRole('dialog')).toContainText('primary: unavailable. backup: unavailable');await page.getByRole('button',{name:'Close',exact:true}).click();
  171 |  await page.locator('#run-unsaved').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  172 |  await page.locator('#battle-next').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-persistence')).toContainText('unsaved');
  173 |  expect(await page.evaluate(()=>(window as unknown as {reviewReadEvidence:()=>unknown}).reviewReadEvidence())).toEqual({primary:'preserve primary',backup:'preserve backup',calls:[]});
  174 | });
  175 | test('review: reopened outcome recovery exports the exact retained backup after partial reset',async({page})=>{
  176 |  test.setTimeout(90000);await start(page);await fight(page,true);const ended=await snapshot(page);
  177 |  const saved=await page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),RUN_STORAGE_KEYS);expect(saved.backup).not.toBeNull();
  178 |  await page.evaluate(primary=>{const remove=Storage.prototype.removeItem;Storage.prototype.removeItem=function(key){if(key===primary)throw new DOMException('Removal denied','SecurityError');return remove.call(this,key);};},RUN_STORAGE_KEYS.primary);
  179 |  await page.locator('#run-new').click();await expect(page.getByRole('button',{name:'Export backup save',exact:true})).toBeVisible();
  180 |  await page.getByRole('button',{name:'Close',exact:true}).click();await page.getByRole('button',{name:'Save recovery',exact:true}).click();
  181 |  await expect(page.getByRole('button',{name:'Export backup save',exact:true})).toBeVisible();
  182 |  const downloadPromise=page.waitForEvent('download');await page.getByRole('button',{name:'Export backup save',exact:true}).click();const download=await downloadPromise;
  183 |  expect(JSON.parse(readFileSync((await download.path())!,'utf8'))).toEqual({slot:'backup',text:saved.backup});
  184 |  expect(await snapshot(page)).toEqual(ended);
  185 |  expect(await page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),RUN_STORAGE_KEYS)).toEqual({primary:saved.primary,backup:null});
  186 | });
  187 | for(const dismiss of ['Escape','Close'] as const)test(`review: recovery dismissal via ${dismiss} retains connected visible keyboard focus`,async({page})=>{
  188 |  async function checkFocus(){
  189 |   const recovery=page.getByRole('button',{name:'Save recovery',exact:true});const before=await snapshot(page);
  190 |   await recovery.focus();await page.keyboard.press('Enter');await expect(page.getByRole('dialog')).toBeVisible();
  191 |   if(before.activeBattle){
  192 |    const viewport=page.viewportSize()!;
  193 |    await page.setViewportSize({width:viewport.height,height:viewport.width});
  194 |    await page.setViewportSize(viewport);
  195 |   }
  196 |   if(dismiss==='Escape')await page.keyboard.press('Escape');
  197 |   else {await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).focus();await page.keyboard.press('Enter');}
  198 |   await expect(page.getByRole('dialog')).not.toBeVisible();await expect(recovery).toBeVisible();await expect(recovery).toBeFocused();await expect(recovery).toBeInViewport();
  199 |   expect(await recovery.evaluate(node=>node.isConnected && document.activeElement===node)).toBe(true);expect(await snapshot(page)).toEqual(before);
  200 |  }
  201 |  await page.goto('/run');await page.locator('#run-start').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  202 |  await checkFocus(); // The mounted preparation controls are replaced on dismissal.
  203 |  await page.reload();await expect(page.locator('#run-continue')).toBeVisible();await checkFocus();
  204 |  await page.locator('#run-continue').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  205 |  await checkFocus(); // Battle controls stay mounted and keep their existing return behavior.
  206 | });
  207 | 
```
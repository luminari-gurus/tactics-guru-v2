# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-progression.spec.ts >> run preparation and dialogs retain 44px controls, native touch and narrow layout
- Location: tests/run-progression.spec.ts:125:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('#fit-restart')
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" locator('#fit-restart') with timeout 5000ms
  - waiting for locator('#fit-restart')
    14 × locator resolved to <button type="button" id="fit-restart">Start new run</button>
       - unexpected value "inactive"

```

```yaml
- button "Start new run"
```

# Test source

```ts
  36  |  const choice=offer.options.find(o=>o.itemId==='item:healing_draught')??offer.options[0];
  37  |  await page.getByRole('button',{name:`Claim ${runContext.items[choice.itemId].label}`,exact:true}).click();await page.locator('#item-confirm').click();
  38  |  await expect(page.locator('#run-start-encounter')).toBeVisible();
  39  |  for(const equipment of (await snapshot(page)).items.ownership.equipment){
  40  |   const now=await snapshot(page);if(now.items.ownership.assignments.some(a=>a.instanceId===equipment.instanceId))continue;
  41  |   const def=runContext.items[equipment.itemId];const hero=now.items.run.party.find(h=>h.hp>0 && def.eligibleHeroes.includes(h.heroId));
  42  |   if(hero){await page.locator(`[id="target-${equipment.instanceId}"]`).selectOption(hero.heroId);await page.getByRole('button',{name:`Equip ${def.label}`,exact:true}).click();await page.locator('#item-confirm').click();}
  43  |  }
  44  |  for(const hero of (await snapshot(page)).items.run.party){
  45  |   const now=await snapshot(page);if(hero.hp===0 || hero.hp===runContext.catalog.heroes[hero.heroId].stats.maxHp || !now.items.ownership.consumables.length)continue;
  46  |   await page.locator('[id="target-item:healing_draught"]').selectOption(hero.heroId);
  47  |   await page.getByRole('button',{name:'Use Healing Draught',exact:true}).click();await page.locator('#item-confirm').click();
  48  |  }
  49  | }
  50  | test('legal three encounter run, rewards, preparation, final resume and fresh restart',async({page})=>{
  51  |  test.setTimeout(300000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await start(page);await page.locator('#battle-sound').click();const records=[];
  52  |  for(let index=0;index<3;index++){
  53  |   await fight(page,false,true);if(index===0)await page.screenshot({path:test.info().outputPath('run-reward.png')});const current=await snapshot(page);expect(current.items.run.phase).toBe(index===2?'victory':'reward');expect(current.items.run.encounterIndex).toBe(index);
  54  |   const record=JSON.parse((await page.locator('#game').getAttribute('data-run-battle-record'))!);const replay=replayRunBattle(record.replay,record.entry,runContext);expect(replay.ok).toBe(true);if(replay.ok){expect(replay.state).toEqual(record.state);expect(replay.events).toEqual(record.events);}records.push(record);
  55  |   if(index<2){
  56  |    // The pending offer and claimed/prepared boundary survive the real Continue path.
  57  |    if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(current);}
  58  |    await prepare(page);const prepared=await snapshot(page);if(index===1){await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(prepared);}
  59  |    await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  60  |    if(await page.locator('#battle-hud-toggle').isVisible()){
  61  |     await expect(page.locator('#battle-hud-toggle')).toHaveAttribute('aria-expanded',index===0?'false':'true');
  62  |     if(index===0)await page.locator('#battle-hud-toggle').click();
  63  |    }
  64  |    await expect(page.locator('#battle-sound')).toHaveAttribute('aria-pressed',index===0?'true':'false');
  65  |   }
  66  |  }
  67  |  const final=await snapshot(page);await expect(page.getByRole('heading',{name:'Run victory',exact:true})).toBeVisible();
  68  |  await page.screenshot({path:test.info().outputPath('run-victory.png')});
  69  |  writeFileSync(test.info().outputPath('run-records.json'),JSON.stringify(records,null,2));
  70  |  await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(final);
  71  |  await page.locator('#run-new').dblclick();const fresh=await snapshot(page);expect(fresh.items.run.seed).toBe(14);expect(fresh.items.run.id).not.toBe(final.items.run.id);expect(fresh.items.ownership).toEqual({consumables:[],equipment:[],assignments:[]});expect(fresh.items.run.party.every(h=>h.hp===runContext.catalog.heroes[h.heroId].stats.maxHp)).toBe(true);
  72  |  expect(errors).toEqual([]);
  73  | });
  74  | test('legal defeat reload, native keyboard restart and isolated single-battle save',async({page})=>{
  75  |  test.setTimeout(180000);await start(page);await fight(page,true);await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  76  |  const ended=await snapshot(page);await page.reload();await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(ended);
  77  |  await page.locator('#run-new').focus();await page.keyboard.press('Enter');await expect(page.locator('#run-start-encounter')).toBeVisible();
  78  |  await page.getByRole('link',{name:'Single battle',exact:true}).click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  79  |  const run=await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary);expect(JSON.parse(run!).payload.items.run.encounterIndex).toBe(0);
  80  |  await page.getByRole('link',{name:'Play three-encounter run'}).click();await page.locator('#run-continue').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  81  | });
  82  | test('accepted player presentation reload preserves exact boundary without old cues',async({page})=>{
  83  |  await start(page);await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
  84  |  await page.clock.install();await page.clock.pauseAt(new Date(Date.now()+1000));await page.locator('#dialog-confirm').click({force:true});
  85  |  await expect(page.locator('#game')).toHaveAttribute('data-phase','presenting');const committed=await snapshot(page);
  86  |  await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  87  |  expect((await readSession(page)).state).toEqual(committed.activeBattle);expect((await readSession(page)).events).toEqual([]);expect(await page.evaluate(()=>window.fitDiagnostics().battleAudio?.lastToken)).toBe(0);
  88  | });
  89  | test('enemy presentation reload resumes the same commands and RNG as an uninterrupted run',async({page,browser,baseURL})=>{
  90  |  const other=await browser.newContext({viewport:page.viewportSize(),baseURL});const control=await other.newPage();
  91  |  try {
  92  |   for(const p of [page,control]){
  93  |    await p.clock.install();await start(p);await p.clock.pauseAt(await p.evaluate(()=>Date.now()+1000));
  94  |    for(let i=0;i<100;i++){
  95  |     const s=await readSession(p),last=s.replay?.commands.at(-1);
  96  |     if(s.phase==='presenting' && last && s.state.units.find(u=>u.id===last.unitId)!.side==='enemy')break;
  97  |     if(s.phase==='player')await p.locator('#battle-next').click({force:true});
  98  |     await p.clock.runFor(32);
  99  |    }
  100 |   }
  101 |   const boundary=await readSession(page);expect(boundary.phase).toBe('presenting');const last=boundary.replay!.commands.at(-1)!;expect(boundary.state.units.find(u=>u.id===last.unitId)!.side).toBe('enemy');
  102 |   expect((await readSession(control)).state).toEqual(boundary.state);
  103 |   await page.reload();await page.clock.resume();await page.locator('#run-continue').click();await control.clock.resume();
  104 |   for(const p of [page,control])await expect(p.locator('#game')).toHaveAttribute('data-phase','player');
  105 |   const resumed=await readSession(page),uninterrupted=await readSession(control);expect(resumed.state).toEqual(uninterrupted.state);
  106 |   const catalog=runBattleCatalog((await snapshot(page)).items,runContext)!;const command=playerDecision(resumed.state,catalog);
  107 |   for(const p of [page,control]){await playCommand(p,command);await expect(p.locator('#game')).toHaveAttribute('data-phase','player');}
  108 |   expect((await readSession(page)).state).toEqual((await readSession(control)).state);
  109 |  }finally{await other.close();}
  110 | });
  111 | test('run startup preserves corrupt bytes, recovery captures input, and unavailable storage permits unsaved play',async({page})=>{
  112 |  await page.goto('/run');await page.evaluate(key=>localStorage.setItem(key,'{bad'),RUN_STORAGE_KEYS.primary);await page.reload();
  113 |  expect(await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.primary)).toBe('{bad');
  114 |  await page.locator('#run-recovery').click();await expect(page.getByRole('dialog')).toContainText('primary: invalid');
  115 |  const visited=new Set<string>();
  116 |  for(const key of ['Tab','Shift+Tab'])for(let i=0;i<8;i++){
  117 |   await page.keyboard.press(key);expect(await page.evaluate(()=>!!document.activeElement?.closest('dialog'))).toBe(true);
  118 |   visited.add(await page.evaluate(()=>document.activeElement!.id));
  119 |  }
  120 |  for(const id of await page.getByRole('dialog').getByRole('button').evaluateAll(buttons=>buttons.map(b=>b.id)))expect(visited.has(id)).toBe(true);
  121 |  await page.locator('#run-close-recovery').click();await page.locator('#run-start').click();await page.locator('#run-confirm-new').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  122 |  await page.reload();await page.addInitScript(()=>{Object.defineProperty(window,'localStorage',{get(){throw new DOMException('denied','SecurityError');}});});await page.reload();
  123 |  await page.locator('#run-unsaved').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-persistence')).toContainText('unsaved');
  124 | });
  125 | test('run preparation and dialogs retain 44px controls, native touch and narrow layout',async({page},info)=>{
  126 |  await page.goto('/run');const activate=async(selector:string)=>{if(info.project.use.hasTouch)await page.locator(selector).tap();else await page.locator(selector).click();};
  127 |  await activate('#run-start');await expect(page.locator('#run-start-encounter')).toBeVisible();
  128 |  for(const viewport of [{width:320,height:568},{width:915,height:412},{width:412,height:915}]){
  129 |   await page.setViewportSize(viewport);
  130 |   const boxes=await page.locator('#run-screen button,#run-screen a,#run-screen select').evaluateAll(nodes=>nodes.filter(n=>n.getClientRects().length).map(n=>{n.scrollIntoView({block:'nearest'});const r=n.getBoundingClientRect();return{width:r.width,height:r.height,left:r.left,right:r.right};}));
  131 |   for(const box of boxes){expect(box.width).toBeGreaterThanOrEqual(44);expect(box.height).toBeGreaterThanOrEqual(44);expect(box.left).toBeGreaterThanOrEqual(0);expect(box.right).toBeLessThanOrEqual(viewport.width);}
  132 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  133 |  }
  134 |  await activate('#run-start-encounter');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  135 |  await page.locator('#fit-restart').click();await expect(page.getByRole('dialog')).toBeVisible();const before=await snapshot(page);await page.mouse.click(3,3);expect(await snapshot(page)).toEqual(before);await page.locator('#run-cancel-new').click();
> 136 |  await expect(page.locator('#fit-restart')).toBeFocused();
      |                                             ^ Error: expect(locator).toBeFocused() failed
  137 |  await page.locator('#battle-sound').click();await page.locator('#fit-restart').click();await page.locator('#run-confirm-new').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-sound')).toHaveAttribute('aria-pressed','true');
  138 | });
  139 | 
  140 | test('cached run return cannot overwrite either slot of a newer replacement',async({page,context,baseURL})=>{
  141 |  await start(page);const first=(await snapshot(page)).items.run.id;
  142 |  await page.goto(new URL('map',baseURL).href);await expect(page.locator('#map-grid span')).toHaveCount(400);
  143 |  const replacement=await context.newPage();await replacement.goto('/run');
  144 |  await replacement.locator('#run-start').click();await replacement.locator('#run-confirm-new').click();
  145 |  const fresh=await snapshot(replacement);expect(fresh.items.run.id).not.toBe(first);expect(fresh.items.run.seed).toBe(14);
  146 |  const stored=()=>page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),RUN_STORAGE_KEYS);
  147 |  const before=await stored();await replacement.close();await page.goBack({waitUntil:'commit'});
  148 |  await expect(page.locator('#run-continue')).toBeVisible();expect(await stored()).toEqual(before);
  149 |  await page.locator('#run-continue').click();expect(await snapshot(page)).toEqual(fresh);
  150 | });
  151 | 
  152 | test('review: in-flow Continue resumes an ongoing backup battle after legal defeat',async({page})=>{
  153 |  test.setTimeout(90000);await start(page);await fight(page,true);
  154 |  await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  155 |  const backup=await page.evaluate(key=>localStorage.getItem(key),RUN_STORAGE_KEYS.backup);
  156 |  const expected=JSON.parse(backup!).payload.activeBattle;expect(expected.outcome).toBe('ongoing');
  157 |  await page.getByRole('button',{name:'Save recovery',exact:true}).click();
  158 |  await page.getByRole('dialog').getByRole('button',{name:'Remove primary save',exact:true}).click();
  159 |  await page.getByRole('dialog').getByRole('button',{name:'Remove reviewed save',exact:true}).click();
  160 |  if(await page.getByRole('dialog').isVisible())await page.getByRole('dialog').getByRole('button',{name:/^(Close|Cancel)$/}).click();
  161 |  await page.getByRole('button',{name:'Continue saved run',exact:true}).click();
  162 |  await page.clock.install();await page.clock.pauseAt(await page.evaluate(()=>Date.now()+1000));
  163 |  await page.getByRole('dialog').getByRole('button',{name:'Continue',exact:true}).click({force:true});
  164 |  await page.clock.runFor(32);
  165 |  await expect(page.locator('#run-screen')).toBeHidden();await expect(page.locator('#game')).toHaveCSS('visibility','visible');
  166 |  expect((await readSession(page)).continuation?.snapshot).toEqual(expected);expect(await page.locator('canvas').count()).toBe(1);
  167 |  await page.clock.resume();await expect(page.getByRole('heading',{name:'Run defeat',exact:true})).toBeVisible();
  168 | });
  169 | test('review: read-level SecurityError permits explicit unsaved play without changing inaccessible bytes',async({page})=>{
  170 |  await page.goto('/run');await page.evaluate(keys=>{localStorage.setItem(keys.primary,'preserve primary');localStorage.setItem(keys.backup,'preserve backup');},RUN_STORAGE_KEYS);
  171 |  await page.addInitScript(keys=>{
  172 |   const read=Storage.prototype.getItem,write=Storage.prototype.setItem,remove=Storage.prototype.removeItem,calls:string[]=[];
  173 |   const owns=(key:string)=>Object.values(keys).some(value=>value===key);
  174 |   Storage.prototype.getItem=function(key){if(owns(key))throw new DOMException('Read denied','SecurityError');return read.call(this,key);};
  175 |   Storage.prototype.setItem=function(key,value){if(owns(key))calls.push('write:'+key);return write.call(this,key,value);};
  176 |   Storage.prototype.removeItem=function(key){if(owns(key))calls.push('remove:'+key);return remove.call(this,key);};
  177 |   Object.assign(window,{reviewReadEvidence:()=>({primary:read.call(localStorage,keys.primary),backup:read.call(localStorage,keys.backup),calls})});
  178 |  },RUN_STORAGE_KEYS);
  179 |  await page.reload();await expect(page.locator('#run-continue')).toHaveCount(0);
  180 |  await page.locator('#run-recovery').click();await expect(page.getByRole('dialog')).toContainText('primary: unavailable. backup: unavailable');await page.getByRole('button',{name:'Close',exact:true}).click();
  181 |  await page.locator('#run-unsaved').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  182 |  await page.locator('#battle-next').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');await expect(page.locator('#battle-persistence')).toContainText('unsaved');
  183 |  expect(await page.evaluate(()=>(window as unknown as {reviewReadEvidence:()=>unknown}).reviewReadEvidence())).toEqual({primary:'preserve primary',backup:'preserve backup',calls:[]});
  184 | });
  185 | test('review: reopened outcome recovery exports the exact retained backup after partial reset',async({page})=>{
  186 |  test.setTimeout(90000);await start(page);await fight(page,true);const ended=await snapshot(page);
  187 |  const saved=await page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),RUN_STORAGE_KEYS);expect(saved.backup).not.toBeNull();
  188 |  await page.evaluate(primary=>{const remove=Storage.prototype.removeItem;Storage.prototype.removeItem=function(key){if(key===primary)throw new DOMException('Removal denied','SecurityError');return remove.call(this,key);};},RUN_STORAGE_KEYS.primary);
  189 |  await page.locator('#run-new').click();await expect(page.getByRole('button',{name:'Export backup save',exact:true})).toBeVisible();
  190 |  await page.getByRole('button',{name:'Close',exact:true}).click();await page.getByRole('button',{name:'Save recovery',exact:true}).click();
  191 |  await expect(page.getByRole('button',{name:'Export backup save',exact:true})).toBeVisible();
  192 |  const downloadPromise=page.waitForEvent('download');await page.getByRole('button',{name:'Export backup save',exact:true}).click();const download=await downloadPromise;
  193 |  expect(JSON.parse(readFileSync((await download.path())!,'utf8'))).toEqual({slot:'backup',text:saved.backup});
  194 |  expect(await snapshot(page)).toEqual(ended);
  195 |  expect(await page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),RUN_STORAGE_KEYS)).toEqual({primary:saved.primary,backup:null});
  196 | });
  197 | for(const dismiss of ['Escape','Close'] as const)test(`review: recovery dismissal via ${dismiss} retains connected visible keyboard focus`,async({page})=>{
  198 |  async function checkFocus(){
  199 |   const recovery=page.getByRole('button',{name:'Save recovery',exact:true});const before=await snapshot(page);
  200 |   await recovery.focus();await page.keyboard.press('Enter');await expect(page.getByRole('dialog')).toBeVisible();
  201 |   if(before.activeBattle){
  202 |    const viewport=page.viewportSize()!;
  203 |    await page.setViewportSize({width:viewport.height,height:viewport.width});
  204 |    await page.setViewportSize(viewport);
  205 |   }
  206 |   if(dismiss==='Escape')await page.keyboard.press('Escape');
  207 |   else {await page.getByRole('dialog').getByRole('button',{name:'Close',exact:true}).focus();await page.keyboard.press('Enter');}
  208 |   await expect(page.getByRole('dialog')).not.toBeVisible();await expect(recovery).toBeVisible();await expect(recovery).toBeFocused();await expect(recovery).toBeInViewport();
  209 |   expect(await recovery.evaluate(node=>node.isConnected && document.activeElement===node)).toBe(true);expect(await snapshot(page)).toEqual(before);
  210 |  }
  211 |  await page.goto('/run');await page.locator('#run-start').click();await expect(page.locator('#run-start-encounter')).toBeVisible();
  212 |  await checkFocus(); // The mounted preparation controls are replaced on dismissal.
  213 |  await page.reload();await expect(page.locator('#run-continue')).toBeVisible();await checkFocus();
  214 |  await page.locator('#run-continue').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  215 |  await checkFocus(); // Battle controls stay mounted and keep their existing return behavior.
  216 | });
  217 | 
```
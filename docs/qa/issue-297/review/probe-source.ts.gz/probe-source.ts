import {test,expect} from '@playwright/test';
import {writeFileSync} from 'node:fs';
for(const mode of ['run','dungeon'])test(`post-mount module failure ${mode}`,async({page},info)=>{
 await page.route(/\/start(?:Run|Dungeon)App-[^/]+\.js$/,async route=>{
  const response=await route.fetch();await route.fulfill({response,body:(await response.text())+'\nthrow new Error("review: post-mount initialization failed");\n'});
 });
 await page.goto('./?game='+mode);
 await expect(page.locator('#fit-status')).toContainText('Could not load the application');
 const result=await page.locator('#fit-status').evaluate(e=>({text:e.textContent,visible:e.checkVisibility(),hiddenAncestor:e.closest('[hidden]')?.id}));
 writeFileSync(info.outputPath('probe.json'),JSON.stringify(result));await page.screenshot({path:info.outputPath('failure.png')});
 expect(result.visible).toBe(true);
});
test('runtime error while run preparation owns screen',async({page},info)=>{
 await page.goto('./?game=run');await expect(page.locator('#run-start')).toBeVisible();
 await page.evaluate(()=>window.dispatchEvent(new ErrorEvent('error',{message:'review: renderer initialization failed'})));
 await expect(page.locator('#fit-status')).toContainText('The run encountered a runtime error');
 const result=await page.locator('#fit-status').evaluate(e=>({text:e.textContent,visible:e.checkVisibility(),hiddenAncestor:e.closest('[hidden]')?.id}));
 writeFileSync(info.outputPath('probe.json'),JSON.stringify(result));await page.screenshot({path:info.outputPath('failure.png')});expect(result.visible).toBe(true);
});

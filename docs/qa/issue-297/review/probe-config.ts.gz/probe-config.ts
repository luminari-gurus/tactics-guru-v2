import { defineConfig } from '@playwright/test';
import base from '../../playwright.regression.config';
export default defineConfig({...base,testDir:'.',testMatch:'review.spec.ts',projects:base.projects!.filter(p=>p.name==='desktop')});

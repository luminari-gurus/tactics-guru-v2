# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-loop.spec.ts >> clearing the native movement destination clears intent and preview without changing saves
- Location: tests/battle-loop.spec.ts:83:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('#game')
Expected: "player"
Received: "presenting"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" locator('#game') with timeout 5000ms
  - waiting for locator('#game')
    13 × locator resolved to <main id="game" data-run="1" data-ready="true" data-phase="presenting" aria-label="Tactics Guru game canvas" data-session="{"state":{"format":3,"versions":{"rules":4,"rng":1,"content":"sha256:c5659e71918e4ebccc31be76ffc04153e2913678c1f04558161944e2ace96450"},"seed":1,"rng":{"words":[301591043,2427469659,191567882,19],"cursor":6},"mapId":"map:forest_ruins","units":[{"id":1,"cell":{"x":1,"y":8},"hasMoved":false,"hasActed":false,"side":"player","defId":"fighter","hp":18},{"id":2,"cell":{"x":2,"y":8},"h…>…</main>
       - unexpected value "presenting"

```

```yaml
- main "Tactics Guru game canvas"
```

# Test source

```ts
  12  |   const move=page.locator('#battle-move'),target=page.locator('#battle-target');
  13  |   await expect(move).toHaveAttribute('aria-pressed','true');await expect(move).toBeEnabled();
  14  |   const initial=await session(page),actor=initial.state.units.find(u=>u.id===initial.state.initiative[initial.state.activeIndex])!;
  15  |   expect(initial.replay.commands.every(c=>initial.state.units.find(u=>u.id===c.unitId)!.side==='enemy')).toBe(true);
  16  |   const saved=await page.evaluate(()=>JSON.stringify(localStorage));
  17  |   const reach=previewMovement(initial.state,actor.id,catalog);if(!reach.ok)throw Error(reach.reason);
  18  |   expect(await target.locator('option').evaluateAll(options=>options.map(o=>(o as HTMLOptionElement).value).filter(Boolean)))
  19  |     .toEqual(reach.cells.filter(c=>c.cost>0).map(c=>`${c.cell.x},${c.cell.y}`));
  20  |   const report=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  21  |   expect(report.reachable).toEqual(reach.cells.map(c=>c.cell));expect(report.selected).toBeNull();
  22  |   await expect(target).toHaveValue('');await expect(page.locator('#battle-review')).toBeDisabled();
  23  |   expect(JSON.parse((await page.locator('#game').getAttribute('data-session'))!).pending).toBeNull();
  24  |   await page.screenshot({path:test.info().outputPath('default-move.png')});
  25  |   for(const action of ['basic','signature']){
  26  |     await page.locator(`[data-action=${action}]`).click();await target.selectOption({index:1});
  27  |     const selected=await target.inputValue(),before=await page.locator('#game').getAttribute('data-session');
  28  |     const overlays=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!).targets;
  29  |     await page.locator('#battle-party').click();await page.locator('#inspection-close').click();
  30  |     await page.locator('#battle-log-open').click();await page.locator('#log-close').click();
  31  |     const box=(await page.locator('#battle-board-region').boundingBox())!;
  32  |     await page.mouse.move(box.x+box.width/2,box.y+box.height/2);
  33  |     const viewport=page.viewportSize()!;await page.setViewportSize({width:viewport.width-1,height:viewport.height});await page.setViewportSize(viewport);
  34  |     await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'));Object.defineProperty(document,'hidden',{configurable:true,value:false});document.dispatchEvent(new Event('visibilitychange'));});
  35  |     await expect(page.locator(`[data-action=${action}]`)).toHaveAttribute('aria-pressed','true');await expect(move).toHaveAttribute('aria-pressed','false');
  36  |     await expect(target).toHaveValue(selected);expect(await page.locator('#game').getAttribute('data-session')).toBe(before);
  37  |     expect(JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!).targets).toEqual(overlays);
  38  |   }
  39  |   await page.locator('#battle-scroll').evaluate(e=>{e.scrollTop=0;});
  40  |   await page.screenshot({path:test.info().outputPath('explicit-override.png')});
  41  |   expect((await session(page)).state).toEqual(initial.state);expect((await session(page)).replay).toEqual(initial.replay);
  42  |   expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(saved);
  43  |   await page.locator('#battle-cancel').click();await page.locator('#battle-party').click();await page.locator('#inspection-close').click();
  44  |   await expect(move).toHaveAttribute('aria-pressed','false');await expect(target).toBeDisabled();
  45  |   expect(JSON.parse((await page.locator('#game').getAttribute('data-session'))!).pending).toBeNull();
  46  |   // Leave an explicit action selected, then progress through actual Wait/enemy turns.
  47  |   await page.locator('[data-action=basic]').click();
  48  |   let otherActor=false,wrapped=false;
  49  |   for(let i=0;i<12 && !wrapped;i++){
  50  |     await page.locator('#battle-next').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  51  |     const current=await session(page),id=current.state.initiative[current.state.activeIndex];
  52  |     await expect(move).toHaveAttribute('aria-pressed','true');await expect(target).toHaveValue('');await expect(page.locator('#battle-review')).toBeDisabled();
  53  |     if(id!==actor.id)otherActor=true;if(id===actor.id && current.state.round>initial.state.round)wrapped=true;
  54  |   }
  55  |   expect(otherActor).toBe(true);expect(wrapped).toBe(true);
  56  |   const final=await session(page),replayed=replayBattle(final.replay,catalog);expect(replayed.ok).toBe(true);
  57  |   if(replayed.ok){expect(replayed.state).toEqual(final.state);expect(replayed.events).toEqual(final.events);}
  58  |   const playerFirstSeed=Array.from({length:20},(_,i)=>i+2).find(seed=>new BattleSession(catalog,'map:forest_ruins',seed).phase==='player');
  59  |   expect(playerFirstSeed).toBeDefined();
  60  |   for(let seed=2;seed<=playerFirstSeed!;seed++){
  61  |     await page.locator('#fit-restart').click();await confirmRestart(page);await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  62  |     await expect(move).toHaveAttribute('aria-pressed','true');
  63  |   }
  64  |   const fresh=await session(page);expect(fresh.state.seed).toBe(playerFirstSeed);expect(fresh.replay.commands).toEqual([]);
  65  |   expect(fresh.replay.initial.units.find(u=>u.id===fresh.replay.initial.initiative[0])!.side).toBe('player');
  66  |   await expect(move).toHaveAttribute('aria-pressed','true');
  67  | });
  68  | 
  69  | // Native keyboard type-ahead works without a platform popup. Headless macOS
  70  | // Chrome ignores Home/ArrowDown even on a plain select. Tab away before each
  71  | // choice to reset the native type-ahead buffer; never synthesize change events.
  72  | async function chooseNativeDestination(target:Locator,index:0|1){
  73  |   const option=target.locator('option').nth(index),label=(await option.textContent())!,value=(await option.getAttribute('value'))!;
  74  |   await target.press('Tab');await target.focus();
  75  |   await target.evaluate(element=>{
  76  |     element.removeAttribute('data-native-change');
  77  |     element.addEventListener('change',event=>element.setAttribute('data-native-change',String(event.isTrusted)),{once:true});
  78  |   });
  79  |   await target.pressSequentially(label);
  80  |   await expect(target).toHaveValue(value);await expect(target).toHaveAttribute('data-native-change','true');
  81  | }
  82  | 
  83  | test('clearing the native movement destination clears intent and preview without changing saves',async({page})=>{
  84  |   const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  85  |   await page.goto('/');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  86  |   const target=page.locator('#battle-target'),review=page.locator('#battle-review');
  87  |   const initial=await session(page),saved=await page.evaluate(()=>JSON.stringify(localStorage));
  88  |   await chooseNativeDestination(target,1);
  89  |   await expect(review).toBeEnabled();
  90  |   const pending=(await session(page)).pending;expect(pending?.type).toBe('move');
  91  |   await chooseNativeDestination(target,0);
  92  |   await expect(target).toHaveValue('');
  93  |   expect((await session(page)).pending).toBeNull();await expect(review).toBeDisabled();
  94  |   await expect(page.locator('#battle-move')).toHaveAttribute('aria-pressed','true');
  95  |   await expect(page.locator('#battle-selection')).toHaveText('Select a tile');
  96  |   await expect(page.locator('#battle-preview')).toHaveText('Select a destination');
  97  |   const report=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  98  |   expect(report.selected).toBeNull();expect(report.hover).toBeNull();
  99  |   expect((await session(page)).state).toEqual(initial.state);expect((await session(page)).replay).toEqual(initial.replay);
  100 |   expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(saved);
  101 |   await review.scrollIntoViewIfNeeded();await page.screenshot({path:test.info().outputPath('destination-cleared.png')});
  102 |   // A real new choice remains usable and still requires deliberate confirmation.
  103 |   await chooseNativeDestination(target,1);await expect(review).toBeEnabled();
  104 |   expect((await session(page)).pending).toEqual(pending);
  105 |   await page.clock.install();await page.clock.pauseAt(await page.evaluate(()=>Date.now()+1000));
  106 |   await expect(review).toHaveText('Confirm action');await review.focus();await page.keyboard.press('Enter');
  107 |   await expect(page.getByRole('dialog')).not.toBeVisible();
  108 |   await expect(page.locator('#game')).toHaveAttribute('data-phase','presenting');await expect(review).toBeDisabled();
  109 |   await review.dispatchEvent('click');await review.dispatchEvent('click');
  110 |   expect((await session(page)).state.commandCount).toBe(initial.state.commandCount+1);
  111 |   await page.clock.resume();
> 112 |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
      |                                       ^ Error: expect(locator).toHaveAttribute(expected) failed
  113 |   const confirmed=await session(page);expect(confirmed.state.commandCount).toBe(initial.state.commandCount+1);
  114 |   expect(confirmed.replay.commands).toEqual([...initial.replay.commands,pending]);
  115 |   expect(errors).toEqual([]);
  116 | });
  117 | 
  118 | for(const dismissal of ['Cancel','Escape'] as const){
  119 |   test(`movement confirmation ${dismissal} resets destination and permits native same-destination retry`,async({page})=>{
  120 |     const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  121 |     await page.goto('/');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  122 |     const target=page.locator('#battle-target'),review=page.locator('#battle-review');
  123 |     const initial=await session(page),saved=await page.evaluate(()=>JSON.stringify(localStorage));
  124 |     await chooseNativeDestination(target,1);
  125 |     await expect(review).toBeEnabled();
  126 |     const destination=await target.inputValue(),pending=(await session(page)).pending;
  127 |     expect(pending?.type).toBe('move');
  128 |     if(dismissal==='Cancel')await page.locator('#battle-cancel').click();else await page.keyboard.press('Escape');
  129 |     await expect(page.getByRole('dialog')).not.toBeVisible();
  130 |     await expect(target).toHaveValue('');await expect(review).toBeDisabled();expect((await session(page)).pending).toBeNull();
  131 |     // Native type-ahead must emit a real change after cancellation; selectOption
  132 |     // would dispatch change even if the destination had incorrectly stayed selected.
  133 |     await page.locator('#battle-move').click();await chooseNativeDestination(target,1);
  134 |     await expect(target).toHaveValue(destination);await expect(review).toBeEnabled();
  135 |     expect((await session(page)).pending).toEqual(pending);
  136 |     expect((await session(page)).state).toEqual(initial.state);expect((await session(page)).replay).toEqual(initial.replay);
  137 |     expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(saved);
  138 |     // Dismiss a second time to inspect the cleared UI before confirming the retry.
  139 |     if(dismissal==='Cancel')await page.locator('#battle-cancel').click();else await page.keyboard.press('Escape');
  140 |     await expect(target).toHaveValue('');await expect(review).toBeDisabled();expect((await session(page)).pending).toBeNull();
  141 |     await expect(page.locator('#battle-move')).toHaveAttribute('aria-pressed','false');
  142 |     const report=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  143 |     if(pending?.type!=='move')throw Error('Expected prepared move');expect(report.selected).toMatchObject({...pending.to});expect(report.hover).toBeNull();
  144 |     await review.scrollIntoViewIfNeeded();await page.screenshot({path:test.info().outputPath('movement-cancelled.png')});
  145 |     await page.locator('#battle-move').click();await chooseNativeDestination(target,1);await expect(review).toBeEnabled();
  146 |     await review.click();
  147 |     await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  148 |     const confirmed=await session(page);expect(confirmed.state.commandCount).toBe(initial.state.commandCount+1);
  149 |     expect(confirmed.replay.commands).toEqual([...initial.replay.commands,pending]);expect(errors).toEqual([]);
  150 |   });
  151 | }
  152 | 
  153 | test('player HUD and preview cancellation preserve state and modal capture', async ({page})=>{
  154 |   await page.goto('/');
  155 |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  156 |   await expect(page.locator('#battle-portraits img:visible')).toBeVisible();
  157 |   await expect(page.locator('#battle-party')).toHaveText('Inspect party');
  158 |   await expect(page.getByRole('button',{name:'Basic attack',exact:true})).toBeVisible();
  159 |   const before = await page.locator('#game').getAttribute('data-session');
  160 |   await page.getByRole('button',{name:'Move',exact:true}).click();
  161 |   await page.locator('#battle-target').selectOption({index:1});
  162 |   await page.locator('#battle-party').click();
  163 |   await expect(page.getByRole('dialog')).toBeVisible();
  164 |   await page.keyboard.press('Tab');expect(await page.evaluate(()=>!!document.activeElement?.closest('dialog'))).toBe(true);
  165 |   await page.keyboard.press('Escape');
  166 |   await expect(page.getByRole('dialog')).not.toBeVisible();
  167 |   await page.locator('#battle-cancel').click();
  168 |   const initial=JSON.parse(before!),after=await session(page);
  169 |   expect(after.state).toEqual(initial.state);expect(after.replay).toEqual(initial.replay);expect(after.pending).toBeNull();
  170 |   await expect(page.locator('#battle-move')).toBeFocused();
  171 |   await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});
  172 |   await page.locator('#battle-cancel').focus();await page.keyboard.press('Enter');
  173 |   await expect(page.locator('#battle-move')).toBeFocused();
  174 |   const cancelled=await session(page);expect(cancelled.state).toEqual(initial.state);expect(cancelled.replay).toEqual(initial.replay);
  175 | 
  176 | });
  177 | 
  178 | import { playerDecision, session, readSession, playCommand } from './helpers/battlePolicy';
  179 | import { standaloneCatalog as catalog } from './helpers/playerPolicy';
  180 | import { replayBattle } from '../src/domain/turns';
  181 | import type { Command } from '../src/domain/types';
  182 | 
  183 | for(const [seed,outcome] of [[1,'playerLoss'],[2,'playerWin']] as const){
  184 |   test(`complete legal authored battle seed ${seed} reaches ${outcome} through controls and replays`,async({page})=>{
  185 |     test.setTimeout(180000);const errors:string[]=[];
  186 |     page.on('pageerror',e=>errors.push(e.message));
  187 |     await page.goto('/');await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  188 |     if(seed===2){await page.getByRole('button',{name:'Restart battle',exact:true}).click();await confirmRestart(page);await expect.poll(async()=> (await session(page)).state.seed).toBe(2);}
  189 |     await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  190 |     const boardObjects=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!).objectCount;
  191 |     for(let i=0;i<200;i++){
  192 |       await expect.poll(async()=> (await session(page)).phase,{timeout:10000}).toMatch(/^(player|ended|error)$/);
  193 |       const board=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  194 |       expect(board.effect).toBeNull();expect(board.objectCount).toBe(boardObjects);
  195 |       const s=await session(page);if(s.phase==='ended')break;expect(s.phase).toBe('player');
  196 |       await playCommand(page,playerDecision(s.state));
  197 |     }
  198 |     const final=await session(page);expect(final.state.outcome).toBe(outcome);
  199 |     expect(final.replay.commands.some(c=>c.type==='move')).toBe(true);
  200 |     expect(final.replay.commands.some(c=>c.type==='useAbility' && c.abilityId==='ability:basic_attack')).toBe(true);
  201 |     if(seed===2)expect(final.replay.commands.filter(c=>c.type==='useAbility').map(c=>c.abilityId)).toEqual(expect.arrayContaining(['ability:guarded_strike','ability:high_shot','ability:magic_missile']));
  202 |     const replay=replayBattle(final.replay,catalog);expect(replay.ok).toBe(true);
  203 |     if(replay.ok){expect(replay.state).toEqual(final.state);expect(replay.events).toEqual(final.events);}
  204 |     await expect(page.getByRole('dialog')).toContainText(outcome==='playerWin'?'Victory':'Defeat');
  205 |     await page.screenshot({path:test.info().outputPath(`${outcome}.png`)});
  206 |     const replayPath=test.info().outputPath('replay.json');
  207 |     writeFileSync(replayPath,JSON.stringify(final,null,2));
  208 |     await test.info().attach('replay',{path:replayPath,contentType:'application/json'});
  209 |     // Reload the legally completed battle and rebuild its outcome without historical cues.
  210 |     await page.reload();await page.locator('#save-continue').click();
  211 |     await expect(page.locator('#game')).toHaveAttribute('data-phase','ended');
  212 |     const continued=await readSession(page);expect(continued.state).toEqual(final.state);
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ability-picker.spec.ts >> Ranger mark_target preserves keyboard touch preview cancellation inspection and exact resume
- Location: tests/ability-picker.spec.ts:19:62

# Error details

```
Error: page.evaluate: TypeError: window.fitDiagnostics is not a function. (In 'window.fitDiagnostics()', 'window.fitDiagnostics' is undefined)
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - paragraph [ref=e4]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Proof scene diagnostics" [ref=e5]:
      - generic "Acting unit information; scroll for details" [ref=e6]:
        - paragraph [ref=e7]: Round 1 · Your turn
        - generic [ref=e8]:
          - img "Ranger portrait" [ref=e10]
          - generic [ref=e11]:
            - heading "Ranger" [level=2] [ref=e12]
            - paragraph [ref=e13]: HP 22/22
            - paragraph [ref=e16]: AC 12 · Accuracy +5
            - paragraph [ref=e17]: No status effects
        - paragraph [ref=e18]: Move ready / Action ready
      - generic "Actions, target and secondary tools; scroll for more" [ref=e19]:
        - generic [ref=e20]:
          - paragraph [ref=e21]: Choose your action
          - generic "Acting unit actions" [ref=e22]:
            - button "Move" [pressed] [ref=e23] [cursor=pointer]:
              - strong [ref=e24]: Move
              - generic [ref=e25]: Uses movement
            - button "Basic attack" [ref=e26] [cursor=pointer]:
              - strong [ref=e27]: Basic attack
              - generic [ref=e28]: Uses action
            - button "High Shot" [ref=e29] [cursor=pointer]:
              - strong [ref=e30]: High Shot
              - generic [ref=e31]: Uses action
            - button "Wait / End turn" [ref=e32] [cursor=pointer]:
              - strong [ref=e33]: Wait / End turn
              - generic [ref=e34]: Ends turn immediately
          - text: Ability
          - combobox "Ability" [ref=e35]:
            - option "High Shot" [selected]
            - option "Mark Target"
            - option "Pinning Shot"
            - option "Zz Ranger"
          - paragraph [ref=e36]: Range 2–5 · Hostile target · attack roll · uses action · Mark Target unlocks at level 2; Pinning Shot at level 3
          - paragraph [ref=e37]: Choose an action, then a target. Wait ends the turn immediately.
          - region "Target and action preview" [ref=e38]:
            - generic [ref=e39]: Target / destination
            - combobox "Target / destination" [ref=e40]:
              - option "Choose target" [selected]
              - option "(0, 1) · cost 1"
              - option "(1, 1) · cost 2"
              - option "(0, 2) · cost 2"
              - option "(2, 1) · cost 3"
              - option "(1, 2) · cost 3"
              - option "(0, 3) · cost 3"
              - option "(3, 1) · cost 4"
              - option "(2, 2) · cost 4"
            - paragraph [ref=e41]: Select a tile
            - paragraph
            - paragraph [ref=e42]: Select a destination
            - generic [ref=e43]:
              - button "Confirm action" [disabled] [ref=e44]
              - button "Cancel action" [ref=e45] [cursor=pointer]
          - navigation "Secondary battle tools" [ref=e46]:
            - button "Inspect party" [ref=e47] [cursor=pointer]
            - button "Battle log" [ref=e48] [cursor=pointer]
            - button "Mute" [active] [pressed] [ref=e49] [cursor=pointer]
          - paragraph [ref=e50]: Sound on
        - generic [ref=e51]:
          - status [ref=e52]: Loading
          - button "Restart proof scene" [disabled] [ref=e53]
        - paragraph [ref=e54]: Elevated board · Tap to select · Drag to pan · Wheel/pinch to zoom
```

# Test source

```ts
  1   | import {expect,test} from '@playwright/test';
  2   | import { readSession, playCommand } from './helpers/battlePolicy';
  3   | import { abilityCatalog } from './helpers/abilityCatalog';
  4   | import { progressHero, projectProgression } from '../src/domain/progression';
  5   | import { HERO_IDS } from '../src/content/constants';
  6   | import { previewMovement } from '../src/domain/grid';
  7   | 
  8   | test('Ranger learned actions follow level one, two and three through the real picker',async({page})=>{
  9   |   for(const [xp,mark,pin] of [[0,0,0],[60,1,0],[180,1,1]]) {
  10  |     await page.goto(`/tests/fixtures/abilities/index.html?hero=ranger&xp=${xp}`);
  11  |     await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  12  |     await expect(page.locator('#battle-ability option[value="ability:high_shot"]')).toHaveCount(1);
  13  |     await expect(page.locator('#battle-ability option[value="ability:mark_target"]')).toHaveCount(mark);
  14  |     await expect(page.locator('#battle-ability option[value="ability:pinning_shot"]')).toHaveCount(pin);
  15  |     await expect(page.locator('#battle-ability-info')).toContainText('Mark Target unlocks at level 2; Pinning Shot at level 3');
  16  |   }
  17  | });
  18  | 
  19  | for(const ability of ['mark_target','pinning_shot'] as const)test(`Ranger ${ability} preserves keyboard touch preview cancellation inspection and exact resume`,async({page,isMobile})=>{
  20  |   test.setTimeout(90000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  21  |   await page.goto('/tests/fixtures/abilities/index.html?hero=ranger&xp=180');
  22  |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  23  |   const picker=page.locator('#battle-ability'),button=page.locator('[data-action=signature]'),abilityId=`ability:${ability}`;
  24  |   const before=await readSession(page),storage=await page.evaluate(()=>JSON.stringify(localStorage));
  25  |   // Exercise no-roll controls with a real unlocked backend, so muted audio cannot
  26  |   // hide an accidental attack/magic cue in the presentation path.
  27  |   if(isMobile)await page.locator('#battle-sound').tap();else {await page.locator('#battle-sound').focus();await page.keyboard.press('Enter');}
> 28  |   await expect.poll(()=>page.evaluate(()=>window.fitDiagnostics().battleAudio)).toMatchObject({enabled:true,status:'ready',started:0});
      |                              ^ Error: page.evaluate: TypeError: window.fitDiagnostics is not a function. (In 'window.fitDiagnostics()', 'window.fitDiagnostics' is undefined)
  29  |   expect((await readSession(page)).state).toEqual(before.state);
  30  |   await picker.selectOption(abilityId);await expect(picker).toHaveValue(abilityId);await picker.focus();
  31  |   if(isMobile)await button.tap();else await button.click();
  32  |   await page.locator('#battle-target').selectOption('2,0');
  33  |   await expect(page.locator('#battle-preview')).toContainText('no damage or roll');
  34  |   await expect(page.locator('#battle-preview')).not.toContainText('Taunt');
  35  |   const pending=(await readSession(page)).pending;expect(pending).toMatchObject({abilityId});
  36  |   const viewport=page.viewportSize()!;await page.setViewportSize({width:320,height:568});
  37  |   await expect(picker).toHaveValue(abilityId);expect((await readSession(page)).pending).toEqual(pending);
  38  |   expect((await readSession(page)).state).toEqual(before.state);expect(await page.evaluate(()=>JSON.stringify(localStorage))).toBe(storage);
  39  |   await page.locator('#battle-review').scrollIntoViewIfNeeded();await page.screenshot({path:test.info().outputPath(`${ability}-narrow-preview.png`)});
  40  |   await page.setViewportSize(viewport);await page.keyboard.press('Escape');expect((await readSession(page)).pending).toBeNull();
  41  |   expect((await readSession(page)).state).toEqual(before.state);
  42  |   if(isMobile)await button.tap();else await button.click();await page.locator('#battle-target').selectOption('2,0');
  43  |   if(isMobile)await page.locator('#battle-review').tap();else {await page.locator('#battle-review').focus();await page.keyboard.press('Enter');}
  44  |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  45  |   const accepted=await readSession(page),target=accepted.state.units.find(u=>u.id===5)!;
  46  |   expect(await page.evaluate(()=>window.fitDiagnostics().battleAudio)).toMatchObject({enabled:true,status:'ready',started:0,completed:0,dropped:0,active:null,recent:[],ownedSounds:0});
  47  |   expect(target[ability==='mark_target'?'markedBy':'pinnedBy']).toBe(2);expect(accepted.state.rng).toEqual(before.state.rng);
  48  |   expect(accepted.state.units.map(u=>u.hp)).toEqual(before.state.units.map(u=>u.hp));
  49  |   expect(accepted.state.commandCount).toBe(before.state.commandCount+1);await expect(picker).toBeDisabled();
  50  |   await page.locator('#battle-party').click();await page.locator('#inspect-unit-5').click();
  51  |   await expect(page.getByRole('dialog')).toContainText(ability==='mark_target'?'Marked by Ranger #2':'Pinned by Ranger #2');
  52  |   await page.screenshot({path:test.info().outputPath(`${ability}-inspection.png`)});await page.locator('#inspection-close').click();
  53  |   await page.locator('#battle-log-open').click();await expect(page.getByRole('dialog')).toContainText(ability==='mark_target'?'marked by Ranger':'pinned by Ranger');await page.locator('#log-close').click();
  54  |   await page.reload();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  55  |   const resumed=await readSession(page);expect(resumed.state).toEqual(accepted.state);expect(resumed.events).toEqual([]);expect(resumed.pending).toBeNull();
  56  |   expect(errors).toEqual([]);
  57  | });
  58  | 
  59  | test('Fighter healing and Taunt preserve keyboard touch cancellation inspection and resume',async({page,isMobile})=>{
  60  |   test.setTimeout(90000);const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  61  |   await page.goto('/tests/fixtures/abilities/index.html?hero=fighter&xp=180&injured');
  62  |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  63  |   const picker=page.locator('#battle-ability'),signature=page.locator('[data-action=signature]');
  64  |   await expect(picker.locator('option[value="ability:second_wind"]')).toHaveCount(1);await expect(picker.locator('option[value="ability:taunt"]')).toHaveCount(1);
  65  |   const initial=await readSession(page);
  66  |   await picker.selectOption('ability:second_wind');if(isMobile)await signature.tap();else await signature.click();
  67  |   await page.locator('#battle-target').selectOption('0,0');await expect(page.locator('#battle-preview')).toContainText('Heal 7 HP');
  68  |   await expect(page.locator('#battle-preview')).not.toContainText('Friendly fire');await expect(page.locator('#battle-ability-info')).toContainText('1/1 use');
  69  |   await page.locator('#battle-party').click();await expect(page.getByRole('dialog')).toContainText('Second Wind 1/1');await page.locator('#inspection-close').click();
  70  |   const viewport=page.viewportSize()!;await page.setViewportSize({width:320,height:568});await expect(picker).toHaveValue('ability:second_wind');
  71  |   expect((await readSession(page)).state).toEqual(initial.state);
  72  |   await page.locator('#battle-review').scrollIntoViewIfNeeded();await page.screenshot({path:test.info().outputPath('fighter-heal-preview-narrow.png')});
  73  |   await page.setViewportSize(viewport);await page.keyboard.press('Escape');expect((await readSession(page)).pending).toBeNull();expect((await readSession(page)).state).toEqual(initial.state);
  74  |   await signature.click();await page.locator('#battle-target').selectOption('0,0');
  75  |   if(isMobile)await page.locator('#battle-review').tap();else {await page.locator('#battle-review').focus();await page.keyboard.press('Enter');}
  76  |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  77  |   const healed=await readSession(page);expect(healed.state.rng).toEqual(initial.state.rng);expect(healed.state.units.find(u=>u.defId==='fighter')).toMatchObject({hp:27,secondWindUsed:true,hasActed:true});
  78  |   await expect(page.locator('#battle-status')).toContainText('0/1');await page.locator('#battle-log-open').click();await expect(page.getByRole('dialog')).toContainText('heals 7 HP');await page.locator('#log-close').click();
  79  |   await page.reload();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');expect((await readSession(page)).state).toEqual(healed.state);
  80  |   await page.locator('#battle-next').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  81  |   for(let i=0;i<8;i++) {const s=await readSession(page);if(s.state.units.find(u=>u.id===s.state.initiative[s.state.activeIndex])!.defId==='fighter')break;await page.locator('#battle-next').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');}
  82  |   let next=await readSession(page),fighter=next.state.units.find(u=>u.id===next.state.initiative[next.state.activeIndex])!;expect(fighter.defId).toBe('fighter');
  83  |   await picker.selectOption('ability:second_wind');await expect(signature).toBeDisabled();await expect(page.locator('#battle-ability-info')).toContainText('Use exhausted');
  84  |   let enemy=next.state.units.find(u=>u.side==='enemy' && u.hp>0 && Math.abs(u.cell.x-fighter.cell.x)+Math.abs(u.cell.y-fighter.cell.y)===1);
  85  |   if(!enemy){
  86  |     const base=abilityCatalog(2),catalog=projectProgression(HERO_IDS.map(id=>progressHero(id,180,1,base)),base),reach=previewMovement(next.state,fighter.id,catalog);if(!reach.ok)throw Error(reach.reason);
  87  |     const move=reach.cells.find(c=>c.cost>0 && next.state.units.some(u=>u.side==='enemy' && u.hp>0 && Math.abs(u.cell.x-c.cell.x)+Math.abs(u.cell.y-c.cell.y)===1));if(!move)throw Error('No legal approach to Taunt');
  88  |     await playCommand(page,{type:'move',unitId:fighter.id,to:move.cell});await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  89  |     next=await readSession(page);fighter=next.state.units.find(u=>u.id===fighter.id)!;
  90  |     enemy=next.state.units.find(u=>u.side==='enemy' && u.hp>0 && Math.abs(u.cell.x-fighter.cell.x)+Math.abs(u.cell.y-fighter.cell.y)===1);
  91  |   }
  92  |   expect(enemy).toBeDefined();if(!enemy)throw Error('No adjacent enemy');
  93  |   await picker.selectOption('ability:taunt');if(isMobile)await signature.tap();else await signature.click();
  94  |   await page.locator('#battle-target').selectOption(`${enemy.cell.x},${enemy.cell.y}`);await expect(page.locator('#battle-preview')).toContainText('no roll');
  95  |   await page.locator('#battle-review').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  96  |   const taunted=await readSession(page);expect(taunted.state.rng).toEqual(next.state.rng);expect(taunted.state.units.find(u=>u.id===enemy.id)?.tauntedBy).toBe(fighter.id);
  97  |   await page.locator('#battle-party').click();await page.locator(`#inspect-unit-${enemy.id}`).click();await expect(page.getByRole('dialog')).toContainText(`Taunted by Fighter #${fighter.id}`);await expect(page.getByRole('dialog')).toContainText('next turn ends');
  98  |   await page.screenshot({path:test.info().outputPath('fighter-taunt-inspection.png')});await page.locator('#inspection-close').click();
  99  |   await page.locator('#battle-log-open').click();await expect(page.getByRole('dialog')).toContainText('taunted by Fighter');await page.locator('#log-close').click();
  100 |   await page.reload();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');expect((await readSession(page)).state).toEqual(taunted.state);expect((await readSession(page)).events).toEqual([]);
  101 |   expect(errors).toEqual([]);
  102 | });
  103 | for(const hero of ['fighter','ranger','mage'])test(`${hero} explicit later ability survives inspection/layout and cancels without mutation`,async({page,isMobile})=>{
  104 |   await page.goto(`/tests/fixtures/abilities/index.html?hero=${hero}`);
  105 |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  106 |   const picker=page.locator('#battle-ability'),button=page.locator('[data-action=signature]');
  107 |   await expect(picker.locator('option')).toHaveCount(2);
  108 |   const before=JSON.parse((await page.locator('#game').getAttribute('data-session'))!);
  109 |   if(isMobile)await picker.tap();else {await picker.focus();await page.keyboard.press('Space');}
  110 |   await page.keyboard.press('z');await page.keyboard.press('Enter');
  111 |   await expect(picker).toBeFocused();
  112 |   await expect(picker).toHaveValue(`ability:zz_${hero}`);
  113 |   if(isMobile)await button.tap();else await button.click();
  114 |   await expect(button).toHaveAttribute('aria-pressed','true');
  115 |   await expect(page.locator('#battle-ability-info')).toContainText('Range 1–5');
  116 |   await page.locator('#battle-target').selectOption('1,0');
  117 |   await expect(page.locator('#battle-review')).toBeEnabled();
  118 |   expect(JSON.parse((await page.locator('#game').getAttribute('data-session'))!).pending.abilityId).toBe(`ability:zz_${hero}`);
  119 |   const prepared=await page.locator('#game').getAttribute('data-session');
  120 |   await page.locator('#battle-party').click();await page.locator('#inspection-close').click();
  121 |   await picker.scrollIntoViewIfNeeded();
  122 |   await page.screenshot({path:test.info().outputPath(`${hero}-original-viewport.png`)});
  123 |   const viewport=page.viewportSize()!;await page.setViewportSize({width:320,height:568});
  124 |   await expect(picker).toHaveValue(`ability:zz_${hero}`);
  125 |   expect(await page.locator('#game').getAttribute('data-session')).toBe(prepared);
  126 |   expect(await picker.evaluate(e=>e.getBoundingClientRect().height)).toBeGreaterThanOrEqual(44);
  127 |   await picker.scrollIntoViewIfNeeded();
  128 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
```
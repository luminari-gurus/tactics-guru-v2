# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ability-picker.spec.ts >> Ranger mark_target preserves keyboard touch preview cancellation inspection and exact resume
- Location: tests/ability-picker.spec.ts:19:62

# Error details

```
Error: page.evaluate: TypeError: window.fitDiagnostics is not a function
    at eval (eval at evaluate (:311:30), <anonymous>:1:14)
    at UtilityScript.evaluate (<anonymous>:313:16)
    at UtilityScript.<anonymous> (<anonymous>:1:44)
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Proof scene diagnostics" [ref=e8]:
      - generic "Acting unit information; scroll for details" [ref=e9]:
        - paragraph [ref=e10]: Round 1 · Your turn
        - generic [ref=e11]:
          - img "Ranger portrait" [ref=e13]
          - generic [ref=e14]:
            - heading "Ranger" [level=2] [ref=e15]
            - paragraph [ref=e16]: HP 22/22
            - paragraph [ref=e19]: AC 12 · Accuracy +5
            - paragraph [ref=e20]: No status effects
        - paragraph [ref=e21]: Move ready / Action ready
      - generic "Actions, target and secondary tools; scroll for more" [ref=e22]:
        - generic [ref=e23]:
          - paragraph [ref=e24]: Choose your action
          - generic "Acting unit actions" [ref=e25]:
            - button "Move" [pressed] [ref=e26] [cursor=pointer]:
              - strong [ref=e27]: Move
              - generic [ref=e28]: Uses movement
            - button "Basic attack" [ref=e29] [cursor=pointer]:
              - strong [ref=e30]: Basic attack
              - generic [ref=e31]: Uses action
            - button "High Shot" [ref=e32] [cursor=pointer]:
              - strong [ref=e33]: High Shot
              - generic [ref=e34]: Uses action
            - button "Wait / End turn" [ref=e35] [cursor=pointer]:
              - strong [ref=e36]: Wait / End turn
              - generic [ref=e37]: Ends turn immediately
          - text: Ability
          - combobox "Ability" [ref=e38]:
            - option "High Shot" [selected]
            - option "Mark Target"
            - option "Pinning Shot"
            - option "Zz Ranger"
          - paragraph [ref=e39]: Range 2–5 · Hostile target · attack roll · uses action · Mark Target unlocks at level 2; Pinning Shot at level 3
          - paragraph [ref=e40]: Choose an action, then a target. Wait ends the turn immediately.
          - region "Target and action preview" [ref=e41]:
            - generic [ref=e42]: Target / destination
            - combobox "Target / destination" [ref=e43]:
              - option "Choose target" [selected]
              - option "(0, 1) · cost 1"
              - option "(1, 1) · cost 2"
              - option "(0, 2) · cost 2"
              - option "(2, 1) · cost 3"
              - option "(1, 2) · cost 3"
              - option "(0, 3) · cost 3"
              - option "(3, 1) · cost 4"
              - option "(2, 2) · cost 4"
            - paragraph [ref=e44]: Select a tile
            - paragraph
            - paragraph [ref=e45]: Select a destination
            - generic [ref=e46]:
              - button "Confirm action" [disabled] [ref=e47]
              - button "Cancel action" [ref=e48] [cursor=pointer]
          - navigation "Secondary battle tools" [ref=e49]:
            - button "Inspect party" [ref=e50] [cursor=pointer]
            - button "Battle log" [ref=e51] [cursor=pointer]
            - button "Mute" [active] [pressed] [ref=e52] [cursor=pointer]
          - paragraph [ref=e53]: Sound on
        - generic [ref=e54]:
          - status [ref=e55]: Loading
          - button "Restart proof scene" [disabled] [ref=e56]
        - paragraph [ref=e57]: Elevated board · Tap to select · Drag to pan · Wheel/pinch to zoom
```
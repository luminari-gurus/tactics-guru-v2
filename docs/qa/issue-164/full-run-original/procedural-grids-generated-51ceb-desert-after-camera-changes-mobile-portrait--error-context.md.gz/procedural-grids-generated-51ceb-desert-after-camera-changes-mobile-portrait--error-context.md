# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: procedural-grids.spec.ts >> generated production board picks, moves and resumes the same desert after camera changes
- Location: tests/procedural-grids.spec.ts:9:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "x": 5,
+   "x": 6,
    "y": 6,
  }
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Encounter 1 of 3 · forest ruins" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Run battle controls" [ref=e8]:
      - generic "Acting unit information; scroll for details" [ref=e9]:
        - paragraph [ref=e10]: Round 1 · Your turn
        - generic [ref=e11]:
          - img "Fighter portrait" [ref=e13]
          - generic [ref=e14]:
            - heading "Fighter" [level=2] [ref=e15]
            - paragraph [ref=e16]: HP 18/18
            - paragraph [ref=e19]: AC 14 · Accuracy +4
            - paragraph [ref=e20]: No status effects
        - paragraph [ref=e21]: Move ready / Action ready
      - generic "Actions, target and secondary tools; scroll for more" [ref=e22]:
        - generic [ref=e23]:
          - paragraph [ref=e24]: Choose your action
          - generic "Acting unit actions" [ref=e25]:
            - button "Move" [pressed] [ref=e26] [cursor=pointer]:
              - strong [ref=e27]: Move
              - generic [ref=e28]: Uses movement
            - button "Basic attack" [ref=e29] [cursor=pointer]:
              - strong [ref=e30]: Basic attack
              - generic [ref=e31]: Uses action
            - button "Guarded Strike" [ref=e32] [cursor=pointer]:
              - strong [ref=e33]: Guarded Strike
              - generic [ref=e34]: Uses action
            - button "Wait / End turn" [ref=e35] [cursor=pointer]:
              - strong [ref=e36]: Wait / End turn
              - generic [ref=e37]: Ends turn immediately
          - text: Ability
          - combobox "Ability" [ref=e38]:
            - option "Guarded Strike" [selected]
          - paragraph [ref=e39]: Range 1–1 · Hostile target · −2 attack / +2 AC until next turn · uses action · Second Wind unlocks at level 2; Taunt at level 3
          - paragraph [ref=e40]: Choose an action, then a target. Wait ends the turn immediately.
          - region "Target and action preview" [ref=e41]:
            - generic [ref=e42]: Target / destination
            - combobox "Target / destination" [ref=e43]:
              - option "Choose target"
              - option "(3, 9) · cost 1"
              - option "(2, 10) · cost 1"
              - option "(4, 10) · cost 1"
              - option "(3, 11) · cost 1"
              - option "(3, 8) · cost 2"
              - option "(2, 9) · cost 2"
              - option "(4, 9) · cost 2"
              - option "(1, 10) · cost 2"
              - option "(2, 11) · cost 2"
              - option "(4, 11) · cost 2"
              - option "(3, 7) · cost 3"
              - option "(2, 8) · cost 3"
              - option "(4, 8) · cost 3"
              - option "(1, 9) · cost 3"
              - option "(5, 9) · cost 3"
              - option "(0, 10) · cost 3"
              - option "(1, 11) · cost 3"
              - option "(5, 11) · cost 3"
              - option "(3, 6) · cost 4"
              - option "(2, 7) · cost 4"
              - option "(4, 7) · cost 4"
              - option "(1, 8) · cost 4"
              - option "(5, 8) · cost 4"
              - option "(0, 9) · cost 4"
              - option "(6, 9) · cost 4"
              - option "(0, 11) · cost 4"
              - option "(6, 11) · cost 4"
            - paragraph [ref=e44]: Selected (6, 6)
            - paragraph
            - paragraph [ref=e45]: "Unavailable: Unreachable"
            - generic [ref=e46]:
              - button "Confirm action" [disabled] [ref=e47]
              - button "Cancel action" [ref=e48] [cursor=pointer]
          - navigation "Secondary battle tools" [ref=e49]:
            - button "Inspect party" [ref=e50] [cursor=pointer]
            - button "Battle log" [ref=e51] [cursor=pointer]
            - button "Enable sound" [ref=e52] [cursor=pointer]
          - paragraph [ref=e53]: Sound off
        - paragraph [ref=e54]: Encounter 1 of 3 · forest ruins
        - generic [ref=e55]:
          - status [ref=e56]: Battle ready
          - button "Start new run" [ref=e57] [cursor=pointer]
        - generic [ref=e58]:
          - button "Save recovery" [ref=e59] [cursor=pointer]
          - generic [ref=e60]: Run saved on this device
        - paragraph [ref=e61]: "Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Single battle" [ref=e62] [cursor=pointer]:
          - /url: /
        - link "Dungeon floors" [ref=e63] [cursor=pointer]:
          - /url: /dungeon
        - group [ref=e64]:
          - generic "Privacy & analytics" [ref=e65] [cursor=pointer]
```

# Test source

```ts
  1  | import { writeFileSync } from 'node:fs';
  2  | import { expect, test } from '@playwright/test';
  3  | import { preparedSnapshot, runContext } from './helpers/runItemFixtures';
  4  | import { encodeRunSave, runBattleCatalog } from '../src/domain/runSaveEnvelope';
  5  | import { RUN_STORAGE_KEYS } from '../src/persistence/runStorage';
  6  | import { previewMovement } from '../src/domain/grid';
  7  | import { readSession, playCommand } from './helpers/battlePolicy';
  8  | 
  9  | test('generated production board picks, moves and resumes the same desert after camera changes',async({page})=>{
  10 |  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  11 |  await page.goto('/run');await page.locator('#run-start').click();await page.locator('#run-start-encounter').click();
  12 |  await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  13 |  const snapshot=JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);
  14 |  expect(snapshot.battlefield.kind).toBe('generated');
  15 |  const catalog=runBattleCatalog(snapshot.items,runContext)!;
  16 |  expect(catalog.maps[snapshot.activeBattle.mapId].cells.every(c=>c.terrainId==='sand'||c.terrainId==='rock')).toBe(true);
  17 |  const region=await page.locator('#battle-board-region').boundingBox();expect(region).not.toBeNull();
  18 |  await page.mouse.move(region!.x+region!.width/2,region!.y+region!.height/2);await page.mouse.wheel(0,-100);
  19 |  await page.mouse.down();await page.mouse.move(region!.x+region!.width/2+18,region!.y+region!.height/2+12);await page.mouse.up();
  20 |  await page.setViewportSize({width:page.viewportSize()!.width,height:page.viewportSize()!.height+20});
  21 |  const report=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  22 | 
  23 |  // Select a known flat central cell through production pointer picking.
  24 |  const cell={x:5,y:6};
  25 |  await page.mouse.click(report.transform.x+(cell.x-cell.y)*40*report.transform.scale,report.transform.y+(cell.x+cell.y)*20*report.transform.scale);
> 26 |  expect(JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!).selected).toMatchObject(cell);
     |                                                                                                 ^ Error: expect(received).toMatchObject(expected)
  27 |  const session=await readSession(page),actor=session.state.initiative[session.state.activeIndex];
  28 |  const reach=previewMovement(session.state,actor,catalog);expect(reach.ok).toBe(true);
  29 |  if(!reach.ok)throw Error('Movement unavailable');
  30 |  expect(report.reachable).toEqual(reach.cells.map(c=>c.cell));
  31 |  const destination=reach.cells.find(c=>c.cost>0)!;
  32 |  await playCommand(page,{type:'move',unitId:actor,to:destination.cell});
  33 |  await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  34 |  const committed=JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);
  35 |  await page.screenshot({path:test.info().outputPath('desert-grid.png')});
  36 |  await page.reload();await page.locator('#run-continue').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  37 |  expect((await readSession(page)).state).toEqual(committed.activeBattle);
  38 |  expect(JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!).battlefield).toEqual(committed.battlefield);
  39 |  expect((await readSession(page)).events).toEqual([]);expect(errors).toEqual([]);
  40 | });
  41 | 
  42 | 
  43 | test('authored final entry preserves carried heroes and equipped projection',async({page})=>{
  44 |  const snapshot=preparedSnapshot();
  45 |  const items={...snapshot.items,run:{...snapshot.items.run,encounterIndex:2,revision:4},ownership:{...snapshot.items.ownership,assignments:[{instanceId:snapshot.items.ownership.equipment[0].instanceId,heroId:'fighter' as const,slot:'charm' as const}]}};
  46 |  const encoded=encodeRunSave({...snapshot,items},runContext);expect(encoded.ok).toBe(true);if(!encoded.ok)throw Error('Invalid final fixture');
  47 |  await page.goto('/run');await page.evaluate(({key,text})=>localStorage.setItem(key,text),{key:RUN_STORAGE_KEYS.primary,text:encoded.text});await page.reload();
  48 |  await page.locator('#run-continue').click();await page.locator('#run-start-encounter').click();await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  49 |  const current=JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);
  50 |  expect(current.battlefield.kind).toBe('authored');expect(current.activeBattle.mapId).toBe('map:ruined_approach');
  51 |  expect(current.activeBattle.units.filter((u:any)=>u.side==='player').map((u:any)=>({heroId:u.defId,hp:u.hp}))).toEqual(items.run.party.filter(h=>h.hp>0).map(({heroId,hp})=>({heroId,hp})));
  52 |  expect(current.items.run.party).toEqual(items.run.party);
  53 |  expect(runBattleCatalog(current.items,runContext)!.heroes.fighter.stats.armorClass).toBe(runContext.catalog.heroes.fighter.stats.armorClass+1);
  54 |  await page.screenshot({path:test.info().outputPath('authored-final.png')});
  55 | });
  56 | 
  57 | 
  58 | test('repeated generated restarts keep the static shape cache bounded',async({page})=>{
  59 |  await page.goto('/run');await page.locator('#run-start').click();await page.locator('#run-start-encounter').click();
  60 |  await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  61 |  const captures=[];
  62 |  for(let restart=0;restart<4;restart++){
  63 |   const report=JSON.parse((await page.locator('#game').getAttribute('data-battle-report'))!);
  64 |   const snapshot=JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);
  65 |   captures.push({restart,seed:snapshot.items.run.seed,battlefield:snapshot.battlefield,viewport:page.viewportSize(),textures:report.shapeTextures,objectCount:report.objectCount});
  66 |   expect(report.shapeTextures.filter((t:any)=>t.key.includes('column'))).toHaveLength(2);
  67 |   expect(report.shapeTextures.length).toBeLessThanOrEqual(18);
  68 |   if(restart>0)expect(report.shapeTextures).toEqual(captures[0].textures);
  69 |   if(restart===3)break;
  70 |   await page.locator('#fit-restart').click();await page.locator('#run-confirm-new').click();await page.locator('#run-start-encounter').click();
  71 |   await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  72 |  }
  73 |  writeFileSync(test.info().outputPath('static-textures.json'),JSON.stringify(captures,null,2));
  74 | });
  75 | 
  76 | 
  77 | test('missing desert surface fails through the controlled asset error',async({page})=>{
  78 |  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  79 |  await page.route('**/battle/terrain/sand.png',route=>route.abort());
  80 |  await page.goto('/run');await page.locator('#run-start').click();await page.locator('#run-start-encounter').click();
  81 |  await expect(page.locator('#fit-status')).toContainText('Error: Asset load failed');
  82 |  await expect(page.locator('#game')).toHaveAttribute('data-ready','false');
  83 |  expect(errors).toEqual([]);
  84 | });
  85 | 
```
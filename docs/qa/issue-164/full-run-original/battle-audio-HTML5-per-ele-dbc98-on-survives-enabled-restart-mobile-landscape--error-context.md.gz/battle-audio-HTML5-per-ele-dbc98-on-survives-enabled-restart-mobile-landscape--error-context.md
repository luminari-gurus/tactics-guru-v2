# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: battle-audio.spec.ts >> HTML5 per-element permission survives enabled restart
- Location: tests/battle-audio.spec.ts:162:34

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - main "Tactics Guru game canvas" [ref=e2]:
    - generic "Battle board. Arrow keys navigate, Enter selects, Escape cancels." [ref=e3]
  - generic:
    - region "Battlefield":
      - generic [ref=e4]:
        - paragraph [ref=e5]: Tactics Guru
        - heading "Forest Ruins" [level=1] [ref=e6]
      - paragraph [ref=e7]: "Gold: active · White: selected · Teal: reachable · Purple dots: ability reach · Pink +: target in reach · Ring: preview origin"
    - complementary "Battle controls" [ref=e8]:
      - generic "Acting unit information; scroll for details" [ref=e9]:
        - paragraph [ref=e10]: Round 1 · Your turn
        - generic [ref=e11]:
          - img "Fighter portrait" [ref=e13]
          - generic [ref=e14]:
            - heading "Fighter" [level=2] [ref=e15]
            - paragraph [ref=e16]: HP 18/18
            - paragraph [ref=e19]: AC 14 · Accuracy +4
            - paragraph [ref=e20]: No status effects
        - paragraph [ref=e21]: Move spent / Action ready
      - generic "Actions, target and secondary tools; scroll for more" [ref=e22]:
        - generic [ref=e23]:
          - paragraph [ref=e24]: Choose your action
          - generic "Acting unit actions" [ref=e25]:
            - button "Move" [disabled] [ref=e26]:
              - strong [ref=e27]: Move
              - generic [ref=e28]: Spent
            - button "Basic attack" [ref=e29] [cursor=pointer]:
              - strong [ref=e30]: Basic attack
              - generic [ref=e31]: Uses action
            - button "Guarded Strike" [ref=e32] [cursor=pointer]:
              - strong [ref=e33]: Guarded Strike
              - generic [ref=e34]: Uses action
            - button "Wait / End turn" [ref=e35] [cursor=pointer]:
              - strong [ref=e36]: Wait / End turn
              - generic [ref=e37]: Ends turn immediately
          - text: Ability
          - combobox "Ability" [ref=e38]:
            - option "Guarded Strike" [selected]
          - paragraph [ref=e39]: Range 1–1 · Hostile target · −2 attack / +2 AC until next turn · uses action · Second Wind unlocks at level 2; Taunt at level 3
          - paragraph [ref=e40]: Movement spent. Choose an action, then a target. Wait ends the turn immediately.
          - region "Target and action preview" [ref=e41]:
            - generic [ref=e42]: Target / destination
            - combobox "Target / destination" [disabled] [ref=e43]:
              - option "Choose target" [selected]
            - paragraph [ref=e44]: Select a tile
            - paragraph
            - paragraph [ref=e45]: Choose an action and target
            - generic [ref=e46]:
              - button "Confirm action" [disabled] [ref=e47]
              - button "Cancel action" [disabled] [ref=e48]
          - navigation "Secondary battle tools" [ref=e49]:
            - button "Inspect party" [ref=e50] [cursor=pointer]
            - button "Battle log" [ref=e51] [cursor=pointer]
            - button "Mute" [pressed] [ref=e52] [cursor=pointer]
            - button "Retry sound" [ref=e53] [cursor=pointer]
          - paragraph [ref=e54]: "Sound blocked: Sound playback timed out. Retry sound."
        - generic [ref=e55]:
          - status [ref=e56]: Battle ready
          - button "Restart battle" [active] [ref=e57] [cursor=pointer]
        - generic [ref=e58]:
          - generic [ref=e59]: Battle saved on this device
          - button "Save recovery" [ref=e60] [cursor=pointer]
        - paragraph [ref=e61]: "Gold: active · White: selected · Teal: reachable · Tap to select · Drag to pan · Wheel/pinch to zoom · Keyboard: arrows, Enter selects, Escape cancels"
        - link "Play three-encounter run" [ref=e62] [cursor=pointer]:
          - /url: /run
        - group [ref=e63]:
          - generic "Privacy & analytics" [ref=e64] [cursor=pointer]
```

# Test source

```ts
  93  |     await page.clock.runFor(48);
  94  |   }
  95  |   expect(enemy).toBeDefined();
  96  |   await expect(page.locator('#battle-sound')).toBeEnabled();
  97  |   await page.locator('#battle-sound').click({force:true});
  98  |   expect(await audio(page)).toMatchObject({enabled:false,active:null});expect((await session(page)).state).toEqual(enemy!.state);
  99  |   await page.clock.resume();await ready(page);
  100 |   expect(found).toEqual([]);
  101 | });
  102 | 
  103 | for(const mode of ['reject','pending'] as const) test(`gesture unlock ${mode} remains bounded and retryable`,async({page})=>{
  104 |   const found=errors(page);
  105 |   await page.addInitScript(mode=>{
  106 |     const original=AudioContext.prototype.resume;
  107 |     const state=Object.getOwnPropertyDescriptor(BaseAudioContext.prototype,'state')!.get!;
  108 |     // Guarantee Phaser sees the initial lock, even when headless autoplay starts running.
  109 |     Object.defineProperty(AudioContext.prototype,'state',{get(){return window.__allowAudio?state.call(this):'suspended';}});
  110 |     AudioContext.prototype.resume=function(){return window.__allowAudio?original.call(this):mode==='reject'?Promise.reject(Error('refused')):new Promise(()=>{});};
  111 |   },mode);
  112 |   await page.goto('/');await ready(page);await page.locator('#battle-sound').click();
  113 |   await expect.poll(()=>audio(page)).toMatchObject({status:'blocked',started:0});
  114 |   await expect(page.locator('#battle-next')).toBeEnabled();
  115 |   await page.evaluate(()=>{window.__allowAudio=true;});await page.locator('#battle-sound-retry').click();
  116 |   await expect.poll(()=>audio(page)).toMatchObject({status:'ready',started:0});expect(found).toEqual([]);
  117 | });
  118 | 
  119 | for(const mode of ['reject','pending'] as const) test(`automatic recovery ${mode} after successful unlock stays nonfatal and bounded`,async({page})=>{
  120 |   const found=errors(page);
  121 |   await page.addInitScript(mode=>{
  122 |     const Original=AudioContext, resume=Original.prototype.resume;
  123 |     window.AudioContext=new Proxy(Original,{construct(target,args){
  124 |       const context=new target(...args);window.__battleContext=context;return context;
  125 |     }});
  126 |     window.__resumeCalls=0;
  127 |     Original.prototype.resume=function(){
  128 |       if(!window.__resumeFailure)return resume.call(this);
  129 |       window.__resumeCalls!++;
  130 |       return mode==='reject'?Promise.reject(new DOMException('Resume refused','NotAllowedError')):new Promise<void>((resolve,reject)=>{
  131 |         window.__releaseResume=()=>{void resume.call(this).then(resolve,reject);};
  132 |       });
  133 |     };
  134 |   },mode);
  135 |   await page.goto('/');await ready(page);await enable(page);
  136 |   await page.evaluate(async()=>{window.__resumeFailure=true;await window.__battleContext!.suspend();window.dispatchEvent(new Event('focus'));});
  137 |   await expect.poll(()=>audio(page)).toMatchObject({status:'blocked',active:null});
  138 |   await expect(page.locator('#battle-sound-retry')).toBeVisible();
  139 |   // Exercise the engine's delayed visible handler as well as focused frame recovery.
  140 |   await page.evaluate(()=>{
  141 |     Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'));
  142 |     Object.defineProperty(document,'hidden',{configurable:true,value:false});document.dispatchEvent(new Event('visibilitychange'));
  143 |     window.dispatchEvent(new Event('focus'));
  144 |   });
  145 |   await page.waitForTimeout(250);
  146 |   expect(await page.evaluate(()=>window.__resumeCalls)).toBe(1);
  147 |   await expect(page.locator('#fit-status')).toHaveText('Battle ready');
  148 |   await expect(page.locator('#battle-next')).toBeEnabled();await expect(page.locator('#fit-restart')).toBeEnabled();
  149 |   const before=(await session(page)).state.commandCount;
  150 |   await page.locator('#battle-next').click();await ready(page);
  151 |   expect((await session(page)).state.commandCount).toBeGreaterThan(before);
  152 |   const started=(await audio(page)).started;
  153 |   await page.evaluate(()=>{window.__resumeFailure=false;});await page.locator('#battle-sound-retry').click();
  154 |   await expect.poll(()=>audio(page)).toMatchObject({status:'ready',started});
  155 |   await page.locator('#fit-restart').click();await confirmRestart(page);await expect(page.locator('#game')).toHaveAttribute('data-run','2');await ready(page);
  156 |   const afterRestart=await audio(page);
  157 |   await page.evaluate(()=>window.__releaseResume?.());await page.waitForTimeout(100);
  158 |   expect(await audio(page)).toEqual(afterRestart);
  159 |   expect((await audio(page)).enabled).toBe(true);expect(found).toEqual([]);
  160 | });
  161 | 
  162 | for(const early of [true,false]) test(`HTML5 per-element permission survives ${early?'early enable':'enabled restart'}`,async({page})=>{
  163 |   const found=errors(page);
  164 |   await page.addInitScript(()=>{
  165 |     Object.defineProperty(window,'AudioContext',{value:undefined});Object.defineProperty(window,'webkitAudioContext',{value:undefined});
  166 |     const original=HTMLMediaElement.prototype.play,primed=new WeakSet<HTMLMediaElement>();
  167 |     let gesture=false;
  168 |     // A gesture lasts only through dispatch, not through later media/network callbacks.
  169 |     for(const event of ['click','keydown','touchend'])document.addEventListener(event,e=>{
  170 |       if(!e.isTrusted)return;gesture=true;setTimeout(()=>{gesture=false;},0);
  171 |     },true);
  172 |     window.__mediaPolicy={primed:0,rejected:0};
  173 |     HTMLMediaElement.prototype.play=function(){
  174 |       if(this.muted && gesture && !primed.has(this)){primed.add(this);window.__mediaPolicy!.primed++;}
  175 |       if(!primed.has(this)){window.__mediaPolicy!.rejected++;return Promise.reject(new DOMException('Element requires a gesture','NotAllowedError'));}
  176 |       return original.call(this);
  177 |     };
  178 |   });
  179 |   let release!:()=>void;const held=new Promise<void>(resolve=>{release=resolve;});
  180 |   if(early)await page.route('**/audio/battle/**',async route=>{await held;await route.continue();});
  181 |   await page.goto('/');await ready(page);
  182 |   if(early){await page.locator('#battle-sound').click();release();}
  183 |   else {await enable(page);await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);}
  184 |   await expect.poll(()=>audio(page)).toMatchObject({enabled:true,load:'ready',status:'blocked',started:0});
  185 |   await expect(page.locator('#battle-sound-retry')).toBeVisible();
  186 |   const primed=early?0:8;
  187 |   expect(await page.evaluate(()=>window.__mediaPolicy)).toEqual({primed,rejected:0});
  188 |   await page.locator('#battle-next').click();await ready(page);
  189 |   expect((await audio(page)).started).toBe(0);
  190 |   await page.locator('#battle-sound-retry').click();await expect.poll(()=>audio(page)).toMatchObject({status:'ready',started:0});
  191 |   expect(await page.evaluate(()=>window.__mediaPolicy)).toEqual({primed:primed+8,rejected:0});
  192 |   await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
> 193 |   await expect.poll(async()=>(await audio(page)).completed).toBeGreaterThan(0);
      |                                                             ^ Error: expect(received).toBeGreaterThan(expected)
  194 |   expect(await page.evaluate(()=>window.__mediaPolicy!.rejected)).toBe(0);expect(found).toEqual([]);
  195 | });
  196 | 
  197 | test('unrelated asynchronous failures still reach the fatal application handler',async({page})=>{
  198 |   await page.goto('/');await ready(page);
  199 |   await page.evaluate(()=>{void Promise.reject(Error('unrelated application failure'));});
  200 |   await expect(page.locator('#fit-status')).toContainText('asynchronous error');
  201 |   await expect(page.locator('#fit-restart')).toBeDisabled();
  202 | });
  203 | 
  204 | declare global { interface Window {
  205 |   __battleContext?:AudioContext;__resumeFailure?:boolean;__resumeCalls?:number;__releaseResume?:()=>void;
  206 |   __mediaPolicy?:{primed:number;rejected:number};
  207 | } }
  208 | 
  209 | for(const mode of ['missing','corrupt','stalled','decode-stalled'] as const) test(`${mode} optional media leaves legal controls usable`,async({page})=>{
  210 |   const found:string[]=[];page.on('pageerror',e=>found.push(e.message));
  211 |   if(mode==='decode-stalled')await page.addInitScript(()=>{AudioContext.prototype.decodeAudioData=()=>new Promise(()=>{});});
  212 |   else await page.route('**/audio/battle/move.mp3',route=>mode==='stalled'?undefined:route.fulfill({status:mode==='missing'?404:200,contentType:'audio/mpeg',body:'invalid audio'}));
  213 |   await page.goto('/');await ready(page);
  214 |   if(mode==='stalled' || mode==='decode-stalled'){
  215 |     // Restart while optional work is pending, five times; old callbacks must stay inert.
  216 |     for(let run=2;run<=6;run++) {await page.locator('#fit-restart').click();await confirmRestart(page);await expect(page.locator('#game')).toHaveAttribute('data-run',String(run));}
  217 |     await ready(page);
  218 |   }
  219 |   await expect.poll(()=>audio(page),{timeout:LOAD_TIMEOUT_MS+3000}).toMatchObject({load:'unavailable',started:0});
  220 |   await expect(page.locator('#battle-sound-status')).toContainText('Sound unavailable');
  221 |   await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});
  222 |   const before=(await session(page)).state.commandCount;await page.locator('#battle-review').click();await ready(page);
  223 |   expect((await session(page)).state.commandCount).toBe(before+1);expect(found).toEqual([]);
  224 | });
  225 | 
  226 | test('HTML5 fallback loads and plays future cues after a gesture',async({page})=>{
  227 |   const found=errors(page);
  228 |   await page.addInitScript(()=>{
  229 |     Object.defineProperty(window,'AudioContext',{value:undefined});Object.defineProperty(window,'webkitAudioContext',{value:undefined});
  230 |     const original=HTMLMediaElement.prototype.play;window.__mediaPlays=0;
  231 |     HTMLMediaElement.prototype.play=function(){window.__mediaPlays!++;return original.call(this);};
  232 |   });
  233 |   await page.goto('/');await ready(page);await enable(page);
  234 |   await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
  235 |   await expect.poll(()=>audio(page)).toMatchObject({started:1,completed:1,active:null});
  236 |   await page.locator('#fit-restart').click();await confirmRestart(page);await ready(page);expect((await audio(page)).enabled).toBe(true);
  237 |   await expect.poll(()=>audio(page)).toMatchObject({load:'ready',status:'blocked'});
  238 |   await page.locator('#battle-sound-retry').click();await expect.poll(()=>audio(page)).toMatchObject({status:'ready'});
  239 |   // Blur in the same event after the real Confirm handler starts the cue, before it can finish.
  240 |   await page.evaluate(()=>document.addEventListener('click',e=>{if((e.target as HTMLElement).id==='battle-review')window.dispatchEvent(new Event('blur'));}));
  241 |   await page.locator('#battle-move').click();await page.locator('#battle-target').selectOption({index:1});await page.locator('#battle-review').click();
  242 |   expect(await audio(page)).toMatchObject({status:'blocked',active:null});
  243 |   const plays=await page.evaluate(()=>window.__mediaPlays);
  244 |   await page.evaluate(()=>window.dispatchEvent(new Event('focus')));await page.waitForTimeout(200);
  245 |   expect(await page.evaluate(()=>window.__mediaPlays)).toBe(plays);expect((await audio(page)).active).toBeNull();expect(found).toEqual([]);
  246 | });
  247 | 
  248 | declare global { interface Window { __mediaPlays?: number } }
  249 | 
  250 | test('unsupported audio has a useful nonfatal status',async({page})=>{
  251 |   const found=errors(page);await page.addInitScript(()=>{HTMLMediaElement.prototype.canPlayType=()=>'';});
  252 |   await page.goto('/');await ready(page);await expect.poll(()=>audio(page)).toMatchObject({load:'unavailable'});
  253 |   await expect(page.locator('#battle-next')).toBeEnabled();expect(found).toEqual([]);
  254 | });
  255 | 
  256 | test('late decode from a destroyed scene cannot alter replacement controls or playback',async({page})=>{
  257 |   const found=errors(page);
  258 |   await page.addInitScript(()=>{
  259 |     const original=AudioContext.prototype.decodeAudioData;
  260 |     let calls=0;const late:(()=>void)[]=[];
  261 |     Object.assign(window,{__releaseDecodes:()=>late.splice(0).forEach(f=>f())});
  262 |     AudioContext.prototype.decodeAudioData=function(bytes){
  263 |       if(++calls>8)return original.call(this,bytes);
  264 |       return new Promise<AudioBuffer>((resolve,reject)=>{late.push(()=>{void original.call(this,bytes).then(resolve,reject);});});
  265 |     };
  266 |   });
  267 |   await page.goto('/');await ready(page);expect((await audio(page)).load).toBe('loading');
  268 |   await page.locator('#fit-restart').click();await confirmRestart(page);
  269 |   // Restart is queued by Phaser; do not accept the outgoing scene's player phase.
  270 |   await expect.poll(async()=>(await session(page)).state.seed).toBe(2);await ready(page);
  271 |   await expect.poll(()=>audio(page)).toMatchObject({load:'ready',enabled:false,started:0});
  272 |   const before=await audio(page);
  273 |   await page.evaluate(()=>(window as unknown as {__releaseDecodes:()=>void}).__releaseDecodes());
  274 |   await page.waitForTimeout(200);
  275 |   expect(await audio(page)).toEqual(before);expect(found).toEqual([]);
  276 | });
  277 | 
  278 | async function startSeed(page:Page,seed:number,enabled:boolean) {
  279 |   await page.goto('/');await ready(page);
  280 |   if(enabled)await enable(page);
  281 |   if(seed===2){await page.locator('#fit-restart').click();await confirmRestart(page);await expect.poll(async()=>(await session(page)).state.seed).toBe(2);await ready(page);}
  282 |   if(enabled)await expect.poll(()=>audio(page)).toMatchObject({enabled:true,status:'ready'});
  283 | }
  284 | 
  285 | for(const seed of [1,2]) test(`seed ${seed}: short sound on/off legal checkpoints preserve session and saved bytes`,async({page})=>{
  286 |   const found=errors(page),silent:{session:Awaited<ReturnType<typeof session>>;saved:{primary:string|null;backup:string|null}}[]=[];
  287 |   const stored=()=>page.evaluate(keys=>({primary:localStorage.getItem(keys.primary),backup:localStorage.getItem(keys.backup)}),BATTLE_STORAGE_KEYS);
  288 |   for(const enabled of [false,true]){
  289 |     if(enabled)await page.evaluate(keys=>Object.values(keys).forEach(key=>localStorage.removeItem(key)),BATTLE_STORAGE_KEYS);
  290 |     await startSeed(page,seed,enabled);
  291 |     for(let i=0;i<=2;i++){
  292 |       const current=await session(page),saved=await stored(),checkpoint={session:current,saved};
  293 |       const encoded=encodeBattleSave(current.state,catalog);expect(encoded.ok).toBe(true);
```
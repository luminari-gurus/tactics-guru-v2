# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: telemetry.spec.ts >> mocked ingestion sees accepted run, rewards, completion and continue without replaying boundaries
- Location: tests/telemetry.spec.ts:20:1

# Error details

```
Test timeout of 300000ms exceeded.
```

```
Error: locator.selectOption: Test timeout of 300000ms exceeded.
Call log:
  - waiting for locator('[id="target-item:healing_draught"]')
    - locator resolved to <select disabled id="target-item:healing_draught" aria-label="Healing Draught target">…</select>
  - attempting select option action
    2 × waiting for element to be visible and enabled
      - element is not enabled
    - retrying select option action
    - waiting 20ms
    2 × waiting for element to be visible and enabled
      - element is not enabled
    - retrying select option action
      - waiting 100ms
    360 × waiting for element to be visible and enabled
        - element is not enabled
      - retrying select option action
        - waiting 500ms

```

# Page snapshot

```yaml
- region "Authored run" [ref=f1e2]:
  - generic [ref=f1e3]:
    - heading "Party items" [level=1] [ref=f1e4]
    - paragraph [ref=f1e5]: Encounter 3 of 3 · Ruined Approach · Prepare party
    - status [ref=f1e6]: Run saved on this device
    - paragraph [ref=f1e7]: Items may be used now, before the next battle starts.
    - region "Party" [ref=f1e8]:
      - paragraph [ref=f1e9]: "Fighter: 24/24 HP · Level 2 · XP 60/180 · Learned: basic attack, guarded strike · Accuracy 4 · Armor class 14 · Charm: none"
      - paragraph [ref=f1e10]: "Ranger: 0/12 HP · Level 1 · XP 30/60 · Learned: basic attack, high shot · Defeated · Accuracy 5 · Armor class 12 · Charm: none"
      - paragraph [ref=f1e11]: "Mage: 0/11 HP · Level 1 · XP 30/60 · Learned: basic attack, magic missile · Defeated · Accuracy 3 · Armor class 11 · Charm: none"
    - region "Rewards" [ref=f1e12]
    - region "Owned items" [ref=f1e13]:
      - heading "Owned items" [level=2] [ref=f1e14]
      - generic [ref=f1e15]:
        - paragraph [ref=f1e16]: Healing Draught ×1 · Restore 6 HP
        - combobox "Healing Draught target" [disabled] [ref=f1e17]:
          - option "Fighter (full HP)" [disabled]
          - option "Ranger (defeated)" [disabled]
          - option "Mage (defeated)" [disabled]
        - button "Use Healing Draught" [disabled] [ref=f1e18]
        - paragraph [ref=f1e19]: No eligible living target with missing HP.
    - region "Run save" [ref=f1e20]:
      - button "Continue saved run" [active] [ref=f1e21] [cursor=pointer]
      - button "Save recovery" [ref=f1e22] [cursor=pointer]
  - generic [ref=f1e23]:
    - button "Start encounter" [ref=f1e24] [cursor=pointer]
    - link "Single battle" [ref=f1e25] [cursor=pointer]:
      - /url: /
    - link "Dungeon floors" [ref=f1e26] [cursor=pointer]:
      - /url: /dungeon
    - group [ref=f1e27]:
      - generic "Privacy & analytics" [ref=f1e28] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { readSession, playCommand } from './helpers/battlePolicy';
  3   | import { playerDecision } from './helpers/playerPolicy';
  4   | import { runContext } from './helpers/runItemFixtures';
  5   | import { runBattleCatalog } from '../src/domain/runSaveEnvelope';
  6   | const endpoint = 'https://us.i.posthog.com/**';
  7   | type Event = { event: string; properties: Record<string, any> };
  8   | async function ingest(page: Page, blocked = false) {
  9   |   const events: Event[] = [];
  10  |   await page.route(endpoint, async route => {
  11  |     const body = route.request().postData();
  12  |     if (body) {
  13  |       const parsed = JSON.parse(body);
  14  |       events.push(...(Array.isArray(parsed) ? parsed : parsed.batch ?? [parsed]));
  15  |     }
  16  |     if (blocked) await route.abort(); else await route.fulfill({ status: 200, contentType: 'application/json', body: '{"status":1}' });
  17  |   });
  18  |   return events;
  19  | }
  20  | test('mocked ingestion sees accepted run, rewards, completion and continue without replaying boundaries', async ({ page }) => {
  21  |   test.setTimeout(300000);
  22  |   const events = await ingest(page);
  23  |   await page.goto('/run?token=private#private'); await page.locator('#run-start').click();
  24  |   await page.locator('#run-start-encounter').click();
  25  |   await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player');
  26  |   for (let index = 0; index < 3; index++) {
  27  |     for (let step = 0; step < 600; step++) {
  28  |       await expect.poll(async () => await page.locator('#run-screen').isVisible() || (await readSession(page))?.phase === 'player').toBe(true);
  29  |       if (await page.locator('#run-screen').isVisible()) break;
  30  |       const state = JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);
  31  |       const battle = await readSession(page);
  32  |       await playCommand(page, playerDecision(battle.state, runBattleCatalog(state.items, runContext)!));
  33  |     }
  34  |     const state = JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);
  35  |     if(index===2)expect(['victory','defeat']).toContain(state.items.run.phase);
  36  |     else expect(state.items.run.phase).toBe('reward');
  37  |     if (index < 2) {
  38  |       const item = (state.items.offer.options.find((option: { itemId: string }) => option.itemId === 'item:healing_draught') ?? state.items.offer.options[0]).itemId;
  39  |       await page.getByRole('button', { name: `Claim ${runContext.items[item as keyof typeof runContext.items].label}`, exact: true }).click();
  40  |       await page.locator('#item-confirm').click();
  41  |       const snapshot = async () => JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!);
  42  |       for (const equipment of (await snapshot()).items.ownership.equipment) {
  43  |         const now = await snapshot();
  44  |         if (now.items.ownership.assignments.some((a: { instanceId: string }) => a.instanceId === equipment.instanceId)) continue;
  45  |         const def = runContext.items[equipment.itemId as keyof typeof runContext.items];
  46  |         const hero = now.items.run.party.find((h: { hp: number; heroId: any }) => h.hp > 0 && def.eligibleHeroes.includes(h.heroId));
  47  |         if (hero) {
  48  |           await page.locator(`[id="target-${equipment.instanceId}"]`).selectOption(hero.heroId);
  49  |           await page.getByRole('button', { name: `Equip ${def.label}`, exact: true }).click(); await page.locator('#item-confirm').click();
  50  |         }
  51  |       }
  52  |       for (const hero of (await snapshot()).items.run.party) {
  53  |         const now = await snapshot();
  54  |         if (hero.hp === 0 || hero.hp === runContext.catalog.heroes[hero.heroId as keyof typeof runContext.catalog.heroes].stats.maxHp || !now.items.ownership.consumables.length) continue;
> 55  |         await page.locator('[id="target-item:healing_draught"]').selectOption(hero.heroId);
      |                                                                  ^ Error: locator.selectOption: Test timeout of 300000ms exceeded.
  56  |         await page.getByRole('button', { name: 'Use Healing Draught', exact: true }).click(); await page.locator('#item-confirm').click();
  57  |       }
  58  |       await page.reload(); await page.locator('#run-continue').click();
  59  |       await page.locator('#run-start-encounter').click();
  60  |       await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player');
  61  |     }
  62  |   }
  63  |   await expect.poll(() => events.filter(e => e.event === 'run_outcome').length).toBe(1);
  64  |   const terminal=JSON.parse((await page.locator('#game').getAttribute('data-run-snapshot'))!).items.run.phase;
  65  |   expect(events.find(e=>e.event==='run_outcome')!.properties).toMatchObject({phase:terminal,outcome:terminal,encounter:2});
  66  |   await page.reload(); await page.locator('#run-continue').click();
  67  |   await expect.poll(() => events.filter(e => e.event === 'run_continued').length).toBe(3);
  68  |   expect(events.filter(e => e.event === 'run_started')).toHaveLength(1);
  69  |   expect(events.filter(e => e.event === 'encounter_started')).toHaveLength(3);
  70  |   expect(events.filter(e => e.event === 'encounter_outcome')).toHaveLength(3);
  71  |   expect(events.filter(e => e.event === 'reward_chosen')).toHaveLength(2);
  72  |   expect(events.filter(e => e.event === 'run_outcome')).toHaveLength(1);
  73  |   expect(JSON.stringify(events)).not.toContain('private');
  74  |   const errors = events.filter(e => e.event === '$exception'); expect(errors.length).toBeGreaterThan(0);
  75  |   if (process.env.PLAYWRIGHT_TELEMETRY_DEV !== 'true') expect(errors[0].properties.$exception_list[0].stacktrace.frames.length).toBeGreaterThan(0);
  76  | });
  77  | test('blocked ingestion leaves battle continue and save working', async ({ page }) => {
  78  |   await ingest(page, true); await page.goto('/'); await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player');
  79  |   const before = (await readSession(page)).state;
  80  |   await page.locator('#battle-next').click(); await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player');
  81  |   const after = (await readSession(page)).state; expect(after.commandCount).toBeGreaterThan(before.commandCount);
  82  |   await page.reload(); await page.locator('#save-continue').click();
  83  |   await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player'); expect((await readSession(page)).state).toEqual(after);
  84  | });
  85  | for (const signal of ['opt-out','DNT','GPC'] as const) test(`${signal} prevents parser loading and all collection`, async ({ page }) => {
  86  |   const events = await ingest(page); const sdk: string[] = []; page.on('request', r => { if (r.url().includes('/transport-')) sdk.push(r.url()); });
  87  |   await page.addInitScript(signal => {
  88  |     if (signal === 'opt-out') localStorage.setItem('tactics-guru:telemetry-opt-out', 'true');
  89  |     else Object.defineProperty(navigator, signal === 'DNT' ? 'doNotTrack' : 'globalPrivacyControl', { value: signal === 'DNT' ? '1' : true });
  90  |   }, signal);
  91  |   await page.goto('/'); await expect(page.locator('#game')).toHaveAttribute('data-phase','player');
  92  |   expect(events).toEqual([]); expect(sdk).toEqual([]);
  93  | });
  94  | test('uncaught errors and rejections are sanitized and duplicate objects are reported once', async ({ page }) => {
  95  |   const events = await ingest(page);
  96  |   await page.goto('/'); await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player');
  97  |   await expect.poll(() => events.filter(e => e.event === '$exception').length).toBe(1); // Controlled verification.
  98  |   await page.evaluate(() => {
  99  |     const error = new TypeError('private error with save contents');
  100 |     window.dispatchEvent(new ErrorEvent('error', { error }));
  101 |     window.dispatchEvent(new ErrorEvent('error', { error }));
  102 |     window.dispatchEvent(new PromiseRejectionEvent('unhandledrejection', { promise: Promise.resolve(), reason: error }));
  103 |     window.dispatchEvent(new PromiseRejectionEvent('unhandledrejection', { promise: Promise.resolve(), reason: { payload: 'private save' } }));
  104 |   });
  105 |   await expect.poll(() => events.filter(e => e.event === '$exception').length).toBe(3);
  106 |   expect(events.filter(e => e.properties.failure === 'runtime_error')).toHaveLength(1);
  107 |   expect(events.filter(e => e.properties.failure === 'unhandled_rejection')).toHaveLength(1);
  108 |   expect(JSON.stringify(events)).not.toContain('private');
  109 | });
  110 | test('failed parser loading preserves gameplay and saving without a reporting loop', async ({ page }) => {
  111 |   const events = await ingest(page);
  112 |   await page.route(process.env.PLAYWRIGHT_TELEMETRY_DEV === 'true' ? '**/src/telemetry/transport.ts' : '**/assets/transport-*.js', route => route.abort());
  113 |   await page.goto('/'); await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player');
  114 |   await page.locator('#battle-next').click(); await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player');
  115 |   await expect(page.locator('#battle-persistence')).toContainText('saved'); expect(events).toEqual([]);
  116 | });
  117 | test('recovery inspections and retries report no raw data and no duplicate failure event', async ({ page }) => {
  118 |   const events = await ingest(page);
  119 |   await page.addInitScript(() => localStorage.setItem('tactics-guru:phaser:run:primary:v1','private broken save'));
  120 |   await page.goto('/run'); await page.locator('#run-recovery').click();
  121 |   await page.locator('#run-retry-save').click(); await page.locator('#run-retry-save').click();
  122 |   await expect.poll(() => events.filter(e => e.event === 'save_recovery_failed').length).toBe(1);
  123 |   expect(JSON.stringify(events)).not.toContain('private');
  124 | });
  125 | test('privacy controls stop collection immediately, persist across routes, and allow future visits', async ({ page }) => {
  126 |   const events = await ingest(page);
  127 |   await page.goto('/'); await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player');
  128 |   await expect.poll(() => events.filter(e => e.event === 'battle_started').length).toBe(1);
  129 |   const privacy = page.locator('#battle-scroll .telemetry-preferences');
  130 |   await privacy.locator('summary').focus(); await page.keyboard.press('Enter');
  131 |   const choice = privacy.getByRole('checkbox', { name: 'Allow anonymous analytics and error reports' });
  132 |   await expect(choice).toBeChecked();
  133 |   const labelBox = await privacy.locator('label').boundingBox(); expect(labelBox!.height).toBeGreaterThanOrEqual(44);
  134 |   await choice.scrollIntoViewIfNeeded(); await expect(choice).toBeInViewport();
  135 |   await page.screenshot({ path: test.info().outputPath('privacy-battle.png') });
  136 |   const before = (await readSession(page)).state;
  137 |   await choice.uncheck(); await expect(privacy.getByRole('status')).toContainText('off');
  138 |   expect((await readSession(page)).state).toEqual(before);
  139 |   const count = events.length;
  140 |   await page.locator('#battle-next').click(); await expect(page.locator('#game')).toHaveAttribute('data-phase', 'player');
  141 |   await page.goto('/run'); const runPrivacy = page.locator('#run-screen .telemetry-preferences');
  142 |   await runPrivacy.locator('summary').click();
  143 |   await expect(runPrivacy.getByRole('checkbox')).not.toBeChecked(); expect(events).toHaveLength(count);
  144 |   await runPrivacy.getByRole('checkbox').check(); await expect(runPrivacy.getByRole('status')).toContainText('later visit');
  145 |   expect(events).toHaveLength(count);
  146 |   await page.goto('/map'); await expect(page.locator('#map-page .telemetry-preferences')).toBeVisible();
  147 |   await expect.poll(() => events.filter(e => e.event === 'app_entered' && e.properties.route === 'map').length).toBe(1);
  148 |   await page.locator('#map-page .telemetry-preferences summary').click();
  149 |   await page.getByRole('checkbox').scrollIntoViewIfNeeded(); await expect(page.getByRole('checkbox')).toBeInViewport();
  150 |   await page.screenshot({ path: test.info().outputPath('privacy-map.png') });
  151 |   await page.getByRole('checkbox').uncheck();
  152 |   await page.reload(); await expect(page.locator('#map-page .telemetry-preferences')).toBeVisible();
  153 |   expect(events.filter(e => e.event === 'app_entered' && e.properties.route === 'map')).toHaveLength(1);
  154 | });
  155 | test('privacy opt-out applies to another open tab without touching saves', async ({ page, context }) => {
```